from abc import ABC, abstractmethod
from typing import Any, Callable, Iterable
from unittest.mock import Mock
from uuid import uuid4

from flows_sdk.types import Blob, HsBlockInstance, Measurement, StoreBlobRequest, StoreBlobResponse


class _MockFunction(Mock):
    """Private class used to implement Mock-like member functions of MockHsBlockInstance."""

    def __init__(self, func: Callable, return_value: Any | None = None) -> None:
        super().__init__()
        self._func = func
        self.return_value = return_value

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        self._mock_check_sig(*args, **kwargs)
        self._increment_mock_call(*args, **kwargs)
        return self._func(*args, **kwargs)


class MockHsTask:
    """
    Used as a stand in HsTask for the purpose of unit-testing CCBs.
    Implements its instance variables via custom value or dummy defaults.
    """

    def __init__(
        self,
        task_id: str = 'dummy_task_id',
        flow_run_id: str = 'dummy_flow_run_id',
        correlation_id: str = 'dummy_correlation_id',
        task_name: str = 'dummy_task_name',
        reference_name: str = 'dummy_reference_name',
    ) -> None:
        self.task_id = task_id
        self.flow_run_id = flow_run_id
        self.correlation_id = correlation_id
        self.task_name = task_name
        self.reference_name = reference_name


class BaseMockHsBlockInstance(ABC):
    """
    Base class for all MockHsBlockInstance classes.

    It's derivatives are used as a stand in HsBlockInstance for the purpose of unit-testing CCBs.
    Fully implements its interface in a semi-functional way.

    Logs, blobs, and measurements are stored in memory
    (therefore can't be meaningfully used in a multiprocess test).

    All of its methods are mocked via _MockFunction, therefore conforming them to
    the Mock testing interface, e.g. mock_instance.hs_request.assert_called_once().
    """

    LogLevel = HsBlockInstance.LogLevel

    def __init__(self) -> None:
        self._response = None
        self.blobs: dict[str, bytes] = {}
        self.log_data: list[str] = []
        self.measurements: list[Measurement] = []

        # init mocked methods:

        self.store_blob = _MockFunction(self._store_blob)
        self.store_blobs = _MockFunction(self._store_blobs)
        self.fetch_blob = _MockFunction(self._fetch_blob)

        self.publish_measurements = _MockFunction(self._publish_measurements)

        mock_resp = Mock()
        mock_resp.status_code = 200
        self.hs_request = _MockFunction(self._hs_request, mock_resp)
        self.hs_get = _MockFunction(self._hs_get)
        self.hs_post = _MockFunction(self._hs_post)

    @abstractmethod
    def _log(self, *args: Any, **kwargs: Any) -> None:
        raise NotImplementedError('log method must be implemented by subclass')

    def _store_blob(self, blob: StoreBlobRequest) -> StoreBlobResponse:
        blob_uuid = str(uuid4())
        self.blobs[blob_uuid] = blob.content
        return StoreBlobResponse(uuid=blob_uuid, name=blob.name)

    def _store_blobs(self, blobs: Iterable[StoreBlobRequest]) -> list[StoreBlobResponse]:
        return [self.store_blob(blob) for blob in blobs]

    def _fetch_blob(self, blob_reference: str) -> Blob:
        return Blob(content=self.blobs[blob_reference])

    def _publish_measurements(self, measurements: list[Measurement]) -> None:
        self.measurements += measurements

    def _hs_request(self, method: str, app_endpoint: str, **kwargs: dict[Any, Any]) -> Any:
        return self.hs_request.return_value

    def _hs_get(self, app_endpoint: str, **kwargs: dict[Any, Any]) -> Any:
        response = self.hs_request('GET', app_endpoint, **kwargs)
        return response

    def _hs_post(self, app_endpoint: str, **kwargs: dict[Any, Any]) -> Any:
        response = self.hs_request('POST', app_endpoint, **kwargs)
        return response


class MockHsBlockInstanceV1(BaseMockHsBlockInstance):
    """
    First iteration of the MockHsBlockInstance class, this imitates the older interface of
    HsBlockInstance prior to the introduction of logging arguments (pre-PYTHON_3_13).

    Use this class if you are running code blocks with python version <= 3.12.
    """

    def __init__(self) -> None:
        super().__init__()
        self.log = _MockFunction(self._log)

    def _log(
        self,
        msg: str,
        level: HsBlockInstance.LogLevel = HsBlockInstance.LogLevel.INFO,
        stacklevel: int = 1,
    ) -> None:
        self.log_data.append(f'{level.name} {msg}')


class MockHsBlockInstanceV2(BaseMockHsBlockInstance):
    """
    Second iteration of the MockHsBlockInstance class, this imitates the interface of
    HsBlockInstance after the introduction of logging arguments (PYTHON_3_13 and above).

    Use this class if you are running code blocks with python version >= 3.13.
    """

    def __init__(self) -> None:
        super().__init__()
        self.log = _MockFunction(self._log)

    def _log(
        self,
        msg: str,
        *args: Any,
        level: HsBlockInstance.LogLevel = HsBlockInstance.LogLevel.INFO,
        **kwargs: Any,
    ) -> None:
        for arg in args:
            if isinstance(arg, self.LogLevel | HsBlockInstance.LogLevel):
                level = arg
        args = tuple(
            arg for arg in args if not isinstance(arg, self.LogLevel | HsBlockInstance.LogLevel)
        )
        formatted_msg = msg.format(*args, **kwargs) if args or kwargs else msg
        self.log_data.append(f'{level.name} {formatted_msg}')


# keep default MockHsBlockInstance pointing to the latest version
MockHsBlockInstance = MockHsBlockInstanceV2
