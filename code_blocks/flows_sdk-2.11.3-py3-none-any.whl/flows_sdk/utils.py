"""
This module provides utility functions and references for working with flow inputs
and runtime metadata in flows.
"""

import base64
import hashlib
import mimetypes
import os
import uuid
from enum import StrEnum
from typing import Any

from flows_sdk.platform_version import (
    PLATFORM_TARGET_VERSION_ENV_VAR,
    get_target_platform_version,
)

# Environment variable that globally controls the code block output wrapping mode.
OUTPUT_WRAPPING_MODE_ENV_VAR = 'HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE'

# Minimum Hyperscience platform version that supports the output wrapping mode feature.
MIN_OUTPUT_WRAPPING_MODE_VERSION = (43, 2)


class OutputWrappingMode(StrEnum):
    """How a code block's runtime output is wrapped.

    - ``RESULT``: the return value is nested under a top-level ``result`` key (the default).
    - ``NO_WRAPPING``: the return value is emitted verbatim.
    """

    RESULT = 'result'
    NO_WRAPPING = 'no_wrapping'

    def __str__(self) -> str:
        return self.value


def resolve_output_wrapping_mode() -> tuple[OutputWrappingMode, bool]:
    """Resolve the global output wrapping mode and whether it should be serialized.

    The mode is controlled solely by the ``HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE`` environment
    variable and only serialized (with the target platform version validated) when it is set to a
    valid mode; otherwise it defaults to ``result`` and is omitted.

    :return: a tuple of the effective wrapping mode and whether it should be serialized.
    """
    configured_mode = os.environ.get(OUTPUT_WRAPPING_MODE_ENV_VAR, '')
    if configured_mode in OutputWrappingMode._value2member_map_:
        _validate_output_wrapping_target_version()
        return OutputWrappingMode(configured_mode), True

    return OutputWrappingMode.RESULT, False


def _validate_output_wrapping_target_version() -> None:
    """Guardrail applied when the wrapping mode is set via the environment variable.

    Requires ``HS_PLATFORM_TARGET_VERSION`` to be set to a version that supports the output
    wrapping mode feature (Hyperscience 43.2+), raising ``ValueError`` otherwise.
    """
    minimum = '.'.join(str(part) for part in MIN_OUTPUT_WRAPPING_MODE_VERSION)
    target_version = get_target_platform_version()
    if target_version is None:
        raise ValueError(
            f"'{OUTPUT_WRAPPING_MODE_ENV_VAR}' is set, which enables the code block "
            f'output wrapping mode feature. This feature is only available on Hyperscience '
            f'{minimum} and later, so the SDK needs to know which platform version this flow '
            f'targets before it can safely emit the parameter. Declare the targeted platform '
            f"version by setting the '{PLATFORM_TARGET_VERSION_ENV_VAR}' environment "
            f'variable to the Hyperscience version you are deploying to (must be {minimum} or '
            f'later).'
        )
    if target_version < MIN_OUTPUT_WRAPPING_MODE_VERSION:
        declared = '.'.join(str(part) for part in target_version)
        raise ValueError(
            f"The code block output wrapping mode feature (enabled via "
            f"'{OUTPUT_WRAPPING_MODE_ENV_VAR}') requires Hyperscience {minimum} or "
            f"later, but '{PLATFORM_TARGET_VERSION_ENV_VAR}' targets version {declared}."
        )


def apply_output_wrapping_mode(
    inputs: dict[str, Any], *, always: bool = False
) -> OutputWrappingMode:
    """Stamp the globally-selected output wrapping mode into a block's ``inputs`` so its
    runtime code drops the historical ``result`` wrapper, and return the resolved mode so the
    block's ``output()`` can match it.

    The mode is selected via the ``HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE`` env var (same switch as
    ``PythonBlock``/``CodeBlock``). When unset the resolved mode is ``RESULT`` (wrap), preserving
    backwards-compatible behavior.

    :param always: when ``True`` the mode is always stamped (defaulting to ``result``), so the
        block's input matches a composite/manifest that declares ``output_wrapping_mode`` as an
        input. When ``False`` it is only stamped if explicitly selected via the env var.
    """
    mode, serialize = resolve_output_wrapping_mode()
    if serialize or always:
        inputs['output_wrapping_mode'] = mode.value
    return mode


def workflow_input(*params: str) -> Any:
    """
    Generate a reference string to access flow input parameters.

    This function creates a reference that will be resolved at runtime to access
    values from the flow's input parameters. It supports accessing nested
    parameters using dot notation.

    :param params: One or more parameter names to create a reference path.
        Multiple parameters will be joined with dots to access nested values.
    :type params: str
    :return: A reference string in the format ``${workflow.input.param_path}``
        that will be resolved at runtime.
    :rtype: str
    :raises AssertionError: If no parameters are provided.

    .. include:: ../../../samples/utils/workflow_input_flow.py
        :literal:
    """
    assert len(params) > 0, 'At least one parameter has to be specified for workflow inputs'
    param_path = '.'.join(params)
    return f'${{workflow.input.{param_path}}}'


class FlowDefinitionReferences:
    """
    Container for flow definition metadata references.

    This class provides constant reference strings that will be resolved at runtime
    to access metadata about the flow definition itself (as opposed to a specific
    flow run).

    These references can be used in block inputs to access flow definition metadata
    dynamically at runtime.

    .. include:: ../../../samples/utils/workflow_definition_references_flow.py
        :literal:
    """

    IDENTIFIER = '${workflow.definition.identifier}'
    """
    Reference to the flow definition identifier.

    This will resolve at runtime to the unique identifier of the flow definition,
    which is set in the flow's Manifest (e.g., 'MY_CUSTOM_FLOW').
    """


class FlowRunReferences:
    """
    Container for flow run metadata references.

    This class provides constant reference strings that will be resolved at runtime
    to access metadata about the current flow run instance (as opposed to the
    flow definition).

    These references can be used in block inputs to access runtime-specific information
    such as the unique run UUID or correlation ID for tracking related flow executions.

    For flow run related APIs please refer to the `Flow Run API documentation
    <https://docs.hyperscience.ai/#flows-runs>`_.

    .. include:: ../../../samples/utils/workflow_run_references_flow.py
        :literal:
    """

    UUID = '${workflow.run.uuid}'
    """
    Reference to the unique identifier of the current flow run.

    This will resolve at runtime to a UUID that uniquely identifies this specific
    execution instance of the flow (e.g., '550e8400-e29b-41d4-a716-446655440000').
    """

    CORRELATION_ID = '${workflow.run.correlation_id}'
    """
    Reference to the correlation ID of the current flow run.

    The correlation ID is a string that gets passed from parent to child flow runs
    and can be used to identify flow runs that belong to the same execution graph.
    This is particularly useful for tracking related flows in a distributed system
    or when flows trigger subflows.

    If the flow run is associated with a Submission, the correlation ID will match
    the Submission's correlation_id. See the Submission API documentation for more details:
    `Submission API documentation <https://docs.hyperscience.ai/#submissions>`_.
    """


def triggers_output(*params: str) -> str:
    """:meta private:"""
    param_path = '.'.join(params)
    param_path = f'.{param_path}' if param_path else ''
    return '${triggers.output.result' + param_path + '}'


def system_setting(key: str) -> str:
    """:meta private:"""
    return f'${{system.settings.{key}}}'


def system_secret(key: str) -> str:
    """:meta private:"""
    return f'${{system.secrets.{key}}}'


def icon_path_to_base64(icon_path: str) -> str:
    """
    :meta private:

    Reads an icon file and returns it in "data:mimetype;base64,xxx" form for putting in a manifest
    """
    with open(icon_path, 'rb') as f:
        encoded_icon = base64.b64encode(f.read()).decode('ascii')
    mimetype, _ = mimetypes.guess_type(icon_path)
    icon_base64 = f'data:{mimetype};base64,{encoded_icon}'
    return icon_base64


def str_to_deterministic_uuid_4(value: str) -> uuid.UUID:
    """
    :meta private:

    Generates a deterministic UUID from a given string
    """
    md5_encoded = hashlib.md5(value.encode(encoding='utf-8'))
    md5_hex = md5_encoded.hexdigest()
    return uuid.UUID(hex=md5_hex, version=4)
