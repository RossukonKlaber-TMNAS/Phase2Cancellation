import copy
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from flows_sdk.blocks import IOBlock
from flows_sdk.flows import InputDefinition, Manifest, Parameter, Triggers
from flows_sdk.implementations.idp_v44.additional_blocks.address_parsing import (
    AddressParserSettings,
)
from flows_sdk.implementations.idp_v44.additional_blocks.common_settings import (
    DEFAULT_ORCA_BASE_MODEL_UUID,
    ORCA_1_0_BASE_MODEL_UUID,
)
from flows_sdk.implementations.idp_v44.additional_blocks.file_filter import FileFilterSettings
from flows_sdk.implementations.idp_v44.additional_values import (
    HttpHeaderAuthorizationParams,
    OAuth2AuthorizationParams,
)
from flows_sdk.implementations.idp_v44.idp_blocks.all_settings import Settings
from flows_sdk.implementations.idp_v44.idp_blocks.common_settings import IdpSystemSettings
from flows_sdk.implementations.idp_v44.idp_blocks.custom_types import (
    CustomTypes,
    SingleEntityTargetAccuracy,
)
from flows_sdk.implementations.idp_v44.idp_blocks.defaults import (
    DEFAULT_IDP_CORE_IDENTIFIER,
    DEFAULT_IDP_ORCA_IDENTIFIER,
    DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER,
    DEFAULT_ORCA_QA_FLOW_IDENTIFIER,
    DEFAULT_SUBMISSION_AWARE_ON_ERROR_FLOW_IDENTIFIER,
    EXACT_PERCENT_SCHEMA,
    IDP_CORE_FLOW_ROLE,
    IDP_OUTPUT_ROLE,
)
from flows_sdk.implementations.idp_v44.idp_blocks.document_renderer import DocumentRendererSettings
from flows_sdk.implementations.idp_v44.idp_blocks.document_renderer.settings import (
    DEFAULT_QUALITY,
    INCHES,
    LETTER_HEIGHT_IN_INCHES,
    LETTER_HEIGHT_IN_MM,
    LETTER_WIDTH_IN_INCHES,
    LETTER_WIDTH_IN_MM,
    MILLIMETERS,
    MODE_BW,
    MODE_GRAYSCALE,
    MODE_RGB,
    PDF_MIME_TYPE,
)
from flows_sdk.implementations.idp_v44.idp_blocks.flexible_extraction import (
    FlexibleExtractionSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.flow_inputs import IdpFlowInputs as Inputs
from flows_sdk.implementations.idp_v44.idp_blocks.machine_classification import (
    MachineClassificationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_classification.settings import (
    CONSECUTIVE_PAGE_BEHAVIOR_GROUP_FILE,
    CONSECUTIVE_PAGE_BEHAVIOR_GROUP_PAGES,
    CONSECUTIVE_PAGE_BEHAVIOR_MANUAL,
    CONSECUTIVE_PAGE_BEHAVIOR_SPLIT_PAGES,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_collation import MachineCollationSettings
from flows_sdk.implementations.idp_v44.idp_blocks.machine_identification import (
    MachineIdentificationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_transcription import (
    MachineTranscriptionSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_transcription.settings import (
    FieldTypeByKind,
    FinetuningConfig,
    TranscriptionConfig,
)
from flows_sdk.implementations.idp_v44.idp_blocks.manual_classification import (
    ManualClassificationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.manual_identification import (
    ManualIdentificationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.manual_transcription import (
    ManualTranscriptionSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.orca_extraction import OrcaExtractionSettings
from flows_sdk.implementations.idp_v44.idp_blocks.orca_extraction.settings import (
    ORCA_ENABLE_LOCATION_HINT,
    ORCA_MAX_BOUNDING_BOXES,
    ORCA_MAX_IMAGE_TOKENS,
    ORCA_MAX_NEW_TOKENS,
    ORCA_SLIDING_WINDOW_SIZE,
)
from flows_sdk.implementations.idp_v44.idp_blocks.reprocessing import ReprocessingSettings
from flows_sdk.implementations.idp_v44.idp_blocks.submission_bootstrap import (
    SubmissionBootstrapSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.submission_bootstrap.settings import (
    ABS_ACCOUNT_KEY,
    ABS_MANAGED_IDENTITY,
    ABS_SAS_TOKEN_ONLY,
    ABS_SERVICE_PRINCIPAL,
    DEFAULT_OAUTH_CLIENT_AUTH_METHOD,
    MAX_PAGES_DEFAULT,
    OCS_SECRET_KEY,
    S3_SECRET_KEY,
)
from flows_sdk.implementations.idp_v44.idp_blocks.submission_complete import (
    SubmissionCompleteSettings,
)
from flows_sdk.utils import icon_path_to_base64, workflow_input

BASE_DIR = Path(__file__).parents[0]

# This module contains all default values needed by an IDP flow

# Include all settings, previously exported for backwards compatibility
__all__ = [
    'S3_SECRET_KEY',
    'OCS_SECRET_KEY',
    'DEFAULT_IDP_CORE_IDENTIFIER',
    'DEFAULT_IDP_ORCA_IDENTIFIER',
    'DEFAULT_ORCA_QA_FLOW_IDENTIFIER',
    'DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER',
    'DEFAULT_SUBMISSION_AWARE_ON_ERROR_FLOW_IDENTIFIER',
    'IDP_CORE_FLOW_ROLE',
    'IDP_OUTPUT_ROLE',
    'ABS_SAS_TOKEN_ONLY',
    'ABS_SERVICE_PRINCIPAL',
    'ABS_MANAGED_IDENTITY',
    'ABS_ACCOUNT_KEY',
    'MAX_PAGES_DEFAULT',
    'EXACT_PERCENT_SCHEMA',
    'CONSECUTIVE_PAGE_BEHAVIOR_GROUP_PAGES',
    'CONSECUTIVE_PAGE_BEHAVIOR_SPLIT_PAGES',
    'CONSECUTIVE_PAGE_BEHAVIOR_MANUAL',
    'CONSECUTIVE_PAGE_BEHAVIOR_GROUP_FILE',
    'PDF_MIME_TYPE',
    'INCHES',
    'MILLIMETERS',
    'LETTER_WIDTH_IN_INCHES',
    'LETTER_WIDTH_IN_MM',
    'LETTER_HEIGHT_IN_INCHES',
    'LETTER_HEIGHT_IN_MM',
    'DEFAULT_QUALITY',
    'MODE_BW',
    'MODE_RGB',
    'MODE_GRAYSCALE',
    'ORCA_SLIDING_WINDOW_SIZE',
    'ORCA_MAX_NEW_TOKENS',
    'ORCA_MAX_IMAGE_TOKENS',
    'ORCA_MAX_BOUNDING_BOXES',
    'ORCA_ENABLE_LOCATION_HINT',
    'ORCA_1_0_BASE_MODEL_UUID',
    'DEFAULT_ORCA_BASE_MODEL_UUID',
    'CustomTypes',
    'SingleEntityTargetAccuracy',
    'FinetuningConfig',
    'FieldTypeByKind',
    'TranscriptionConfig',
    'HttpHeaderAuthorizationParams',
    'OAuth2AuthorizationParams',
    'Settings',
    'Inputs',
]

HTTP_SECRET_KEY = 'http_config'
JSON_OUTPUT_ROLE = 'json_output'


class IdentificationSupervisionChoices:
    SUPERVISION_DEFAULT = 0
    SUPERVISION_ALWAYS = 1
    SUPERVISION_AUTOIDENTIFY = 2


@dataclass
class StructuredSamplingRates:
    entry_sampling_rate: float
    checkbox_sampling_rate: float
    signature_sampling_rate: float

    @classmethod
    def single_sampling_rate(cls, sampling_rate: float) -> 'StructuredSamplingRates':
        return cls(
            entry_sampling_rate=sampling_rate,
            checkbox_sampling_rate=sampling_rate,
            signature_sampling_rate=sampling_rate,
        )


@dataclass
class TranscriptionQaConfigData:
    auto_qa_sampling_rate_enabled: bool
    structured_sampling_rates: StructuredSamplingRates
    semi_structured_sampling_rate: float
    exclude_auto_transcribe_fields_from_qa: bool


@dataclass
class QaConfigData:
    field_id_qa_enabled: bool
    field_id_qa_sampling_ratio: float
    nlc_qa_sampling_ratio: float
    transcription_qa: TranscriptionQaConfigData | None
    table_cell_transcription_qa_sample_rate: float | None
    table_id_qa_enabled: bool = True
    table_id_qa_sampling_ratio: float = 0.05


@dataclass
class MachineClassificationConfig:
    nlc_enabled: bool
    nlc_target_accuracy: float
    vpc_registration_threshold: float
    layout_id_dealbreaker: bool | None = False
    layout_id_dealbreaker_bypass: bool | None = False


@dataclass
class SupervisionConfig:
    task_restrictions: list[str]


@dataclass
class ManualTranscriptionConfig(SupervisionConfig):
    supervision_transcription_masking: bool
    table_output_manual_review: bool
    always_supervise_blank_cells: bool


@dataclass
class ManualIdentificationConfig(SupervisionConfig):
    pass


@dataclass
class FlexibleExtractionConfig(SupervisionConfig):
    supervision_transcription_masking: bool
    show_machine_predictions: bool
    searchable_pages: bool


@dataclass
class DocumentRenderingConfig:
    quality: int
    mime_type: str
    unit: str
    enabled: bool
    height: float | None
    width: float | None
    mode: str | None
    searchable_pdf_enabled: bool = False


@dataclass
class FileFilterConfig:
    filter_type: Literal['ALL_FILES', 'IMAGES_ONLY']
    minimum_image_width: int | None
    minimum_image_height: int | None
    minimum_file_size_kb: float | None
    file_extensions_action: Literal['NONE', 'ALLOW', 'DENY']
    file_extensions: list | None
    file_extensions_other: str | None


@dataclass
class OrcaConfig:
    orca_use_live_model: bool | str | None
    orca_base_model_uuid: str | None
    orca_type: Literal['orca', 'orca_awq']
    orca_sliding_window_size: int
    orca_max_new_tokens: int
    # @deprecated since v44.0; will be removed in v47.0. Superseded by
    # orca_max_tokens_per_image.
    orca_max_image_tokens: int | None
    # Interpreted against the selected model's own vision grid; None lets the model choose.
    orca_max_tokens_per_image: int | None
    orca_max_num_bboxes: int
    orca_target_accuracy: float
    orca_qa_flow_identifier: str | None
    orca_qa_sample_rate: float
    orca_qa_task_restrictions: list[str]
    orca_enable_location_hint: bool = ORCA_ENABLE_LOCATION_HINT


@dataclass
class IdpWorkflowConfig:
    """
    Convenience dataclass outlining all flow-level config values for IDP.
    """

    # Workflow level configs
    rotation_correction_enabled: bool
    document_grouping_logic: str
    qa_config: QaConfigData
    manual_document_organization_enabled: bool

    # Transcription settings
    transcription_automation_training: bool
    transcription_training_legibility_period: int
    transcription_model: str
    manual_transcription_enabled: bool
    finetuning_only_trained_layouts: bool
    flex_confidence_boosting_enabled: bool
    improved_transcription_threshold_accuracy: bool
    structured_text: TranscriptionConfig
    semi_structured_text: TranscriptionConfig
    semi_structured_table: TranscriptionConfig
    structured_checkbox: TranscriptionConfig
    structured_signature: TranscriptionConfig
    semi_structured_checkbox: TranscriptionConfig

    # Identification settings
    field_id_target_accuracy: float
    table_id_target_accuracy: float

    manual_field_id_enabled: bool

    machine_classification_config: MachineClassificationConfig
    manual_transcription_config: ManualTranscriptionConfig
    manual_identification_config: ManualIdentificationConfig
    flexible_extraction_config: FlexibleExtractionConfig

    # Document rendering settings
    document_rendering: DocumentRenderingConfig

    # File Filter settings
    file_filter: FileFilterConfig

    # ORCA settings
    orca: OrcaConfig

    notification_workflow_initialization: str | None = None
    notification_workflow_classification: str | None = None
    notification_workflow_identification: str | None = None
    notification_workflow_transcription: str | None = None
    notification_workflow_flexible_extraction: str | None = None
    field_transcription_target_accuracies: list[SingleEntityTargetAccuracy] | None = None
    identification_target_accuracies: list[SingleEntityTargetAccuracy] | None = None

    submission_bootstrap_max_number_pages_enabled: bool = False
    submission_bootstrap_max_number_pages: int | None = None
    submission_bootstrap_s3_config: str | None = None
    # @deprecated since v43.1; will be removed in v46.0.
    submission_bootstrap_ocs_config: str | None = None
    submission_bootstrap_oauth_token_url: str | None = None
    submission_bootstrap_oauth_client_id: str | None = None
    submission_bootstrap_oauth_client_secret: str | None = None
    submission_bootstrap_oauth_scope: str | None = None
    submission_bootstrap_oauth_client_auth_method: str | None = DEFAULT_OAUTH_CLIENT_AUTH_METHOD


def get_idp_wf_inputs(idp_wf_config: IdpWorkflowConfig) -> dict[str, Any]:
    """
    A helper function that maps the values provided by an ``IdpWorkflowConfig`` to their
    corresponding IDP keys.

    :param idp_wf_config: with static values to be filled.
    :return: a dictionary with filled static values, compatible with IDP flows.

    Example usage with default values::

        flow = Flow(
            input=get_idp_wf_inputs(get_idp_wf_config()),
            ...
        )

    Example usage::

        Example usage when instantiating an IDP flow with custom parameters::

        flow = Flow(
            input=get_idp_wf_inputs({an instance of IdpWorkflowConfig}),
            ...
        )
    """
    transcription_qa = idp_wf_config.qa_config.transcription_qa
    return {
        # this field needs to exist for releases to be assigned to this flow
        **IdpSystemSettings.create(
            layout_release_uuid=workflow_input(IdpSystemSettings.LayoutReleaseUuid)
        ),
        **Inputs.create(),
        **SubmissionBootstrapSettings.create(
            notification_workflow=idp_wf_config.notification_workflow_initialization,
            max_number_of_pages_enabled=idp_wf_config.submission_bootstrap_max_number_pages_enabled,
            max_number_of_pages=idp_wf_config.submission_bootstrap_max_number_pages,
            s3_config=idp_wf_config.submission_bootstrap_s3_config,
            ocs_config=idp_wf_config.submission_bootstrap_ocs_config,
            oauth_token_url=idp_wf_config.submission_bootstrap_oauth_token_url,
            oauth_client_id=idp_wf_config.submission_bootstrap_oauth_client_id,
            oauth_client_secret=idp_wf_config.submission_bootstrap_oauth_client_secret,
            oauth_client_auth_method=(idp_wf_config.submission_bootstrap_oauth_client_auth_method),
            oauth_scope=idp_wf_config.submission_bootstrap_oauth_scope,
        ),
        **MachineClassificationSettings.create(
            structured_layout_match_threshold=(
                idp_wf_config.machine_classification_config.vpc_registration_threshold
            ),
            layout_id_dealbreaker=idp_wf_config.machine_classification_config.layout_id_dealbreaker,
            layout_id_dealbreaker_bypass=(
                idp_wf_config.machine_classification_config.layout_id_dealbreaker_bypass
            ),
            semi_structured_classification=idp_wf_config.machine_classification_config.nlc_enabled,
            semi_structured_target_accuracy=(
                idp_wf_config.machine_classification_config.nlc_target_accuracy
            ),
            semi_structured_doc_grouping_logic=idp_wf_config.document_grouping_logic,
            rotation_correction_enabled=idp_wf_config.rotation_correction_enabled,
            mobile_processing_enabled=False,
            file_transcription_enabled=False,
            manual_classification_enabled=idp_wf_config.manual_document_organization_enabled,
        ),
        **ManualClassificationSettings.create(
            manual_classification_enabled=idp_wf_config.manual_document_organization_enabled,
            notification_workflow=idp_wf_config.notification_workflow_classification,
            structured_layout_match_threshold=(
                idp_wf_config.machine_classification_config.vpc_registration_threshold
            ),
        ),
        **MachineIdentificationSettings.create(
            field_id_target_accuracy=idp_wf_config.field_id_target_accuracy,
            table_id_target_accuracy=idp_wf_config.table_id_target_accuracy,
            id_target_accuracies=idp_wf_config.identification_target_accuracies,
            manual_id_enabled=idp_wf_config.manual_field_id_enabled,
        ),
        **ManualIdentificationSettings.create(
            manual_id_enabled=idp_wf_config.manual_field_id_enabled,
            notification_workflow=idp_wf_config.notification_workflow_identification,
        ),
        **MachineTranscriptionSettings.create(
            transcription_model=idp_wf_config.transcription_model,
            target_accuracies=idp_wf_config.field_transcription_target_accuracies or [],
            finetuning_only_trained_layouts=idp_wf_config.finetuning_only_trained_layouts,
            manual_transcription_enabled=idp_wf_config.manual_transcription_enabled,
            always_supervise_blank_cells=(
                idp_wf_config.manual_transcription_config.always_supervise_blank_cells
            ),
            structured_training_enabled=idp_wf_config.transcription_automation_training,
            structured_training_period=idp_wf_config.transcription_training_legibility_period,
            structured_improved_threshold_accuracy=(
                idp_wf_config.improved_transcription_threshold_accuracy
            ),
            structured_text_config=idp_wf_config.structured_text,
            structured_checkbox_config=idp_wf_config.structured_checkbox,
            structured_signature_config=idp_wf_config.structured_signature,
            semi_structured_training_enabled=(
                idp_wf_config.transcription_automation_training
                or idp_wf_config.flex_confidence_boosting_enabled
            ),
            semi_structured_training_period=idp_wf_config.transcription_training_legibility_period,
            semi_structured_improved_threshold_accuracy=(
                idp_wf_config.improved_transcription_threshold_accuracy
            ),
            semi_structured_field_text_config=idp_wf_config.semi_structured_text,
            semi_structured_table_text_config=idp_wf_config.semi_structured_table,
            semi_structured_checkbox_config=idp_wf_config.semi_structured_checkbox,
        ),
        **ManualTranscriptionSettings.create(
            manual_transcription_enabled=idp_wf_config.manual_transcription_enabled,
            notification_workflow=idp_wf_config.notification_workflow_transcription,
            task_restrictions=idp_wf_config.manual_transcription_config.task_restrictions,
            supervision_transcription_masking=(
                idp_wf_config.manual_transcription_config.supervision_transcription_masking
            ),
            table_output_manual_review=(
                idp_wf_config.manual_transcription_config.table_output_manual_review
            ),
        ),
        **FlexibleExtractionSettings.create(
            notification_workflow=idp_wf_config.notification_workflow_flexible_extraction,
            task_restrictions=idp_wf_config.flexible_extraction_config.task_restrictions,
            supervision_transcription_masking=(
                idp_wf_config.flexible_extraction_config.supervision_transcription_masking
            ),
            show_machine_predictions=(
                idp_wf_config.flexible_extraction_config.show_machine_predictions
            ),
            searchable_pages=idp_wf_config.flexible_extraction_config.searchable_pages,
        ),
        **ReprocessingSettings.create(
            reprocessing_enabled=True,
        ),
        **DocumentRendererSettings.create(
            enabled=idp_wf_config.document_rendering.enabled,
            mime_type=idp_wf_config.document_rendering.mime_type,
            unit=idp_wf_config.document_rendering.unit,
            width=idp_wf_config.document_rendering.width,
            height=idp_wf_config.document_rendering.height,
            quality=idp_wf_config.document_rendering.quality,
            mode=idp_wf_config.document_rendering.mode,
            searchable_pdf_enabled=idp_wf_config.document_rendering.searchable_pdf_enabled,
        ),
        **SubmissionCompleteSettings.create(
            nlc_qa_sample_rate=idp_wf_config.qa_config.nlc_qa_sampling_ratio,
            field_id_qa_enabled=idp_wf_config.qa_config.field_id_qa_enabled,
            field_id_qa_sample_rate=idp_wf_config.qa_config.field_id_qa_sampling_ratio,
            table_id_qa_enabled=True,
            table_id_qa_sample_rate=0.05,
            field_transcr_qa_enabled=transcription_qa is not None,
            transcr_auto_qa_sampling_enabled=(
                transcription_qa is not None and transcription_qa.auto_qa_sampling_rate_enabled
            ),
            field_transcr_structured_text_qa_sample_rate=(
                transcription_qa.structured_sampling_rates.entry_sampling_rate
                if transcription_qa is not None
                else None
            ),
            field_transcr_structured_checkbox_qa_sample_rate=(
                transcription_qa.structured_sampling_rates.checkbox_sampling_rate
                if transcription_qa is not None
                else None
            ),
            field_transcr_structured_signature_qa_sample_rate=(
                transcription_qa.structured_sampling_rates.signature_sampling_rate
                if transcription_qa is not None
                else None
            ),
            field_transcr_semi_structured_field_qa_sample_rate=(
                transcription_qa.semi_structured_sampling_rate
                if transcription_qa is not None
                else None
            ),
            field_transcr_exclude_auto_transcribe_fields_from_qa=(
                transcription_qa.exclude_auto_transcribe_fields_from_qa
                if transcription_qa is not None
                else False
            ),
            table_transcr_qa_enabled=True,
            table_transcr_qa_sample_rate=0.05,
        ),
        **FileFilterSettings.create(
            filter_type=idp_wf_config.file_filter.filter_type,
            minimum_image_width=idp_wf_config.file_filter.minimum_image_width,
            minimum_image_height=idp_wf_config.file_filter.minimum_image_height,
            minimum_file_size_kb=idp_wf_config.file_filter.minimum_file_size_kb,
            file_extensions_action=idp_wf_config.file_filter.file_extensions_action,
            file_extensions=idp_wf_config.file_filter.file_extensions,
            file_extensions_other=idp_wf_config.file_filter.file_extensions_other,
        ),
        **OrcaExtractionSettings.create(
            orca_type=idp_wf_config.orca.orca_type,
            orca_use_live_model=idp_wf_config.orca.orca_use_live_model,
            base_model_uuid=idp_wf_config.orca.orca_base_model_uuid,
            target_accuracy=idp_wf_config.orca.orca_target_accuracy,
            sliding_window_size=idp_wf_config.orca.orca_sliding_window_size,
            max_new_tokens=idp_wf_config.orca.orca_max_new_tokens,
            max_image_tokens=idp_wf_config.orca.orca_max_image_tokens,
            max_tokens_per_image=idp_wf_config.orca.orca_max_tokens_per_image,
            max_num_bboxes=idp_wf_config.orca.orca_max_num_bboxes,
            enable_location_hint=idp_wf_config.orca.orca_enable_location_hint,
        ),
        Settings.OrcaQaFlowIdentifier: idp_wf_config.orca.orca_qa_flow_identifier,
        Settings.OrcaQaSampleRate: idp_wf_config.orca.orca_qa_sample_rate,
        Settings.OrcaQaTaskRestrictions: idp_wf_config.orca.orca_qa_task_restrictions,
    }


def get_idp_wf_config() -> IdpWorkflowConfig:
    """
    A helper function that instantiates an ``IdpWorkflowConfig`` pre-filled with default values.
    ``IdpWorkflowConfig`` is the container class for defining flow-level settings.

    :return: a valid, fully constructed IdpWorkflowConfig instance

    Example usage when instantiating an IDP flow::

        flow = Flow(
            input=get_idp_wf_inputs(get_idp_wf_config()),
            ...
        )
    """
    return IdpWorkflowConfig(
        submission_bootstrap_max_number_pages_enabled=False,
        submission_bootstrap_max_number_pages=100,
        manual_document_organization_enabled=False,
        rotation_correction_enabled=True,
        field_id_target_accuracy=0.95,
        table_id_target_accuracy=0.96,
        transcription_automation_training=False,
        transcription_training_legibility_period=30,
        flex_confidence_boosting_enabled=False,
        improved_transcription_threshold_accuracy=True,
        structured_text=TranscriptionConfig(
            min_samples=5000,
            max_samples=50000,
            target_accuracy=0.95,
            confidence_threshold=0.52,
            acceptable_confidence=0.1,
        ),
        semi_structured_text=TranscriptionConfig(
            min_samples=2000,
            max_samples=50000,
            target_accuracy=0.95,
            confidence_threshold=0.52,
            acceptable_confidence=0.1,
        ),
        semi_structured_table=TranscriptionConfig(
            min_samples=2000,
            max_samples=50000,
            target_accuracy=0.95,
            confidence_threshold=0.52,
            acceptable_confidence=0.1,
        ),
        structured_checkbox=TranscriptionConfig(
            min_samples=2000,
            max_samples=50000,
            target_accuracy=0.95,
            confidence_threshold=0.56,
            acceptable_confidence=0.5,
        ),
        structured_signature=TranscriptionConfig(
            min_samples=2000,
            max_samples=50000,
            target_accuracy=0.95,
            confidence_threshold=0.99,
            acceptable_confidence=0.5,
        ),
        semi_structured_checkbox=TranscriptionConfig(
            min_samples=2000,
            max_samples=50000,
            target_accuracy=0.95,
            confidence_threshold=0.56,
            acceptable_confidence=0.5,
        ),
        manual_field_id_enabled=True,
        manual_transcription_enabled=True,
        machine_classification_config=MachineClassificationConfig(
            nlc_enabled=True, nlc_target_accuracy=0.99, vpc_registration_threshold=0.6
        ),
        document_grouping_logic='group_pages',
        flexible_extraction_config=FlexibleExtractionConfig(
            task_restrictions=[],
            supervision_transcription_masking=True,
            show_machine_predictions=True,
            searchable_pages=False,
        ),
        manual_transcription_config=ManualTranscriptionConfig(
            task_restrictions=[],
            supervision_transcription_masking=True,
            table_output_manual_review=False,
            always_supervise_blank_cells=True,
        ),
        manual_identification_config=ManualIdentificationConfig(task_restrictions=[]),
        qa_config=QaConfigData(
            field_id_qa_sampling_ratio=0.05,
            field_id_qa_enabled=True,
            nlc_qa_sampling_ratio=0.05,
            table_id_qa_enabled=True,
            table_id_qa_sampling_ratio=0.05,
            table_cell_transcription_qa_sample_rate=0.05,
            transcription_qa=TranscriptionQaConfigData(
                auto_qa_sampling_rate_enabled=False,
                structured_sampling_rates=StructuredSamplingRates.single_sampling_rate(0.05),
                semi_structured_sampling_rate=0.05,
                exclude_auto_transcribe_fields_from_qa=False,
            ),
        ),
        transcription_model='IDP',
        finetuning_only_trained_layouts=True,
        document_rendering=DocumentRenderingConfig(
            height=11,
            width=8.5,
            quality=50,
            mime_type='application/pdf',
            unit=INCHES,
            mode='RGB',
            enabled=False,
            searchable_pdf_enabled=False,
        ),
        file_filter=FileFilterConfig(
            filter_type='ALL_FILES',
            minimum_image_width=None,
            minimum_image_height=None,
            minimum_file_size_kb=None,
            file_extensions_action='NONE',
            file_extensions=None,
            file_extensions_other=None,
        ),
        orca=OrcaConfig(
            orca_use_live_model=False,
            orca_base_model_uuid=None,
            orca_type='orca',
            orca_sliding_window_size=ORCA_SLIDING_WINDOW_SIZE,
            orca_max_new_tokens=ORCA_MAX_NEW_TOKENS,
            # Both unset so the per-image token budget follows the selected base model.
            orca_max_image_tokens=None,
            orca_max_tokens_per_image=None,
            orca_max_num_bboxes=ORCA_MAX_BOUNDING_BOXES,
            orca_enable_location_hint=ORCA_ENABLE_LOCATION_HINT,
            orca_target_accuracy=0.95,
            # Default QA Flow Identifier Should stay None until FLOWS-5530 is fixed
            orca_qa_flow_identifier=None,
            orca_qa_sample_rate=0.05,
            orca_qa_task_restrictions=[],
        ),
    )


class ApiParams:
    Restrictions = 'restrictions'
    GoalTimeRule = 'goal_time_rule'
    LayoutUuid = 'layout_uuid'
    FallbackLayoutUuid = 'fallback_layout_uuid'
    SourceRoutingTagCommaSeparated = 'source_routing_tag_comma_separated'
    MachineOnly = 'machine_only'
    SingleDocumentPerPage = 'single_document_per_page'
    Cases = 'cases'


class IDPTriggers(Triggers):
    """
    An adapter class making it easier to instantiate :py:class:`flows_sdk.flows.Triggers` for
    IDP flows.
    In particular, provides defaults for some fields (e.g. title, description, reference_name)
    and defines `api_params_manifest` with IDP specific parameters.

    :param blocks: :py:class:`flows_sdk.blocks.IOBlock` s to be included as triggers for
        an IDP Flow.
        Optional, defaults to an empty list.

    Example usage when instantiating an IDP flow::

        folder_listener = IOBlock(...)
        flow = Flow(
            triggers=IDPTriggers([folder_listener]),
            ...
        )
    """

    # mypy pidantic errors out on redefined init
    # issue: https://github.com/pydantic/pydantic/issues/4113
    def __init__(self, blocks: Sequence[IOBlock] | None = None) -> None:
        blocks = blocks or []

        super().__init__(
            title='Inputs',
            description='Ingest submission data from an external source, '
            'and trigger submission processing',
            reference_name='triggers',
            blocks=blocks,
            api_params_manifest=InputDefinition(
                input=[
                    Parameter(
                        name=ApiParams.Restrictions,
                        type='TaskRestrictions',
                        title='Task Restrictions',
                        description=(
                            'Supervision tasks for submissions created via this input '
                            'connection will only be accessible to users associated with '
                            'the specified Task Restrictions.'
                        ),
                        optional=True,
                        value=[],
                    ),
                    Parameter(
                        name=ApiParams.GoalTimeRule,
                        type='GoalTimeRule',
                        title='Submission Processing Deadline',
                        description=(
                            'Dynamic processing deadline for submissions '
                            'coming via this connection.'
                            'This will impact how manual tasks get prioritized in the Work Queue.'
                        ),
                        optional=True,
                        value=None,
                    ),
                    Parameter(
                        name=ApiParams.LayoutUuid,
                        type='LayoutUUID',
                        title='Layout UUID',
                        description=(
                            "The UUID of a Semi-Structured layout that's part of an "
                            'active release can be specified. When specified, all '
                            'submitted pages in the request will be matched to it and '
                            'machine page classification will be skipped.'
                        ),
                        optional=True,
                        value=None,
                    ),
                    Parameter(
                        name=ApiParams.FallbackLayoutUuid,
                        type='LayoutUUID',
                        title='Fallback Layout UUID',
                        description=(
                            "The UUID of a Semi-Structured layout that's part of an "
                            'active release can be specified. When specified only pages '
                            'that are not matched to a live Structured layout in the '
                            'request will be matched to the specified Semi-structured '
                            'layout.'
                        ),
                        optional=True,
                        value=None,
                    ),
                    Parameter(
                        name=ApiParams.SourceRoutingTagCommaSeparated,
                        type='string',
                        title='Source Tags',
                        description=(
                            'Comma-separated values. Source tags can be used to filter what '
                            'status change notifications are sent to each output connection.'
                        ),
                        optional=True,
                        value=None,
                    ),
                    Parameter(
                        name=ApiParams.MachineOnly,
                        type='boolean',
                        title='Machine Only',
                        description='Process the submission using an automated flow only.',
                        value=False,
                    ),
                    Parameter(
                        name=ApiParams.SingleDocumentPerPage,
                        type='boolean',
                        title='Single Document Per Page',
                        description=(
                            'This parameter only applies to semi-structured documents. '
                            'Force the creation of separate documents for each uploaded '
                            'page in each file. For example, a single PNG image will '
                            'produce a single document while a 3-page PDF file will '
                            'always produce 3 separate documents under this scheme. '
                            "It takes precedence over the flow's settings. "
                            'By default, PNG and JPG files that match the same layout '
                            'are combined into one document while only consecutive pages '
                            'in a single PDF, TFF, or XPS matching the same layout will '
                            'be grouped into the same document.'
                        ),
                        value=False,
                    ),
                ],
                ui={
                    'groups': [
                        {
                            'title': 'Submission Processing Settings',
                            'fields': [
                                ApiParams.Restrictions,
                                ApiParams.GoalTimeRule,
                                ApiParams.LayoutUuid,
                                ApiParams.FallbackLayoutUuid,
                                ApiParams.SourceRoutingTagCommaSeparated,
                                ApiParams.MachineOnly,
                                ApiParams.SingleDocumentPerPage,
                            ],
                        }
                    ]
                },
            ),
        )


class IDPWrapperManifest(Manifest):
    """
    An adapter class making it easier to instantiate :py:class:`flows_sdk.flows.Manifest` for
    IDP wrapper flows.
    In particular, provides defaults for some fields (e.g. roles)
    but more importantly, defines all :py:class:`flows_sdk.flows.Parameter` that construct the
    Flow inputs and their UI representation (left-hand side menu in Flow studio).


    :param flow_identifier: A system-wide unique identifier for :py:class:`flows_sdk.flows.Flow`

    Example usage when instantiating an IDP flow::

        flow = Flow(
            manifest=IDPWrapperManifest(flow_identifier='FLOW_IDENTIFIER'),
            ...
        )
    """

    # mypy pidantic errors out on redefined init
    # issue: https://github.com/pydantic/pydantic/issues/4113
    def __init__(self, flow_identifier: str) -> None:
        super().__init__(
            identifier=flow_identifier,
            roles=['idp'],
            input=[
                Parameter(
                    name=Settings.LayoutReleaseUuid, type='ReleaseUUID', title='Layout Release'
                ),
            ],
        )


class IDPCoreManifest(Manifest):
    """
    An adapter class making it easier to instantiate :py:class:`flows_sdk.flows.Manifest` for
    IDP Core flows.
    In particular, provides defaults for some fields (e.g. roles, output)
    but more importantly, defines all :py:class:`flows_sdk.flows.Parameter` that construct the
    Flow inputs and their UI representation (left-hand side menu in Flow studio).


    :param flow_identifier: A system-wide unique identifier for :py:class:`flows_sdk.flows.Flow`
    :param roles: 'read_only', 'supporting' and 'idp_core' are the default roles of every subflow
        that can replace the default IDP_CORE subflow inside the top-level IDP flows.
        'supporting' and 'idp_core' are mandatory roles that are necessary for all IDP Core flows.
        'supporting' ensures that the subflow will be auto-deployed together with the
        top-level IDP flow.
        'idp_core' ensures that this subflow can be selected in the UI in dropdowns which allow
        picking an alternative subflow to the default IDP_CORE subflow. If you are implementing
        a subflow that is not supposed to be a drop-in replacement for IDP_CORE, you will have to
        subclass or implement your own version of IDPCoreManifest class in order
        to remove the `idp_core` role.

    Example usage when instantiating an IDP flow::

        flow = Flow(
            manifest=IDPCoreManifest(flow_identifier='FLOW_IDENTIFIER'),
            ...
        )
    """

    def __init__(self, flow_identifier: str, roles: list[str] | None = None) -> None:
        if not roles:
            roles = ['read_only', 'supporting', IDP_CORE_FLOW_ROLE]
        mandatory_roles = ['supporting', IDP_CORE_FLOW_ROLE]
        roles = roles + [role for role in mandatory_roles if role not in roles]

        flow_level_settings = {IdpSystemSettings.LayoutReleaseUuid}

        super().__init__(
            identifier=flow_identifier,
            roles=roles,
            enable_overrides=True,
            input=copy.deepcopy(
                [
                    *Inputs.get_all_manifest_params(),
                    *Settings.get_all_manifest_params(),
                ]
            ),
            ui={
                'icon': icon_path_to_base64(str(BASE_DIR / 'icon.png')),
                'groups': [
                    {
                        'title': 'ORCA',
                        'fields': [
                            *OrcaExtractionSettings.get_all(exclude=flow_level_settings),
                            Settings.OrcaQaFlowIdentifier,
                            Settings.OrcaQaTaskRestrictions,
                            Settings.OrcaQaSampleRate,
                        ],
                    },
                    {
                        'title': 'File Filter',
                        'fields': FileFilterSettings.get_all(exclude=flow_level_settings),
                    },
                    {
                        'title': 'Submission Bootstrap',
                        'fields': SubmissionBootstrapSettings.get_all(exclude=flow_level_settings),
                    },
                    {
                        'title': 'Collation',
                        'fields': MachineCollationSettings.get_all(exclude=flow_level_settings),
                    },
                    {
                        'title': 'Classification',
                        'fields': [
                            *MachineClassificationSettings.get_all(
                                exclude={
                                    *flow_level_settings,
                                    MachineClassificationSettings.ManualNlcEnabled,
                                }
                            ),
                            *ManualClassificationSettings.get_all(
                                exclude={
                                    *flow_level_settings,
                                    ManualClassificationSettings.StructuredLayoutMatchThreshold,
                                }
                            ),
                            *SubmissionCompleteSettings.get_classification_settings(),
                        ],
                    },
                    {
                        'title': 'Identification',
                        'fields': [
                            *MachineIdentificationSettings.get_all(
                                exclude={
                                    *flow_level_settings,
                                    MachineIdentificationSettings.ManualFieldIdEnabled,
                                    MachineIdentificationSettings.ForceRequiredEntriesToSV,
                                }
                            ),
                            *ManualIdentificationSettings.get_all(exclude=flow_level_settings),
                            *SubmissionCompleteSettings.get_identification_settings(),
                        ],
                    },
                    {
                        'title': 'General Transcription',
                        'fields': [
                            *MachineTranscriptionSettings.get_general_settings(
                                exclude={
                                    *flow_level_settings,
                                    MachineTranscriptionSettings.ManualTranscriptionEnabled,
                                    MachineTranscriptionSettings.ManualTranscriptionAlwaysSuperviseBlankCells,  # noqa
                                }
                            ),
                            *ManualTranscriptionSettings.get_all(exclude=flow_level_settings),
                            *SubmissionCompleteSettings.get_transcription_settings(),
                        ],
                    },
                    {
                        'title': 'Structured Document Transcription',
                        'fields': MachineTranscriptionSettings.get_structured_settings(),
                    },
                    {
                        'title': 'Semi-Structured Document Transcription',
                        'fields': MachineTranscriptionSettings.get_semi_structured_settings(),
                    },
                    {
                        'title': 'Address Parsing',
                        'fields': AddressParserSettings.get_all(exclude=flow_level_settings),
                    },
                    {
                        'title': 'Flexible Extraction',
                        'fields': FlexibleExtractionSettings.get_all(exclude=flow_level_settings),
                    },
                    {
                        'title': 'Document Rendering',
                        'fields': DocumentRendererSettings.get_all(exclude=flow_level_settings),
                    },
                    {
                        'title': 'Reprocessing',
                        'fields': ReprocessingSettings.get_all(exclude=flow_level_settings),
                    },
                ],
            },
            output=[
                Parameter(
                    name='submission',
                    type='Submission',
                    title='Submission',
                    description='The processed submission',
                )
            ],
        )
