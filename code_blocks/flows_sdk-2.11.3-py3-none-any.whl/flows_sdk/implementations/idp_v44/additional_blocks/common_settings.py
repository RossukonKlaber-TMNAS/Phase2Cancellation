from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.licensing.gated_features import LicenseGatedFeature
from flows_sdk.implementations.idp_v44.licensing.licensing import (
    FeatureGatingCommonDependencies,
    build_license_gating_validation_context,
)

ORCA_1_0_BASE_MODEL_UUID = '14554188-cf8e-4f10-9057-d1df2f710072'
# From form_extraction.base_models.registry (ORCA_2).
ORCA_2_BASE_MODEL_UUID = 'ef3863d8-87d0-4528-999a-00b52fa72cd0'
DEFAULT_ORCA_BASE_MODEL_UUID = ORCA_1_0_BASE_MODEL_UUID


ORCA_ENABLED_DEPENDENCIES = [
    Dependency(
        condition={'properties': {'orca_enabled': {'const': False}}},
        override={'ui': {'hide_and_retain': True}, 'optional': True},
    ),
    *FeatureGatingCommonDependencies.LargeLanguageModels,
]


def get_orca_base_model_uuid_param(
    param_name: str,
    description: str | None = None,
    additional_dependencies: list[Dependency] | None = None,
) -> Parameter:
    return Parameter(
        name=param_name,
        type='string',
        title='ORCA Base Model',
        description=description,
        optional=True,
        dependencies=[
            # Skip validation when ORCA is disabled and LLM Feature is missing
            Dependency(
                condition={
                    'properties': {
                        'orca_enabled': {'const': True},
                        **build_license_gating_validation_context(
                            condition={
                                'contains': {
                                    'const': LicenseGatedFeature.LARGE_LANGUAGE_MODELS.value
                                }
                            }
                        ),
                    }
                },
                override={
                    'optional': False,
                    'type': 'MLModelUUID',
                    'type_spec': {'model_type': 'orca'},
                },
            ),
            *ORCA_ENABLED_DEPENDENCIES,
            *(additional_dependencies or []),
        ],
    )


class OrcaSettings(BaseInputs):
    OrcaEnabled = 'orca_enabled'
    OrcaType = 'orca_type'

    @classmethod
    def create(cls, orca_type: str) -> dict[str, Any]:
        return {
            cls.OrcaType: orca_type,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.OrcaEnabled,
                type='boolean',
                value=False,
                ui={'hidden': True},
                title='ORCA Enabled',
            ),
            Parameter(
                name=cls.OrcaType,
                type='string',
                schema={
                    'type': 'string',
                    'oneOf': [
                        {'title': 'ORCA', 'const': 'orca'},
                        {'title': 'ORCA-AWQ', 'const': 'orca_awq'},
                    ],
                },
                title='ORCA Type',
                value='orca',
                ui={'hidden': True},
                dependencies=ORCA_ENABLED_DEPENDENCIES,
            ),
        ]
