from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v44.additional_blocks.address_parsing.settings import (
    AddressParserSettings,
)
from flows_sdk.utils import workflow_input


class AddressParserBlock(Block):
    """
    Address Parser Block parses address-typed fields into structured components (street, city,
    zip, etc.), either locally (usaddress for US addresses, deepparse for international
    addresses) or by routing them through a configured third-party address API.

    Mandatory parameters:

    :param transcriptions: list of
        :py:class:`Transcription <flows_sdk.implementations.idp_v44.contracts.Transcription>` objects that
        need to be parsed

    Optional Parameters:

    :param address_parsing_enabled: flag to enable or disable address parsing,
        defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
    :param address_parser_api_provider: selects the address parsing provider
        ('none' / 'google' / 'smarty' / 'geoapify'),
        defaults to workflow_input(AddressParserSettings.ApiProvider)
    :param address_parser_api_key: API key for the configured provider,
        defaults to workflow_input(AddressParserSettings.ApiKey)
    :param address_parser_api_options: provider-specific JSON options,
        defaults to workflow_input(AddressParserSettings.ApiOptions)
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param title: overrides the block's default title shown in Flow Studio,
        defaults to 'Address Parser'
    :param description: overrides the block's default description shown in Flow Studio,
        defaults to 'Parses address-typed transcriptions into structured components'

    Output:
    The block returns an object with the following keys:

    * `parsed_addresses`: list of
      :py:class:`AddressData <flows_sdk.implementations.idp_v44.contracts.AddressData>` objects

    Example usage::

        address_parser = AddressParserBlock(
            reference_name='address_parser',
            transcriptions=extract_transcriptions.output('transcriptions'),
            address_parser_api_provider='google',
        )
    """

    IDENTIFIER = 'ADDRESS_PARSER_2'

    def __init__(
        self,
        transcriptions: list[dict[str, Any]] | str,
        address_parsing_enabled: bool | str = workflow_input(
            AddressParserSettings.AddressParsingEnabled
        ),
        address_parser_api_provider: str = workflow_input(AddressParserSettings.ApiProvider),
        address_parser_api_key: str | None = workflow_input(AddressParserSettings.ApiKey),
        address_parser_api_options: str | dict | None = workflow_input(
            AddressParserSettings.ApiOptions
        ),
        reference_name: str | None = None,
        title: str = 'Address Parser',
        description: str = 'Parses address-typed transcriptions into structured components',
    ) -> None:
        inputs: dict[str, Any] = {
            'transcriptions': transcriptions,
            AddressParserSettings.AddressParsingEnabled: address_parsing_enabled,
            AddressParserSettings.ApiProvider: address_parser_api_provider,
            AddressParserSettings.ApiKey: address_parser_api_key,
            AddressParserSettings.ApiOptions: address_parser_api_options,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )
