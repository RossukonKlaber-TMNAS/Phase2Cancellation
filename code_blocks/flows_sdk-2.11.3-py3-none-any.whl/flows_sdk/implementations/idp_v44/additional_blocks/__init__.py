from collections.abc import Sequence
from typing import Any

from flows_sdk.blocks import Block, IOBlock, Outputs
from flows_sdk.implementations.idp_v44.additional_blocks.address_parsing import AddressParserBlock
from flows_sdk.implementations.idp_v44.additional_blocks.file_filter import FileFilterBlock
from flows_sdk.implementations.idp_v44.additional_blocks.orca_general_prompting import (
    GeneralPromptingORCABlock,
)
from flows_sdk.implementations.idp_v44.additional_values import (
    DEFAULT_ENTITY_RECOGNITION_PAGE_BATCH_SIZE,
    DEFAULT_ENTITY_RECOGNITION_PAGE_OVERLAP,
    JSON_OUTPUT_ROLE,
    REDACTION_OPAQUE_BOX_MODE,
    REDACTION_SYNTHETIC_DATA_MODE,
    HttpHeaderAuthorizationParams,
    OAuth2AuthorizationParams,
)
from flows_sdk.implementations.idp_v44.idp_blocks.defaults import (
    DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER,
)
from flows_sdk.utils import apply_output_wrapping_mode

__all__ = [
    'JSONOutputsBlock',
    'ImageCorrectionBlock',
    'FullPageTranscriptionBlock',
    'QASchedulerBlock',
    'FullPageTranscriptionQABlock',
    'CustomSupervisionBlock',
    'SoapRequestBlock',
    'BaseHttpRestBlock',
    'HttpRestBlock',
    'HyperscienceRestApiBlock',
    'DatabaseAccessBlock',
    'EntityRecognitionBlock',
    'RedactionBlock',
    'FileFilterBlock',
    'GeneralPromptingORCABlock',
    'ImagesToPrintableFileBlock',
    'VertexAIBlock',
    'AddressParserBlock',
]


class JSONOutputsBlock(Outputs):
    """Output block allows users to send JSON data extracted by an IDP flow to other systems
    for downstream processing
    Mandatory parameters:

    :param inputs: Used by the UI to automatically pre-populate the input of
        newly added blocks. Extended in this class to include ``'enabled': True``
        to visualize an enabled/disabled trigger that is controllable via Flow Studio.

    Usage when parameters are to be defined in Flow Studio::

        outputs = JSONOutputBlock(
            inputs={'result': }
        )
    """

    def __init__(self, inputs: dict[str, Any], blocks: Sequence[IOBlock] | None = None) -> None:
        if not blocks:
            blocks = []

        super().__init__(
            reference_name='json_outputs',
            title='JSON Outputs',
            description='Send JSON submission data to external systems',
            role_filter=[JSON_OUTPUT_ROLE],
            input_template=inputs,
            blocks=blocks,
        )


class ImageCorrectionBlock(Block):
    """
    Image Correction Block rotates and de-skews tilted/skewed images so that they are more
    transcription-friendly.

    Mandatory parameters:

    :param pages: list of :py:class:`Page <flows_sdk.implementations.idp_v44.contracts.Page>` objects
        that need to be image-corrected

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param rotation_correction_enabled: Identifies and corrects the orientation of images.
        Enabled by default.
    :param mobile_processing_enabled: Improves the machine readability of photo captured documents.
        Disabled by default.
    :param language_family: language family to use when performing image correction.
        If not provided, the system will default to `latin`. Language families are single
        word lowercase strings, e.g., `latin`, `arabic`, `korean`, `chinese`.
        You can read more about language families in the
        "Supported Languages" article in the application documentation:
        https://help.hyperscience.ai/v44/docs/supported-languages.
    :param app_metadata: used for capturing information about the flow

    Output:
    The block returns an object with the following keys:

    * `pages`: list of :py:class:`Page <flows_sdk.implementations.idp_v44.contracts.Page>` objects with
      their `corrected_image_uuid` field populated with rotated/de-skewed images.

    Example usage::

        # This is one way to obtain the submission object (using SubmissionBootstrapBlock)
        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

        image_correction_block = ImageCorrectionBlock(
            reference_name='image_correction',
            pages=submission_bootstrap.output('submission.unassigned_pages'),
        )

        # reference to the output of IDPImageCorrectionBlock which can be passed as input to the
        # next block. For more information on output() and output references, please take a look
        # at class Block and its output() method
        output_ref = image_correction_block.output()
    """

    IDENTIFIER = 'IMAGE_CORRECTION_PAGES_2'

    def __init__(
        self,
        pages: list[dict[str, Any]] | str,
        reference_name: str | None = None,
        rotation_correction_enabled: bool = True,
        mobile_processing_enabled: bool = False,
        language_family: str | None = None,
        title: str = 'Image Correction (Pages)',
        description: str = 'Rotate and de-skew documents',
        app_metadata: list[str] | None = None,
    ) -> None:
        inputs: dict[Any, Any] = {
            'pages': pages,
            'rotation_correction_enabled': rotation_correction_enabled,
            'mobile_processing_enabled': mobile_processing_enabled,
            'language_family': language_family,
        }
        if app_metadata is not None:
            inputs['app_metadata'] = app_metadata

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class FullPageTranscriptionBlock(Block):
    """
    Full Page Transcription Block machine-transcribes the provided pages.

    Mandatory parameters:

    :param pages: list of :py:class:`Page <flows_sdk.implementations.idp_v44.contracts.Page>` objects
        that need to be transcribed

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param language_family: language family to use when instantiating the underlying transcription
        model. If not provided, the system will default to `latin`. Language families are single
        word lowercase strings, e.g., `latin`, `arabic`, `korean`, `chinese`.
        You can read more about language families in the
        "Supported Languages" article in the application documentation:
        https://help.hyperscience.ai/v44/docs/supported-languages.
    :param app_metadata: used for capturing information about the flow
    :param rerun_segmentation: Available from V42.3; controls whether segmentation should be
        rerun for already segmented pages.

    Output:
    The block returns an object with the following keys:

    * `pages`: list of :py:class:`Page <flows_sdk.implementations.idp_v44.contracts.Page>` objects with
      their `combined_segments` field populated with the transcription results.

    Example usage::

        # This is one way to obtain the submission object (using SubmissionBootstrapBlock)
        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

        fpt_block = FullPageTranscriptionBlock(
            reference_name='fpt',
            pages=submission_bootstrap.output('submission.unassigned_pages'),
        )

        # reference to the output of FullPageTranscriptionBlock which can be passed as input to the
        # next block. For more information on output() and output references, please take a look at
        # class Block and its output() method
        output_ref = fpt_block.output()
    """

    IDENTIFIER = 'FULL_PAGE_TRANSCRIPTION_PAGES_3'

    def __init__(
        self,
        pages: list[dict[str, Any]] | str,
        reference_name: str | None = None,
        title: str = 'Full Page Transcription (Pages)',
        description: str = 'Transcribes documents',
        language_family: str | None = None,
        app_metadata: list[str] | None = None,
        rerun_segmentation: bool = False,
    ) -> None:
        inputs: dict[Any, Any] = {
            'pages': pages,
            'language_family': language_family,
            'rerun_segmentation': rerun_segmentation,
        }
        if app_metadata is not None:
            inputs['app_metadata'] = app_metadata

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class QASchedulerBlock(Block):
    """
    Available from V41.2

    Schedules Quality Assurance (QA) tasks for a specific workflow.

    This class serves as a specialized block within a flow for scheduling Quality
    Assurance tasks. It ensures the proper configuration and scheduling processes
    for a given workflow instance. It leverages provided data and parameters such
    as identification of the workflow, submission details, QA configuration, and
    optional reprocessing cases.

    Mandatory parameters:

    :param flow_identifier: A unique string identifying the flow to associate this QA
        scheduler with.
    :param submission: A dictionary containing submission details.
        Will be used as payload to trigger
        the target flow to be QA'd.
    :param qa_config: A dictionary containing QA configuration. Will be used as payload to trigger
        the target flow to be QA'd.

    Optional parameters:

    :param is_reprocessing: An optional value indicating whether this block is part of
        a reprocessing workflow. Defaults to False.
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided

    Example usage::

        qa_scheduler = QASchedulerBlock(
            flow_identifier='my_qa_flow',
            submission={'submission_id': 12345, 'data': 'example_data'},
            qa_config={'sample_rate': 0.1, 'language_family': 'latin'},
            is_reprocessing=False,
        )

        # reference to the output of QASchedulerBlock which can be passed
         as input to the next block.
        # For more information on output() and output references, please take a look at class Block
        # and its output() method
        output_ref = qa_scheduler.output()
    """

    IDENTIFIER = 'QA_SCHEDULER'

    def __init__(
        self,
        flow_identifier: str,
        submission: dict[str, Any] | str,
        qa_config: dict[str, Any] | str,
        is_reprocessing: bool | str | None = False,
        reference_name: str | None = None,
    ) -> None:
        inputs: dict[str, Any] = {
            'flow_identifier': flow_identifier,
            'submission': submission,
            'qa_config': qa_config,
            'is_reprocessing': is_reprocessing,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title='QA Scheduler',
            description='Schedules Quality Assurance tasks for a given flow',
        )


class FullPageTranscriptionQABlock(Block):
    """
    Available from V41.2

    Full Page Transcription QA Block performs Quality Assurance on the output of
    Full Page Transcription Block. It samples a percentage of segments for QA
    and allows users to split segments into smaller tokens for easier QA.

    Mandatory parameters:

    :param submission: Submission object
    :param sample_rate: Defines the percentage of segments the system samples
        for Quality Assurance
    :param language_family: Specifies the language family for the class
    :param split_text_segments: Enabling this option splits segments into smaller, more
        manageable tokens for easier QA

    Parameters with defaults:

    :param min_characters_in_segment: Minimum number of characters in a token.
        Defaults to 4. Minimum value is 1, maximum is 100.
    :type min_characters_in_segment: integer
    :param task_restrictions: Defines what users can access tasks created
        by this block. Defaults to None, which is treated as an empty list.
    :type task_restrictions: Optional[TaskRestrictions]
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided

    Example usage::

        full_page_transcription_qa = FullPageTranscriptionQABlock(
            reference_name='full_page_transcription_qa',
            submission=manual_transcription.output('submission'),
            sample_rate=10,
            language_family='latin',
            split_text_segments=True,
            min_characters_in_segment=4,
            task_restrictions=[],
        )

        # reference to the output of FullPageTranscriptionQABlock which can be passed
        as input to the
        # next block. For more information on output() and output references, please take a look
        # at class Block and its output() method
        output_ref = full_page_transcription_qa.output()
    """

    IDENTIFIER = 'FULL_PAGE_TRANSCRIPTION_QA_2'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        sample_rate: int | str,
        language_family: str,
        split_text_segments: bool | str,
        min_characters_in_segment: int | str = 4,
        task_restrictions: list[Any] | str | None = None,
        reference_name: str | None = None,
    ) -> None:
        if task_restrictions is None:
            task_restrictions = []

        inputs: dict[str, Any] = {
            'submission': submission,
            'sample_rate': sample_rate,
            'language_family': language_family,
            'split_text_segments': split_text_segments,
            'min_characters_in_segment': min_characters_in_segment,
            'task_restrictions': task_restrictions,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title='Full Page Transcription QA',
            description='Quality Assurance for Full Page Transcription',
        )


class CustomSupervisionBlock(Block):
    """The CustomSupervisionBlock uses a JSON schema as a form builder to create customer-driven
    UIs for Supervision tasks.

    Mandatory parameters:

    :param submission: Submission object
    :param task_purpose: the custom task name that's given to all supervision tasks that run
        through a particular instance of a custom supervision block. This can be used to filter
        tasks in the task queue.
    :param data: JSON structure that supplies the data used to populate the supervision_template
    :param supervision_template: JSON used for configuration of the Custom Supervision Task.

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param supervision_transcription_masking: Prevents users from inputting invalid
        characters during the Custom Supervision task,
        defaults to True
    :param task_restrictions: Defines what users can access Supervision tasks created
        by this block,
        defaults to []
    :param notification_workflow: Notification flow name to run when the submission
        enters Custom Supervision,
        defaults to IDP_SUBMISSION_NOTIFY_NAME
    :param chat_flow_identifier: Available from V41.2; optional chat flow identifier to be populated
        to enable Document Chat in Custom Supervision
    :param title: UI-visible title of the block. Defaults to 'IDP Custom Supervision'
    :type title: Optional[str]
    :param description: Description of the block. Both useful for documentation purpose and visible
            to users in the Flow studio. Defaults to 'IDP Custom Supervision'
    :type description: Optional[str]

    Example usage::

        custom_supervision = CustomSupervisionBlock(
            reference_name='custom_supervision',
            submission=manual_transcription.output('submission'),
            task_purpose='make_custom_decision',
            supervision_template=[
                {
                    'name': 'three_column_template',
                    'version': '1.0',
                    'thumbnail': {
                        'group_by_document': True,
                        'group_by_case': True,
                    },
                    'action': [
                        {
                            'name': 'my_tab',
                            'display': 'SSN Info',
                            'input': [
                                {
                                    'name': 'ssn_field',
                                    'type': 'transcription',
                                    'data_identifier': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                                    'title': 'SSN',
                                },
                            ],
                            'ui': {
                                'groups': [
                                    {
                                        'title': 'My Group',
                                        'fields': ['ssn_field'],
                                    },
                                ],
                            },
                        },
                    ],
                },
            ],
            data={
                'fields': [
                    {
                        'id': 967,
                        'uuid': 'fe8d4e7a-a82c-448c-85a1-0a3cbbe53b61',
                        'value': '111-22-3333',
                        'page_id': 15,
                        'layout_field_id': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                        'validation_overridden': False,
                        'bounding_box': [
                            0.09360783305186686,
                            0.25792617589433436,
                            0.6358913805295097,
                            0.28862414740388187,
                        ],
                        'occurrence_index': 1,
                    },
                ],
                'template_fields': [
                    {
                        'uuid': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                        'notes': '',
                        'type': 'entry',
                        'data_type_uuid': 'b600a4e4-758f-4c4b-a2f4-cbb5dd870a0c',
                        'name': 'SSN',
                    },
                ],
                'pages': [
                    {
                        'id': 15,
                        'file_page_number': 1,
                        'document_page_number': 1,
                        'image_url': '/image/2ed3d989-b64a-44bd-a9fb-6e0dcc5ccdb8',
                        'form_id': 2,
                        'submission_id': 1,
                        'external_case_ids': [],
                        'read_only': False,
                        'filename': '1 page.pdf',
                        'form_page_id': 1
                    },
                ],
                'documents': [
                    {
                        'id': 2,
                        'layout_uuid': 'e31c3cbf-dcea-44fd-a052-902463c6040f',
                        'layout_name': 'layout_name',
                        'page_count': 2,
                        'read_only': False,
                    },
                ],
                'cases': [],
                'selected_choices': [],
            },
            supervision_transcription_masking=False,
        )
    """

    IDENTIFIER = 'CUSTOM_SUPERVISION_3'

    def __init__(
        self,
        submission: Any,
        task_purpose: str,
        data: Any,
        supervision_template: Any,
        reference_name: str | None = None,
        supervision_transcription_masking: bool = True,
        task_restrictions: list[Any] | None = None,
        notification_workflow: str = DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER,
        chat_flow_identifier: str | None = None,
        title: str | None = 'Custom Supervision',
        description: str | None = 'Custom Supervision',
    ) -> None:
        if not task_restrictions:
            task_restrictions = []

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'supervision_template': supervision_template,
                'submission': submission,
                'task_purpose': task_purpose,
                'data': data,
                'task_restrictions': task_restrictions,
                'supervision_transcription_masking': supervision_transcription_masking,
                'notification_workflow': notification_workflow,
                'chat_flow_identifier': chat_flow_identifier,
            },
            title=title,
            description=description,
        )


class SoapRequestBlock(Block):
    """Soap Block allows user to perform SOAP requests

    Mandatory parameters:

    :param method: SOAP method to invoke
    :param endpoint: absolute url including schema to HTTP endpoint for this request

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param body_namespace: SOAP request body namespace url
    :param headers_namespace: SOAP request headers namespace url
    :param headers: SOAP headers to use
    :param http_headers: Available from V42.1; HTTP headers to be sent on all requests
    :param params: key-value pair used as query parameters in the request to be
        inserted as SOAP body

    Example usage::

        # minimum viable instantiation, the rest of the fields can later be added in the UI
        soap_block = SoapRequestBlock(
            reference_name='soap_request',
            title='Soap Request',
            description='Perform soap request',
            method='ExampleMethod',
        )
        soap_block = SoapRequestBlock(
            reference_name='soap_request',
            title='Soap Request',
            description='Perform soap request',
            method='ExampleMethod',
            endpoint='http://example.org/abc.wso',
            body_namespace='http://www.example.org/abc.countryinfo',
            params={'example': 'stuff'},
            headers={},
            http_headers={}
        )
        # reference to the output of SoapRequestBlock which can be passed as input to the next block
        # for more information on output() and output references, please take a look at class Block
        # and its output() method
        output_ref = soap_block.output()
    """

    IDENTIFIER = 'SOAP_REQ'

    def __init__(
        self,
        method: str,
        reference_name: str | None = None,
        endpoint: str = '',
        body_namespace: str | None = None,
        headers_namespace: str | None = None,
        headers: dict[Any, Any] | None = None,
        http_headers: dict[str, Any] | None = None,
        params: dict[Any, Any] | None = None,
        use_wsdl: bool = False,
        wsdl_uri: str | None = '',
        wsdl_service_name: str | None = '',
        wsdl_port_name: str | None = '',
        title: str = 'HTTP REST Block',
        description: str = 'HTTP REST block',
    ) -> None:
        inputs: dict[Any, Any] = {
            'method': method,
            'endpoint': endpoint,
            'use_wsdl': use_wsdl,
            'wsdl_uri': wsdl_uri,
            'wsdl_service_name': wsdl_service_name,
            'wsdl_port_name': wsdl_port_name,
        }
        if body_namespace is not None:
            inputs['body_namespace'] = body_namespace
        if headers_namespace is not None:
            inputs['headers_namespace'] = headers_namespace
        if headers is not None:
            inputs['headers'] = headers
        if params is not None:
            inputs['params'] = params
        if http_headers is not None:
            inputs['http_headers'] = http_headers

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class BaseHttpRestBlock(Block):
    """
    :meta private:
    Base HttpRest block to be reused by internal and external divergent interface implementations
    """

    IDENTIFIER = 'HTTP_REST'

    def __init__(
        self,
        method: str,
        reference_name: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        payload: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
        endpoint: str | None = None,
        sdm_app_endpoint: str | None = None,
        timeout: int | None = 600,
        authorization_type: str | None = None,
        handled_error_codes: list[int | str] | None = None,
        auth_params: None | (HttpHeaderAuthorizationParams | OAuth2AuthorizationParams) = None,
        endpoint_secrets: str | None = None,
        response_encoding: str | None = None,
        title: str = 'HTTP REST Block',
        description: str = 'HTTP REST block',
    ) -> None:
        assert endpoint or sdm_app_endpoint, 'An endpoint or an sdm_app_endpoint must be specified'

        inputs: dict[Any, Any] = {'method': method}
        if endpoint is not None:
            inputs['endpoint'] = endpoint
        if sdm_app_endpoint is not None:
            inputs['sdm_app_endpoint'] = sdm_app_endpoint
        if headers is not None:
            inputs['headers'] = headers
        if params is not None:
            inputs['params'] = params
        if payload is not None:
            inputs['payload'] = payload
        if json is not None:
            inputs['json'] = json
        if timeout is not None:
            inputs['timeout'] = timeout
        if authorization_type is not None:
            inputs['authorization_type'] = authorization_type
        if handled_error_codes is not None:
            inputs['handled_error_codes'] = handled_error_codes
        if endpoint_secrets is not None:
            inputs['endpoint_secrets'] = endpoint_secrets
        if response_encoding is not None:
            inputs['response_encoding'] = response_encoding
        if auth_params is not None:
            if isinstance(auth_params, HttpHeaderAuthorizationParams):
                inputs['authorization_header'] = auth_params.authorization_header
                inputs['authorization_header_name'] = auth_params.authorization_header_name
            elif isinstance(auth_params, OAuth2AuthorizationParams):
                inputs['auth_url'] = auth_params.auth_url
                inputs['client_id'] = auth_params.client_id
                inputs['client_secret'] = auth_params.client_secret
                inputs['audience'] = auth_params.audience
                inputs['scope'] = auth_params.scope
            else:
                raise ValueError(
                    'auth_params must be of type HttpHeaderAuthorizationParams '
                    'or OAuth2AuthorizationParams'
                )

        # HTTP REST is an alias for a code block, so it wraps its output in "result" at runtime
        # unless the no-wrapping mode is stamped into its input (forwarded to the aliased block).
        apply_output_wrapping_mode(inputs)

        super().__init__(
            identifier=self.IDENTIFIER,
            title=title,
            description=description,
            reference_name=reference_name,
            input=inputs,
        )


class HttpRestBlock(BaseHttpRestBlock):
    """Http Rest Block allows user to perform HTTP requests

    Mandatory parameters:

    :param method: HTTP method to use
    :param endpoint: absolute url including schema to HTTP endpoint for this request

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param headers: HTTP headers to use
    :param params: key-value pair used as query parameters in the request
    :param payload: key-value pair to be used as x-www-form-urlencoded data.
        Mutually exclusive with json
    :param json: key-value pair to be used as json data. Mutually exclusive
        with payload
    :param timeout: How long (in seconds) to keep the connection open if no bytes are received
        from the endpoint. Set to 0 to wait indefinitely (not recommended).
    :param authorization_type: authorization type (none, http_header,
        oauth_2_client_credentials)
    :param handled_error_codes: specify HTTP error codes that will not fail
        the task, allowing for wildcards with the 'x' char. Example: [400, \"5xx\"]
    :param auth_params: authorization parameters to be passed when the authorization_type
        is set to "http_header" or "oauth_2_client_credentials"
    :param response_encoding: Character encoding to use when decoding the response. If not
        provided, the encoding from the Content-Type header or the requests library's default
        detection will be used. Specify a standard encoding name (e.g., 'utf-8', 'ISO-8859-1',
        'windows-1252') to override.

    For a guide on working with secrets, review the Flows SDK page on "Secure Handling of Secrets"
    and specifically the section on "Secrets cannot be nested within strings or objects".

    Example usage::

        # Minimum viable instantiation
        http_rest_block = HttpRestBlock(
            reference_name='http_request',
            title='Http Request',
            description='Perform http request',
            method='GET',
            endpoint='http://www.example.com',
        )

        # Reference to the output of HttpRestBlock which can be passed as input to the next block
        output_ref = http_rest_block.output()

        # By default the output is wrapped under "result" (reference it via output('result.X')).
        # When the HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE env var selects no_wrapping, it is no longer
        # wrapped, so reference it directly via output('X') instead.

        # For more information on output() and output references,
        # please take a look at class Block and its output() method.

        # HTTP header authorization
        header_auth_block = HttpRestBlock(
            reference_name='header_auth_request',
            title='Header Auth Request',
            description='Perform request with HTTP header auth',
            method='GET',
            endpoint='https://www.example.com',
            authorization_type='http_header',
            auth_params=HttpHeaderAuthorizationParams(
                authorization_header_name='Authorization',
                authorization_header=workflow_input('header_with_secret'),  # e.g.: Bearer 1234abcd
            ),
        )

        # OAuth2 Client Credentials authorization
        oauth2_block = HttpRestBlock(
            reference_name='oauth2_request',
            title='OAuth2 Request',
            description='Perform request with OAuth2',
            method='GET',
            endpoint='https://api.example.com/v1/resources',
            authorization_type='oauth_2_client_credentials',
            auth_params=OAuth2AuthorizationParams(
                auth_url='https://auth.example.com/oauth2/token',
                client_id=workflow_input('oauth_client_id'),
                client_secret=workflow_input('oauth_client_secret'),
                audience='https://api.example.com',
                scope='read write',
            ),
        )
    """

    def __init__(
        self,
        method: str,
        endpoint: str,
        reference_name: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        payload: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
        timeout: int | None = 600,
        authorization_type: str | None = None,
        handled_error_codes: list[int | str] | None = None,
        auth_params: None | (HttpHeaderAuthorizationParams | OAuth2AuthorizationParams) = None,
        response_encoding: str | None = None,
        title: str = 'HTTP REST Block',
        description: str = 'HTTP REST block',
    ) -> None:
        super().__init__(
            method=method,
            reference_name=reference_name,
            headers=headers,
            params=params,
            payload=payload,
            json=json,
            endpoint=endpoint,
            timeout=timeout,
            authorization_type=authorization_type,
            handled_error_codes=handled_error_codes,
            auth_params=auth_params,
            response_encoding=response_encoding,
            title=title,
            description=description,
        )


class HyperscienceRestApiBlock(BaseHttpRestBlock):
    """Make Http requests to the Hyperscience platform APIs.
    This block will automatically take care of prepending the base url and will include
    the appropriate authentication headers with the request.

    Mandatory parameters:

    :param method: HTTP method to use
    :param app_endpoint: relative url, beginning with a forward slash, to an HTTP endpoint served
        by the Hypersciecne platform. For reference on the available endpoints, check out
        https://docs.hyperscience.ai/

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param headers: HTTP headers to use
    :param params: key-value pair used as query parameters in the request
    :param payload: key-value pair to be used as x-www-form-urlencoded data.
        Mutually exclusive with json
    :param json: key-value pair to be used as json data. Mutually exclusive
        with payload
    :param handled_error_codes: specify HTTP error codes that will not fail
        the task, allowing for wildcards with the 'x' char. Example: [400, \"5xx\"]
    :param timeout: How long (in seconds) to keep the connection open if no bytes are received
        from the endpoint. Set to 0 to wait indefinitely (not recommended).
    :param response_encoding: Character encoding to use when decoding the response. If not
        provided, the encoding from the Content-Type header or the requests library's default
        detection will be used. Specify a standard encoding name (e.g., 'utf-8', 'ISO-8859-1',
        'windows-1252') to override.

    Example usage::

        hs_rest_block = HyperscienceRestApiBlock(
            reference_name='http_request',
            app_endpoint='/api/healthcheck',
            method='GET',
        )
    """

    def __init__(
        self,
        method: str,
        app_endpoint: str,
        reference_name: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        payload: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
        handled_error_codes: list[int | str] | None = None,
        timeout: int | None = 600,
        response_encoding: str | None = None,
        title: str = 'Hyperscience HTTP REST Block',
        description: str = 'Hyperscience HTTP REST block',
    ) -> None:
        super().__init__(
            method=method,
            reference_name=reference_name,
            headers=headers,
            params=params,
            payload=payload,
            json=json,
            sdm_app_endpoint=app_endpoint,
            timeout=timeout,
            authorization_type=None,
            handled_error_codes=handled_error_codes,
            response_encoding=response_encoding,
            title=title,
            description=description,
        )


class DatabaseAccessBlock(Block):
    """Database Block allows user to access and perform queries on the specified database

    Mandatory parameters:

    :param db_type: database type (mssql, oracle, postgres)
    :param database: database name
    :param host: URL/IP address of the server database is hosted on
    :param username: database username
    :param password: database password
    :param query: parameterized query

    Optional parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param port: database port number
    :param options: dictionary of additional connection string options
    :param timeout: timeout in seconds (mssql and postgres only)
    :param query_params: dictionary of values for query placeholders

    Example usage::

        # minimum viable instantiation, the rest of the fields can later be added in the UI
        db_lookup = DatabaseAccessBlock(
            reference_name='db_lookup',
            title='Database Lookup',
            description='Perform database lookup',
        )
        # note that storing password in plain text form is not recommended
        # password can later be entered in the UI or defined as a flow secret.
        db_lookup = DatabaseAccessBlock(
            reference_name='db_lookup',
            title='Database Lookup',
            description='Perform database lookup',
            db_type='mssql',
            database='cars',
            host='example.com',
            username='user',
            # we recommend skipping the password field or defining it as a system secret
            # e.g. system_secret('{your_secret_identifier}') (both allow for secret input via. UI)
            password='pw'
            port=1433,
            timeout=200,
            query='SELECT * from CAR',
        )
        # reference to the output of DBAccessBlock which can be passed as input to the next block
        # for more information on output() and output references, please take a look at class Block
        # and its output() method
        output_ref = db_lookup.output()
        # content of output_ref:
        {
            "result": [
                {
                    "id": 1,
                    "brand": "Aston Martin",
                    "model": "Vanquish"
                },
                {
                    "id": 2,
                    "brand": "Jaguar",
                    "model": "XE 2018"
                }
            ]
        }

    Database output for the same query (SELECT * FROM CAR)

    .. image:: ../media/images/db_access_query_example.png
    """

    IDENTIFIER = 'DB_ACCESS_2'

    def __init__(
        self,
        reference_name: str | None = None,
        db_type: str = '',
        database: str = '',
        host: str = '',
        username: str = '',
        password: str = '',
        query: str = '',
        port: int | None = None,
        options: dict[Any, Any] | None = None,
        timeout: int | None = None,
        query_params: dict[Any, Any] | None = None,
        title: str = 'DB Block',
        description: str = 'DB access block',
    ) -> None:
        inputs: dict[Any, Any] = {
            'db_type': db_type,
            'database': database,
            'host': host,
            'username': username,
            'password': password,
            'query': query,
        }
        if port is not None:
            inputs['port'] = port
        if options is not None:
            inputs['options'] = options
        if timeout is not None:
            inputs['timeout'] = timeout
        if query_params is not None:
            inputs['query_params'] = query_params

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            title=title,
            description=description,
            input=inputs,
        )


class EntityRecognitionBlock(Block):
    """
    Entity Recognition Block detects entities of different types within the pages.

    The block supports three recognition engines that can be enabled independently:

    - **Named Entity Recognition (NER)** — detects Person Names, Organisation/Company Names,
      and Addresses using a trained ML model.
    - **Custom Entity Detection (CED)** — detects words or word patterns described by regular
      expressions and keyword configurations. See *Regex Map Configuration* and
      *Keyword Map Configuration* below.
    - **Signature Detection** — detects signatures on pages.

    Mandatory parameters:

    :param pages: list of :py:class:`Page <flows_sdk.implementations.idp_v44.contracts.Page>` objects
    :param regex_map: mapping of entity type names to regex patterns (or ``'default'``).
        See *Regex Map Configuration* below for the full format.
    :param keyword_map: mapping of entity type names to keyword search configurations
        (or ``['default']``). See *Keyword Map Configuration* below for the full format.

    Optional Parameters:

    :param ner_enabled: a boolean flag that enables or disables Named Entity Recognition.
        Default value is True.
    :param ced_enabled: a boolean flag that enables or disables Custom Entity Detection.
        Default value is True.
    :param signature_enabled: a boolean flag that enables or disables Signature Detection.
        Default value is True.
    :param page_batch_size: Available from V42.3; an integer that specifies the number of pages to
        be processed in a batch. If set to `None`, all pages are processed in a single batch.
        Default value is 15.
    :param page_overlap: Available from V42.3; an integer that specifies the number of overlapping
        pages between batches. Default value is 1, which means that the last page of a batch will
        be repeated as the first page of the next batch. This is to ensure that entities that are
        located at the border of two batches are not missed.
    :param language_family: Available from V42.3; language family to use when performing
        segmentation. If not provided, the system will default to `latin`. Language families are
        single word lowercase strings, e.g., `latin`, `arabic`, `korean`, `chinese`.
        You can read more about language families in the "Supported Languages" article in the
        application documentation: https://help.hyperscience.ai/v44/docs/supported-languages.
    :param enable_multiline_detection: a boolean flag that enables or disables multiline detection
        in Custom Entity Detection. When enabled, also looks for matches spanning multiple lines
        on the same page. Default value is True.
    :param enable_cross_page_detection: a boolean flag that enables or disables cross-page detection
        in Custom Entity Detection. When enabled, also looks for matches straddling two consecutive
        pages. Default value is True.
    :param deduplicate_entities: a boolean flag that enables or disables deduplication of entities
        detected by different recognition engines (NER, CED, Signature). When enabled, overlapping
        entities are resolved using entity-type priority. Default value is False.
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided

    Output:
    The block returns an object with the following keys:

    * `groups`: list of :py:class:`EntityGroup <flows_sdk.implementations.idp_v44.contracts.EntityGroup>`
      objects, containing the detected entities.

    .. rubric:: Regex Map Configuration

    The ``regex_map`` parameter is a dictionary that maps entity type names to regular expression
    patterns. The block searches through the transcribed text and matches patterns corresponding
    to each regex, regardless of surrounding keywords.

    - Use ``'default'`` as the value to use the built-in regex for that entity type.
    - Use a custom regex string to define your own pattern.

    Example ``regex_map``::

        regex_map = {
            # Use built-in regexes for these types
            'ssn': 'default',
            'email': 'default',
            'us phone number': 'default',
            # Custom regex for an account ID like "AB1385 957"
            'account id': '[A-Z]{2}\\d{4}\\s\\d{3}',
        }

    .. rubric:: Keyword Map Configuration

    The ``keyword_map`` parameter is a dictionary that maps entity type names to a list of
    keyword search configurations. Unlike ``regex_map``, keyword search looks for entity
    patterns **near specific keywords** in the text.

    Each value is a list where items can be:

    - ``'default'`` — use the built-in keyword configuration for that entity type.
    - A dictionary describing a custom keyword-entity pair with the following keys:

      - ``keywords_regex`` (required) — defines which keywords to search for:

        - ``root_regexes`` (required, list of str) — root keyword patterns,
          e.g. ``['Account', 'Acc']``.
        - ``suffix_sequence`` (required, list of list of str) — each inner list contains
          suffix alternatives that combine with roots. For example,
          ``[['ID', 'I.D'], ['Number', '#']]`` generates combinations like
          ``Account ID Number``, ``Acc I.D #``, etc.
        - ``is_suffix_optional`` (optional, bool, default: ``False``) — when ``True``,
          root words alone also match (without any suffix).
        - ``custom_targets`` (optional, list of str) — additional standalone keywords that
          don't follow the root+suffix pattern, e.g. ``['SSN']``.
        - ``is_case_sensitive`` (optional, bool, default: ``False``) — whether keyword
          matching is case-sensitive.

      - ``entity_regex`` (required, str) — the regex pattern for the entity value itself.
      - ``entity_regex_error_tolerance`` (optional, int, default: ``0``) — fuzzy matching
        tolerance. Specifies how many wrong/additional/fewer symbols are allowed in a match.
      - ``enable_table_search`` (optional, bool, default: ``False``) — when ``True``,
        also considers the keyword as a potential column header and searches the column below.
      - ``enable_closest_word_line_below`` (optional, bool, default: ``True``) — when
        ``True``, considers the closest non-overlapping word in the line below the keyword.
      - ``enable_block_above_search`` (optional, bool, default: ``True``) — when ``True``,
        also searches above the keyword.
      - ``allow_intervening_words`` (optional, bool, default: ``True``) — when ``False``,
        rejects matches that have any words between the keyword and the entity.

    Example ``keyword_map``::

        keyword_map = {
            # Use built-in keyword config for passport numbers
            'passport number': ['default'],
            # Custom keyword config for a patient name entity
            'patient': [
                {
                    'keywords_regex': {
                        'root_regexes': ['patient', "patient's", 'veteran'],
                        'suffix_sequence': [['name']],
                        'custom_targets': ['name', 'chart'],
                        'is_suffix_optional': True,
                    },
                    'entity_regex': '.*',
                }
            ],
            # Custom keyword config for an Account ID
            'account id': [
                {
                    'keywords_regex': {
                        'root_regexes': ['Account', 'Acc'],
                        'suffix_sequence': [['ID', 'I.D'], ['Number', 'Num', '#']],
                        'is_suffix_optional': True,
                    },
                    'entity_regex': '[A-Z]{2}\\d{4}\\s\\d{3}',
                }
            ],
        }

    .. rubric:: Built-in Entity Types

    The following entity types have built-in (``'default'``) regex and keyword definitions:

    ``ssn``, ``email``, ``employer id``, ``us phone number``, ``date``, ``micr``,
    ``machine readable line``, ``policy number``, ``loan number``, ``credit card number``,
    ``customer id``, ``account number``, ``employee id``, ``passport number``,
    ``uscis number``, ``driver license number``, ``driver license restrictions``,
    ``i94 number``, ``pin number``, ``ptin number``, ``judgment number``,
    ``case number``, ``bankruptcy number``, ``application number``, ``file number``,
    ``routing number``, ``nmls number``, ``appraiser certification number``

    Use ``'default'`` in ``regex_map`` and ``['default']`` in ``keyword_map`` to enable
    the built-in detection for any of these types.

    Example usage::

        # This is one way to obtain the pages (using SubmissionBootstrapBlock)
        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

        entity_recognition_block = EntityRecognitionBlock(
            reference_name='entity_recognition',
            pages=submission_bootstrap.output('submission.unassigned_pages'),
            regex_map=DEFAULT_PII_REGEX_MAP,
            keyword_map=DEFAULT_PII_KEYWORD_MAP,
        )

        # reference to the output of EntityRecognitionBlock which can be passed as input to the
        # next block. For more information on output() and output references, please take a look at
        # class Block and its output() method
        output_ref = entity_recognition_block.output()
    """

    IDENTIFIER = 'ENTITY_RECOGNITION_2'

    def __init__(
        self,
        pages: list[dict[str, Any]] | str,
        regex_map: dict[str, str] | str | None = None,
        keyword_map: dict[str, list[str]] | str | None = None,
        ner_enabled: bool | str = True,
        ced_enabled: bool | str = True,
        signature_enabled: bool | str = True,
        page_batch_size: int | None = DEFAULT_ENTITY_RECOGNITION_PAGE_BATCH_SIZE,
        page_overlap: int = DEFAULT_ENTITY_RECOGNITION_PAGE_OVERLAP,
        language_family: str | None = None,
        enable_multiline_detection: bool = True,
        enable_cross_page_detection: bool = True,
        deduplicate_entities: bool | str = False,
        reference_name: str | None = None,
        title: str = 'Entity Recognition',
        description: str = 'Recognizes entities of different types in documents',
    ) -> None:
        inputs: dict[Any, Any] = {
            'pages': pages,
            'regex_map': regex_map,
            'keyword_map': keyword_map,
            'ner_enabled': ner_enabled,
            'ced_enabled': ced_enabled,
            'signature_enabled': signature_enabled,
            'page_batch_size': page_batch_size,
            'page_overlap': page_overlap,
            'language_family': language_family,
            'enable_multiline_detection': enable_multiline_detection,
            'enable_cross_page_detection': enable_cross_page_detection,
            'deduplicate_entities': deduplicate_entities,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class RedactionBlock(Block):
    """
    Redacts and masks the provided entities on the pages based on the corresponding settings.

    Mandatory parameters:

    :param redaction_groups: list of
        :py:class:`EntityGroup <flows_sdk.implementations.idp_v44.contracts.EntityGroup>` objects.
        Each group contains a list of entities to be redacted / masked together.

    Optional Parameters:

    :param text_content_mode: a discrete value, either "synthetic_data" or "opaque_box",
        which defines the masking / redaction method to be performed on text entities.
        Default value is "synthetic_data".
    :param sensitive_content_mode: a discrete value, either "opaque_box", or "obfuscated_box".
        Defines the masking method to be performed on entities with sensitive content. Default
        value is "opaque_box".
    :param replacements: can be used to define the replacement text for a given entity type and
        original text. It is a dictionary where keys are entity types and values are dictionaries
        that map original text to replacement text.
    :param skip_entity_types: a list of entity types that should be excluded from redaction
        / masking.
    :param add_watermark: a boolean flag that indicates whether to add a watermark to the pages
        that have redaction / masking applied. Default value is True.
    :param watermark_text: a string that specifies the text to be used in the watermark, if
        add_watermark is set to True. If not provided, a default watermark text will be used.

    Output:
    The block returns an object with the following keys:

    * `redacted_groups`: list of
      :py:class:`RedactedGroup <flows_sdk.implementations.idp_v44.contracts.RedactedGroup>` objects,
      containing the redacted images.

    Example usage::

        redaction = RedactionBlock(
            reference_name='redaction',
            redaction_groups=entity_recognition.output('groups'),
        )
    """

    IDENTIFIER = 'REDACTION_AND_MASKING'

    def __init__(
        self,
        redaction_groups: list[dict[str, Any]] | str,
        text_content_mode: str = REDACTION_SYNTHETIC_DATA_MODE,
        sensitive_content_mode: str = REDACTION_OPAQUE_BOX_MODE,
        replacements: dict[str, dict[str, str]] | None | str = None,
        skip_entity_types: list[str] | None | str = None,
        add_watermark: bool | str = True,
        watermark_text: str | None = None,
        reference_name: str | None = None,
        title: str = 'Redaction',
        description: str = 'Performs redaction on the provided pages.',
    ) -> None:
        inputs: dict[str, Any] = {
            'redaction_groups': redaction_groups,
            'text_content_mode': text_content_mode,
            'sensitive_content_mode': sensitive_content_mode,
            'replacements': replacements,
            'skip_entity_types': skip_entity_types,
            'add_watermark': add_watermark,
            'watermark_text': watermark_text,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class ImagesToPrintableFileBlock(Block):
    """
    This block renders each document's sequence of images into a separate PDF file and
    stores each resulting PDF in Blob storage. For every document provided,
    a new blob is created containing the rendered PDF.

    Available from V42.1.

    Mandatory parameters:

    :param documents: List of documents, each containing a document_id and `pages`.
        Each page contains `image_uuid` for image-only output, and may optionally include
        `searchable_words_blob_uuid` for generating a searchable PDF text layer.

    Optional parameters:

    :param height_in_mm: the height of the document to be generated in millimeters.
        Default is 279.4 (US Letter height). Ignored when use_native_dimensions is True.
    :param width_in_mm: the width of the document to be generated in millimeters.
        Default is 215.9 (US Letter width). Ignored when use_native_dimensions is True.
    :param use_native_dimensions: Available from V42.3; when True, each page uses its source
        image's native dimensions instead of being resized to width_in_mm × height_in_mm.
        This preserves maximum image quality. Default is False. When enabled, the output
        height_in_mm and width_in_mm represent the bounding box (maximum dimensions across all
        pages).
    :param dpi: Available from V42.3; dots per inch to assume for images without embedded DPI
        metadata. Used to calculate physical dimensions in native dimensions mode. Default is 200
        (matching VECTOR_GRAPHICS_DPI used by the pagination pipeline).
    :param mime_type: the mime type of the document to be generated. Default is 'application/pdf'
    :param quality: Quality of pages (images) appended to the resulting document
        as a percentage (recommended 50%). Higher quality results in a larger file size for the
        generated PDF.
    :param mode: Mode of the images appended to the resulting document.
        Supported modes are RGB (default), L (grayscale) and 1 (black-and-white)

    Page-based document shape:

    Each page contains the image UUID to render and may optionally include
    `searchable_words_blob_uuid`. A page with no searchable words blob renders image-only
    output; a page with a searchable words blob also emits an invisible searchable text
    layer for those words.

    PDF page order follows the order of entries in `pages`.

    * `image_uuid`: UUID of the rendered image for that PDF page.
    * `searchable_words_blob_uuid`: Optional UUID of a block-storage JSON blob whose
      records provide the minimal searchable word data: image_uuid, text, and bbox.

    Example usage::

        documents = [
            {
                'document_id': '48212a99-c099-42e3-bb45-75664db65341',
                'pages': [
                    {'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41973'},
                    {'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41974'},
                ],
            },
            {
                'document_id': 'delivery_receipt_xyz',
                'pages': [
                    {'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41975'},
                ],
            }
        ]

        # Fixed dimensions mode (default) - all pages resized to specified dimensions
        images_renderer_block = ImagesToPrintableFileBlock(
            reference_name='images_renderer',
            height_in_mm=279.4,
            width_in_mm=215.9,
            quality=50,
            mode='L',
            documents=documents
        )

        # Native dimensions mode - preserves original image quality
        images_renderer_native = ImagesToPrintableFileBlock(
            reference_name='images_renderer_native',
            use_native_dimensions=True,
            dpi=200,
            quality=80,
            documents=documents
        )

        output_ref = images_renderer_block.output()

        Searchable words are optional on each page. Store them in Blob storage and
        reference the blob from the page::

            documents = [
                {
                    'document_id': '48212a99-c099-42e3-bb45-75664db65341',
                    'pages': [
                        {
                            'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41972',
                        },
                        {
                            'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41973',
                            'searchable_words_blob_uuid': (
                                'd6f5a4bd-581d-4d3d-9eba-d0382b64fda6'
                            ),
                        }
                    ],
                }
            ]

        The searchable words blob must be UTF-8 JSON with a `words` list::

            {
                "words": [
                    {
                        "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                        "text": "Example",
                        "bbox": [0.11, 0.21, 0.19, 0.23]
                    },
                    {
                        "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                        "text": "text",
                        "bbox": [0.22, 0.21, 0.29, 0.23]
                    }
                ]
            }

        Only records whose `image_uuid` matches the rendered page image are converted
        into searchable words. The blob reader also accepts `segments` as an alias for
        the top-level `words` list, `transcription` as an alias for `text`, and
        `tight_crop_bounding_box` or `bounding_box` as aliases for `bbox`. Extra fields
        are ignored, so a ProcessedSegmentList-shaped blob can be reused directly as long
        as those minimal fields are present. Each bbox is normalized to the rendered
        image:

        * `bbox[0]` / `bbox[1]`: top-left x/y.
        * `bbox[2]` / `bbox[3]`: bottom-right x/y.
        * `[0.0, 0.0]`: top-left of the rendered image.
        * `[1.0, 1.0]`: bottom-right of the rendered image.

    Example content of output_ref (fixed dimensions mode)::

        {
            "rendered_documents": [
                {
                    "document_id": "48212a99-c099-42e3-bb45-75664db65341",
                    "blob_uuid": "52e81c7f-aef6-4f69-b4a6-91fd770a607d",
                    "mime_type": "application/pdf",
                    "height_in_mm": 279.4,
                    "width_in_mm": 215.9,
                    "quality": 50,
                    "mode": "L",
                    "page_dimensions": [
                        {
                            "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                            "width_in_mm": 215.9,
                            "height_in_mm": 279.4,
                        },
                        {
                            "image_uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                            "width_in_mm": 215.9,
                            "height_in_mm": 279.4,
                        },
                    ]
                }
            ]
        }

    Example content of output_ref (native dimensions mode)::

        {
            "rendered_documents": [
                {
                    "document_id": "48212a99-c099-42e3-bb45-75664db65341",
                    "blob_uuid": "52e81c7f-aef6-4f69-b4a6-91fd770a607d",
                    "mime_type": "application/pdf",
                    "height_in_mm": 297.0,
                    "width_in_mm": 215.9,
                    "quality": 80,
                    "mode": "RGB",
                    "page_dimensions": [
                        {
                            "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                            "width_in_mm": 210.0,
                            "height_in_mm": 297.0,
                        },
                        {
                            "image_uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                            "width_in_mm": 215.9,
                            "height_in_mm": 279.4,
                        },
                    ]
                }
            ]
        }

    """

    IDENTIFIER = 'IMAGE_TO_PRINTABLE_FILE'

    def __init__(
        self,
        documents: list[dict[str, Any]],
        height_in_mm: float = 279.4,
        width_in_mm: float = 215.9,
        use_native_dimensions: bool = False,
        dpi: int = 200,
        mime_type: str = 'application/pdf',
        quality: int = 50,
        mode: str = 'RGB',
        reference_name: str | None = None,
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'documents': documents,
                'height_in_mm': height_in_mm,
                'width_in_mm': width_in_mm,
                'use_native_dimensions': use_native_dimensions,
                'dpi': dpi,
                'mime_type': mime_type,
                'quality': quality,
                'mode': mode,
            },
            title='Images to PDF',
            description='Renders a list of images into a PDF',
        )


class VertexAIBlock(Block):
    """Generate content using a GCP Vertex AI model.

    Available from V43.1.

    Mandatory parameters:

    :param model: ID of the model to use. For example: gemini-2.5-flash or gemini-2.5-pro
    :param messages: A list of messages. Each message has a 'role' (e.g. user, model) and
        'content' (list of text or file contents).
    :param project: GCP Project
    :param location: GCP Location. For more information, check out:
        https://docs.cloud.google.com/vertex-ai/generative-ai/docs/learn/locations
    :param service_acc_json: Full service account auth json. Optional when
        workload_identity is True. For more information, check out:
        https://cloud.google.com/iam/docs/service-account-creds
    :param workload_identity: When True, authenticate via GCP Workload
        Identity instead of a service account key. Defaults to False.

    Optional parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param generation_config: Generation config. For more information, check out:
        https://docs.cloud.google.com/vertex-ai/generative-ai/docs/reference/rest/v1/GenerationConfig
    :param safety_settings: A list of SafetySetting objects passed directly to the Vertex AI API.
        For more information:
        https://docs.cloud.google.com/vertex-ai/generative-ai/docs/reference/rest/v1/SafetySetting
    :param extra_body: Additional fields merged into the API request body.

    Output:
    The block returns an object with the following keys:

    * `text`: The text of the first response candidate, with all of its text parts joined.
      ``None`` when the response has no candidates or the first candidate has no text parts.
    * `response`: The raw ``generateContent`` response body returned by the Vertex AI API.

    If the request to Vertex AI fails, the block fails.

    Example usage::

        vertexai = VertexAIBlock(
            reference_name='vertexai',
            model='gemini-2.5-flash',
            messages=[{'role': 'user', 'content': [{'type': 'text', 'text': 'Hello'}]}],
            project='my-gcp-project',
            location='us-central1',
            service_acc_json='${system.secrets.gcp_service_account}',
        )
    """

    IDENTIFIER = 'VERTEXAI_2'

    def __init__(
        self,
        model: str,
        messages: list[dict[str, Any]],
        project: str,
        location: str,
        service_acc_json: str | None = None,
        workload_identity: bool = False,
        reference_name: str | None = None,
        generation_config: dict[str, Any] | None = None,
        safety_settings: list[dict[str, Any]] | None = None,
        extra_body: dict[str, Any] | None = None,
        title: str = 'GCP VertexAI Generate Content',
        description: str = 'Send prompts (text and files) to a model hosted on GCP Vertex AI',
    ) -> None:
        input_dict: dict[str, Any] = {
            'model': model,
            'messages': messages,
            'generation_config': generation_config,
            'safety_settings': safety_settings,
            'extra_body': extra_body,
            'project': project,
            'location': location,
            'workload_identity': workload_identity,
        }
        if service_acc_json is not None:
            input_dict['service_acc_json'] = service_acc_json

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=input_dict,
            title=title,
            description=description,
        )
