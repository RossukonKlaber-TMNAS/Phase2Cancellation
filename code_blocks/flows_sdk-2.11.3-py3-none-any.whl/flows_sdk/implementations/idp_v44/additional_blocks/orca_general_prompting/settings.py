from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v44.additional_blocks.common_settings import (
    OrcaSettings,
    get_orca_base_model_uuid_param,
)
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs


class OrcaGeneralPromptingSettings(OrcaSettings, BaseInputs):
    OrcaBaseModelUUID = 'orca_base_model_uuid'

    @classmethod
    def create(  # type: ignore[override]
        cls, orca_type: str, base_model_uuid: str | None
    ) -> dict[str, Any]:
        return {
            **OrcaSettings.create(orca_type),
            cls.OrcaBaseModelUUID: base_model_uuid,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            get_orca_base_model_uuid_param(cls.OrcaBaseModelUUID),
        ]
