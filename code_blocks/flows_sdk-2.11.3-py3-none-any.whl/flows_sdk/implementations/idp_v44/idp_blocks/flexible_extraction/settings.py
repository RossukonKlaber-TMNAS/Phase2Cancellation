from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs


class FlexibleExtractionSettings(BaseInputs):
    FlexibleExtractionNotificationWorkflow = 'notification_workflow_flexible_extraction'
    FlexibleExtractionSupervisionTranscriptionMasking = (
        'flexible_extraction_supervision_transcription_masking'
    )
    FlexibleExtractionTaskRestrictions = 'flexible_extraction_task_restrictions'
    FlexibleExtractionShowMachinePredictions = 'flexible_extraction_show_machine_predictions'
    FlexibleExtractionSearchablePages = 'flexible_extraction_searchable_pages'

    @classmethod
    def create(
        cls,
        notification_workflow: str | None,
        task_restrictions: list[str],
        supervision_transcription_masking: bool,
        show_machine_predictions: bool,
        searchable_pages: bool = False,
    ) -> dict[str, Any]:
        return {
            cls.FlexibleExtractionNotificationWorkflow: notification_workflow,
            cls.FlexibleExtractionTaskRestrictions: task_restrictions,
            cls.FlexibleExtractionSupervisionTranscriptionMasking: (
                supervision_transcription_masking
            ),
            cls.FlexibleExtractionShowMachinePredictions: show_machine_predictions,
            cls.FlexibleExtractionSearchablePages: searchable_pages,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.FlexibleExtractionNotificationWorkflow,
                type='FlowIdentifier',
                value=None,
                title='Flexible Extraction Notification Flow',
                type_spec={'filter_roles': ['notifications'], 'label': 'If task needed'},
                optional=True,
            ),
            Parameter(
                name=cls.FlexibleExtractionSupervisionTranscriptionMasking,
                type='boolean',
                value=True,
                title='Flexible Extraction Transcription Masking',
                description=(
                    'Prevents users from inputting invalid characters during'
                    ' the Flexible Extraction task.'
                ),
            ),
            Parameter(
                name=cls.FlexibleExtractionTaskRestrictions,
                type='TaskRestrictions',
                title='Default Task Restrictions',
                description=(
                    'Defines what users can access Supervision tasks created by this block.'
                ),
                optional=True,
            ),
            Parameter(
                name=cls.FlexibleExtractionShowMachinePredictions,
                type='boolean',
                value=True,
                optional=True,
                title='Flexible Extraction Show Machine Predictions',
                description=(
                    'When enabled, low-confidence machine transcriptions are pre-filled in '
                    'Flexible Extraction Supervision tasks for human review.'
                ),
            ),
            Parameter(
                name=cls.FlexibleExtractionSearchablePages,
                type='boolean',
                value=False,
                optional=True,
                title='Enable Text Segment Search',
            ),
        ]
