from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.licensing.licensing import FeatureGatingCommonDependencies


class IdpSystemSettings(BaseInputs):
    LayoutReleaseUuid = 'layout_release_uuid'

    @classmethod
    def create(cls, layout_release_uuid: str) -> dict[str, Any]:
        return {cls.LayoutReleaseUuid: layout_release_uuid}

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.LayoutReleaseUuid,
                type='ReleaseUUID',
                title='Layout Release',
            )
        ]


class OrcaDependencySettings(BaseInputs):
    OrcaOnlyExtraction = 'orca_only_extraction'

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.OrcaOnlyExtraction,
                type='boolean',
                value=False,
                ui={'hidden': True},
                title='ORCA Only Extraction',
            ),
        ]


ORCA_ONLY_EXTRACTION_DEPENDENCY = Dependency(
    condition={'properties': {OrcaDependencySettings.OrcaOnlyExtraction: {'const': True}}},
    override={'ui': {'hide_and_retain': True}},
)


class ClassificationSettings(BaseInputs):
    StructuredLayoutMatchThreshold = 'structured_layout_match_threshold'
    ManualNlcEnabled = 'manual_nlc_enabled'

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.StructuredLayoutMatchThreshold,
                type='number',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='Structured Layout Match Threshold',
                description=(
                    'Matches structured layouts above this threshold to a layout variation '
                    'automatically. Pages below this threshold will be sent to Document '
                    'Classification, if enabled. If disabled, such pages will be marked as '
                    '"No Layout Variation Found."'
                ),
            ),
            Parameter(
                name=cls.ManualNlcEnabled,
                type='boolean',
                title='Manual Classification Supervision',
                description='Enables manual classification when applicable',
            ),
        ]


class IdentificationSettings(OrcaDependencySettings, BaseInputs):
    # This enables both field and table identification
    ManualFieldIdEnabled = 'manual_field_id_enabled'

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.ManualFieldIdEnabled,
                type='boolean',
                value=True,
                title='Manual Identification Supervision',
                description='Enables manual identification when applicable',
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
        ]


class ExtractionSettings(OrcaDependencySettings, BaseInputs):
    ForceRequiredEntriesToSV = 'force_required_entries_to_sv'

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.ForceRequiredEntriesToSV,
                type='boolean',
                value=False,
                title='Force missing/blank Fields to Supervision',
                description=(
                    'Enable this option to route fields marked as "Required" to Supervision for '
                    'review if they are missing or left blank, ensuring important data is present '
                    'in downstream processes.'
                ),
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
        ]


class TranscriptionSettings(BaseInputs):
    ManualTranscriptionEnabled = 'manual_transcription_enabled'
    ManualTranscriptionAlwaysSuperviseBlankCells = (
        'manual_transcription_always_supervise_blank_cells'
    )

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.ManualTranscriptionEnabled,
                type='boolean',
                title='Manual Transcription Supervision',
                description='Enables manual transcription when applicable',
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.ManualTranscriptionAlwaysSuperviseBlankCells,
                type='boolean',
                value=True,
                title='Create Manual Transcription Task For Tables With Blank Cells',
                description=(
                    'If enabled, always send blank cells in transcribed tables to be '
                    'supervised manually, regardless of confidence.'
                ),
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
        ]
