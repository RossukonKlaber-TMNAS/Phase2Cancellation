from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.idp_blocks.common_settings import (
    ORCA_ONLY_EXTRACTION_DEPENDENCY,
)
from flows_sdk.implementations.idp_v44.licensing.licensing import FeatureGatingCommonDependencies


class SubmissionCompleteSettings(BaseInputs):
    SemiQaSampleRate = 'semi_qa_sample_rate'

    FieldIdQaEnabled = 'field_id_qa_enabled'
    FieldIdQaSampleRate = 'field_id_qa_sample_rate'
    TableIdQaEnabled = 'table_id_qa_enabled'
    TableIdQaSampleRate = 'table_id_qa_sample_rate'

    TranscriptionQaEnabled = 'qa'
    AutoQaSamplingRateEnabled = 'auto_qa_sampling_rate_enabled'
    TranscriptionStructuredEntryQaSampleRate = 'structured_entry_qa_sample_rate'
    TranscriptionStructuredCheckboxQaSampleRate = 'structured_checkbox_qa_sample_rate'
    TranscriptionStructuredSignatureQaSampleRate = 'structured_signature_qa_sample_rate'
    TranscriptionSemiStructuredQaSampleRate = 'semi_structured_qa_sample_rate'
    TableCellTranscriptionQaEnabled = 'table_cell_transcription_qa_enabled'
    TableCellTranscriptionQaSampleRate = 'table_cell_transcription_qa_sample_rate'
    ExcludeAutoTranscribeFieldsFromQA = 'exclude_auto_transcribe_fields_from_qa'

    @classmethod
    def create(
        cls,
        nlc_qa_sample_rate: float,
        field_id_qa_enabled: bool,
        field_id_qa_sample_rate: float,
        table_id_qa_enabled: bool,
        table_id_qa_sample_rate: float,
        transcr_auto_qa_sampling_enabled: bool,
        field_transcr_qa_enabled: bool,
        field_transcr_structured_text_qa_sample_rate: float | None,
        field_transcr_structured_checkbox_qa_sample_rate: float | None,
        field_transcr_structured_signature_qa_sample_rate: float | None,
        field_transcr_semi_structured_field_qa_sample_rate: float | None,
        field_transcr_exclude_auto_transcribe_fields_from_qa: bool,
        table_transcr_qa_enabled: bool,
        table_transcr_qa_sample_rate: float | None,
    ) -> dict[str, Any]:
        return {
            cls.SemiQaSampleRate: nlc_qa_sample_rate,
            cls.FieldIdQaEnabled: field_id_qa_enabled,
            cls.FieldIdQaSampleRate: field_id_qa_sample_rate,
            cls.TableIdQaEnabled: table_id_qa_enabled,
            cls.TableIdQaSampleRate: table_id_qa_sample_rate,
            cls.AutoQaSamplingRateEnabled: transcr_auto_qa_sampling_enabled,
            cls.TranscriptionQaEnabled: field_transcr_qa_enabled,
            cls.TranscriptionStructuredEntryQaSampleRate: (
                field_transcr_structured_text_qa_sample_rate
            ),
            cls.TranscriptionStructuredCheckboxQaSampleRate: (
                field_transcr_structured_checkbox_qa_sample_rate
            ),
            cls.TranscriptionStructuredSignatureQaSampleRate: (
                field_transcr_structured_signature_qa_sample_rate
            ),
            cls.TranscriptionSemiStructuredQaSampleRate: (
                field_transcr_semi_structured_field_qa_sample_rate
            ),
            cls.ExcludeAutoTranscribeFieldsFromQA: (
                field_transcr_exclude_auto_transcribe_fields_from_qa
            ),
            cls.TableCellTranscriptionQaEnabled: table_transcr_qa_enabled,
            cls.TableCellTranscriptionQaSampleRate: table_transcr_qa_sample_rate,
        }

    @classmethod
    def get_classification_settings(cls) -> list[str]:
        return [cls.SemiQaSampleRate]

    @classmethod
    def get_identification_settings(cls) -> list[str]:
        return [
            cls.FieldIdQaEnabled,
            cls.FieldIdQaSampleRate,
            cls.TableIdQaEnabled,
            cls.TableIdQaSampleRate,
        ]

    @classmethod
    def get_transcription_settings(cls) -> list[str]:
        return [
            cls.TranscriptionQaEnabled,
            cls.AutoQaSamplingRateEnabled,
            cls.TranscriptionStructuredEntryQaSampleRate,
            cls.TranscriptionStructuredCheckboxQaSampleRate,
            cls.TranscriptionStructuredSignatureQaSampleRate,
            cls.TranscriptionSemiStructuredQaSampleRate,
            cls.ExcludeAutoTranscribeFieldsFromQA,
            cls.TableCellTranscriptionQaEnabled,
            cls.TableCellTranscriptionQaSampleRate,
        ]

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.SemiQaSampleRate,
                type='Percentage',
                title='Semi-Structured Classification QA Sample Rate',
                description='Defines the percentage of documents sampled for QA.',
                dependencies=FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.FieldIdQaEnabled,
                type='boolean',
                title='Field Identification Quality Assurance',
                description=(
                    'Allows users to verify the location or presence of fields on '
                    'semi-structured documents.'
                ),
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.FieldIdQaSampleRate,
                type='Percentage',
                title='Field Identification QA Sample Rate',
                description='Defines the percentage of documents the system samples for QA.',
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.FieldIdQaEnabled: {'const': False}}},
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Field Identification Quality Assurance'
                                    ' is disabled.'
                                )
                            }
                        },
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.TableIdQaEnabled,
                type='boolean',
                value=True,
                title='TABLE IDENTIFICATION QUALITY ASSURANCE',
                description='Allows users to verify the location of table cells.',
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.TableIdQaSampleRate,
                type='Percentage',
                value=0.05,
                title='TABLE IDENTIFICATION QA SAMPLE RATE',
                description='Defines the percentage of tables the system samples for QA.',
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.TableIdQaEnabled: {'const': False}}},
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Table Identification Quality Assurance'
                                    ' is disabled.'
                                )
                            }
                        },
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.TranscriptionQaEnabled,
                type='boolean',
                title='Transcription Quality Assurance',
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.AutoQaSamplingRateEnabled,
                type='boolean',
                title='Automatic QA Sample Rate',
                description='Updates QA rate daily based on submission volume.',
                value=False,
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.TranscriptionQaEnabled: {'const': False}}},
                        override={'ui': {'hidden': True}},
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.TranscriptionStructuredEntryQaSampleRate,
                type='Percentage',
                title='Structured Text Transcription QA Sample Rate',
                description=(
                    'Defines the percentage of structured text fields the system samples for QA.'
                ),
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.TranscriptionQaEnabled: {'const': False}}},
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Transcription Quality Assurance is disabled.'
                                )
                            }
                        },
                    ),
                    Dependency(
                        condition={'properties': {cls.AutoQaSamplingRateEnabled: {'const': True}}},
                        override={'ui': {'disabled': True}},
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.TranscriptionStructuredCheckboxQaSampleRate,
                type='Percentage',
                title='Structured Checkbox Transcription QA Sample Rate',
                description=(
                    'Defines the percentage of structured checkbox fields '
                    'the system samples for QA.'
                ),
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.TranscriptionQaEnabled: {'const': False}}},
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Transcription Quality Assurance is disabled.'
                                )
                            }
                        },
                    ),
                    Dependency(
                        condition={'properties': {cls.AutoQaSamplingRateEnabled: {'const': True}}},
                        override={'ui': {'disabled': True}},
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.TranscriptionStructuredSignatureQaSampleRate,
                type='Percentage',
                title='Structured Signature Transcription QA Sample Rate',
                description=(
                    'Defines the percentage of structured signature fields '
                    'the system samples for QA.'
                ),
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.TranscriptionQaEnabled: {'const': False}}},
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Transcription Quality Assurance is disabled.'
                                )
                            }
                        },
                    ),
                    Dependency(
                        condition={'properties': {cls.AutoQaSamplingRateEnabled: {'const': True}}},
                        override={'ui': {'disabled': True}},
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.TranscriptionSemiStructuredQaSampleRate,
                type='Percentage',
                title='Semi-Structured Transcription QA Sample Rate',
                description=(
                    'Defines the percentage of semi-structured fields the system samples for QA.'
                ),
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.TranscriptionQaEnabled: {'const': False}}},
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Transcription Quality Assurance is disabled.'
                                )
                            }
                        },
                    ),
                    Dependency(
                        condition={'properties': {cls.AutoQaSamplingRateEnabled: {'const': True}}},
                        override={'ui': {'disabled': True}},
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.TableCellTranscriptionQaEnabled,
                type='boolean',
                title='Table Transcription Quality Assurance',
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.TableCellTranscriptionQaSampleRate,
                type='Percentage',
                title='Table Transcription QA Sample Rate',
                description=(
                    'Defines the percentage of cells the system samples for QA. This '
                    'value is likely to be lower than "Transcription QA Sample Rate" since'
                    'there are more table cells than fields on any given page.'
                ),
                dependencies=[
                    Dependency(
                        condition={
                            'properties': {cls.TableCellTranscriptionQaEnabled: {'const': False}}
                        },
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Table Transcription Quality Assurance'
                                    ' is disabled.'
                                )
                            }
                        },
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.ExcludeAutoTranscribeFieldsFromQA,
                type='boolean',
                title='Exclude Auto-Transcribe Fields From QA',
                value=False,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
        ]
