from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v44.idp_blocks.submission_complete.settings import (
    SubmissionCompleteSettings as Settings,
)
from flows_sdk.utils import workflow_input


class SubmissionCompleteBlock(Block):
    """Submission complete block finalizes submission processing and updates reporting data.
    **This block should be called at the END of every flow** that
    uses blocks included in the ``flows_sdk.implementations.idp_v34`` library.
    The block requires both the ``submission`` object and a ``payload`` to be passed in.

    Mandatory parameters:

    :param submission: Submission object
    :param payload: Object to pass to downstream systems

    Parameters with defaults:

    :param is_reprocessing: boolean to handle execution when reprocessing,
        defaults to False
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param nlc_qa_sampling_ratio: Defines the percentage of pages sampled for
        Classification QA, defaults to workflow_input(Settings.SemiQaSampleRate)
    :param field_id_qa_enabled:
        defaults to workflow_input(Settings.FieldIdQaEnabled)
    :param field_id_qa_sampling_ratio: Defines the percentage of fields sampled for
        Identification QA, defaults to workflow_input(Settings.FieldIdQaSampleRate)
    :param table_id_qa_enabled: Allows users to verify the location of table cells,
        defaults to workflow_input(Settings.TableIdQaEnabled)
    :param table_id_qa_sampling_ratio: Defines the percentage of tables the
        system samples for QA, defaults to workflow_input(Settings.TableIdQaSampleRate)
    :param transcription_qa_enabled:
        defaults to workflow_input(Settings.TranscriptionQaEnabled)
    :param transcription_structured_entry_qa_sample_rate: Defines the percentage of structured
        text fields the system samples for Transcription QA, defaults to
        workflow_input(Settings.TranscriptionStructuredEntryQaSampleRate)
    :param transcription_structured_signature_qa_sample_rate: Defines the percentage of structured
        signature fields sampled for Transcription QA, defaults to
        workflow_input(Settings.TranscriptionStructuredSignatureQaSampleRate)
    :param transcription_structured_checkbox_qa_sample_rate: Defines the percentage of structured
        checkbox fields sampled for Transcription QA, defaults to
        workflow_input(Settings.TranscriptionStructuredCheckboxQaSampleRate)
    :param transcription_semi_structured_qa_sample_rate: Defines the percentage of semi-
        structured fields the system samples for Transcription QA, defaults to
        workflow_input(Settings.TranscriptionSemiStructuredQaSampleRate)
    :param table_cell_transcription_qa_enabled:
        defaults to workflow_input(Settings.TableCellTranscriptionQaEnabled)
    :param table_cell_transcription_qa_sample_rate: Defines the percentage of cells the
        system samples for QA. This value is likely to be lower than
        “Transcription QA Sample Rate” since there are more table cells than fields
        on any given page, defaults to workflow_input(Settings.TableCellTranscriptionQaSampleRate)
    :param auto_qa_sampling_rate_enabled: Enables automatic selection of QA sampling rates
        based on system configuration or heuristics, defaults to
        workflow_input(Settings.AutoQaSamplingRateEnabled)
    :param exclude_auto_transcribe_fields_from_qa: Defines whether fields that are marked as
        auto-transcribe in layout should be excluded from QA or not,
        defaults to workflow_input(Settings.ExcludeAutoTranscribeFieldsFromQA)

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>` with
      the finalized submission processing and reporting data.

    Example usage::

        submission_complete = SubmissionCompleteBlock(
            reference_name='complete_submission',
            submission=flexible_extraction.output('submission')
        )
    """

    IDENTIFIER = 'SUBMISSION_COMPLETE_5'

    def __init__(
        self,
        submission: str,
        is_reprocessing: str | bool = False,
        reference_name: str | None = None,
        nlc_qa_sampling_ratio: str | int | float = workflow_input(Settings.SemiQaSampleRate),
        field_id_qa_enabled: str | bool = workflow_input(Settings.FieldIdQaEnabled),
        field_id_qa_sampling_ratio: str | int | float = workflow_input(
            Settings.FieldIdQaSampleRate
        ),
        table_id_qa_enabled: str | bool = workflow_input(Settings.TableIdQaEnabled),
        table_id_qa_sampling_ratio: str | int | float = workflow_input(
            Settings.TableIdQaSampleRate
        ),
        transcription_qa_enabled: str | bool = workflow_input(Settings.TranscriptionQaEnabled),
        transcription_structured_entry_qa_sample_rate: str | float = workflow_input(
            Settings.TranscriptionStructuredEntryQaSampleRate
        ),
        transcription_structured_signature_qa_sample_rate: str | float = workflow_input(
            Settings.TranscriptionStructuredSignatureQaSampleRate
        ),
        transcription_structured_checkbox_qa_sample_rate: str | float = workflow_input(
            Settings.TranscriptionStructuredCheckboxQaSampleRate
        ),
        transcription_semi_structured_qa_sample_rate: str | float = workflow_input(
            Settings.TranscriptionSemiStructuredQaSampleRate
        ),
        table_cell_transcription_qa_enabled: str | bool = workflow_input(
            Settings.TableCellTranscriptionQaEnabled
        ),
        table_cell_transcription_qa_sample_rate: str | int | float = workflow_input(
            Settings.TableCellTranscriptionQaSampleRate
        ),
        auto_qa_sampling_rate_enabled: str | bool = workflow_input(
            Settings.AutoQaSamplingRateEnabled
        ),
        exclude_auto_transcribe_fields_from_qa: str | bool = workflow_input(
            Settings.ExcludeAutoTranscribeFieldsFromQA
        ),
        payload: Any = None,
    ) -> None:
        inputs = {
            'submission': submission,
            'is_reprocessing': is_reprocessing,
            'nlc_qa_sampling_ratio': nlc_qa_sampling_ratio,
            'field_id_qa_enabled': field_id_qa_enabled,
            'field_id_qa_sampling_ratio': field_id_qa_sampling_ratio,
            'table_id_qa_enabled': table_id_qa_enabled,
            'table_id_qa_sampling_ratio': table_id_qa_sampling_ratio,
            'transcription_qa_enabled': transcription_qa_enabled,
            'transcription_structured_entry_qa_sample_rate': (
                transcription_structured_entry_qa_sample_rate
            ),
            'transcription_structured_checkbox_qa_sample_rate': (
                transcription_structured_checkbox_qa_sample_rate
            ),
            'transcription_structured_signature_qa_sample_rate': (
                transcription_structured_signature_qa_sample_rate
            ),
            'transcription_semi_structured_qa_sample_rate': (
                transcription_semi_structured_qa_sample_rate
            ),
            'table_cell_transcription_qa_enabled': table_cell_transcription_qa_enabled,
            'table_cell_transcription_qa_sample_rate': table_cell_transcription_qa_sample_rate,
            'auto_qa_sampling_rate_enabled': auto_qa_sampling_rate_enabled,
            'exclude_auto_transcribe_fields_from_qa': exclude_auto_transcribe_fields_from_qa,
        }

        if payload is not None:
            inputs['payload'] = payload

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title='Complete',
            description='Finalize submission processing and update reporting data',
        )
