from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v44.idp_blocks.common_settings import IdpSystemSettings
from flows_sdk.implementations.idp_v44.idp_blocks.flow_inputs import IdpFlowInputs
from flows_sdk.implementations.idp_v44.idp_blocks.submission_bootstrap.settings import (
    SubmissionBootstrapSettings as Settings,
)
from flows_sdk.utils import workflow_input


class SubmissionBootstrapBlock(Block):
    """Submission bootstrap block initializes the submission object and prepares external images
    or other submission data if needed.
    **This block should be called at the START of every flow** that
    uses blocks included in the library.

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param trigger: the trigger input from a connector - if not set explicitly,
        it will default to the workflow input trigger (which is where this value is normally found)
    :param layout_release_uuid: Layout Release UUID at submission creation time,
        defaults to workflow_input(Settings.LayoutReleaseUuid)
    :param s3_config: Specify Amazon S3 credentials for submission retrieval store.
        Expects a json expression: ``{"aws_access_key_id": "X", "aws_secret_access_key": "Y"}``,
        defaults to workflow_input(Settings.SubmissionBootstrapS3Config)
    :param s3_endpoint_url: Endpoint URL for S3 submission retrieval store,
        defaults to workflow_input(Settings.SubmissionBootstrapS3EndpointUrl)
    :param ocs_config: OCS Configuration for downloading submission data.
        @deprecated since v43.1; will be removed in v46.0.
        defaults to workflow_input(Settings.SubmissionBootstrapOCSConfig)
    :param ocs_host_url: Available from V42.3; OCS host URL for submission retrieval store,
        @deprecated since v43.1; will be removed in v46.0.
        defaults to workflow_input(Settings.SubmissionBootstrapOCSHostUrl)
    :param ocs_username: Available from V42.3; OCS username for authentication,
        @deprecated since v43.1; will be removed in v46.0.
        defaults to workflow_input(Settings.SubmissionBootstrapOCSUsername)
    :param ocs_password: Available from V42.3; OCS password for authentication,
        @deprecated since v43.1; will be removed in v46.0.
        defaults to workflow_input(Settings.SubmissionBootstrapOCSPassword)
    :param ocs_ssl_cert: Available from V42.3; CA bundle filename inside $HS_PATH/certs directory or
        "SKIP" to disable validation,
        @deprecated since v43.1; will be removed in v46.0.
        defaults to workflow_input(Settings.SubmissionBootstrapOCSSslCert)
    :param http_config:
        An optional system secret field expressing the HTTP Configuration for
        downloading submission data. The content is expected to be a json formatted as:
        ``{"username": "X", "password": "Y", "ssl_cert": "CA bundle filename"}``,
        defaults to workflow_input(Settings.SubmissionBootstrapHTTPConfig)
    :param oauth_token_url:
        OAuth token endpoint for client credentials authentication.
    :param oauth_client_id: Client ID for OAuth client credentials.
    :param oauth_client_secret: Client secret for OAuth client credentials.
    :param oauth_scope:
        Optional OAuth scope sent with the OAuth client credentials token request.
    :param abs_auth_type: The type of authentication to use for Azure Blob Storage
        ('SAS Token Only' / 'Service Principal' / 'Managed Identity' / 'Account Key'),
        defaults to workflow_input(Settings.SubmissionBootstrapABSAuthType)
    :param abs_account_url: The URL of the Azure Blob Storage account,
        defaults to workflow_input(Settings.SubmissionBootstrapABSAccountUrl)
    :param abs_tenant_id: The tenant ID of the service principal,
        defaults to workflow_input(Settings.SubmissionBootstrapABSTenantId)
    :param abs_client_id: The client ID of the service principal or managed identity,
        defaults to workflow_input(Settings.SubmissionBootstrapABSClientId)
    :param abs_client_secret: The client secret of the service principal,
        defaults to workflow_input(Settings.SubmissionBootstrapABSClientSecret)
    :param abs_authority_host: The authority host of the service principal,
        defaults to workflow_input(Settings.SubmissionBootstrapABSAuthorityHost)
    :param abs_account_name: The account name of the Azure Blob Storage account,
        defaults to workflow_input(Settings.SubmissionBootstrapABSAccountName)
    :param abs_account_key: The account key of the Azure Blob Storage account,
        defaults to workflow_input(Settings.SubmissionBootstrapABSAccountKey)
    :param gcs_credentials_json: GCS service account credentials in JSON format,
        defaults to workflow_input(Settings.SubmissionBootstrapGCSCredentialsJson)
    :param gcs_workload_identity:
        Whether to obtain the credentials by using the Workload Identity Federation,
        applicable for HS installations inside GKE clusters,
        defaults to workflow_input(Settings.SubmissionBootstrapGCSWorkloadIdentity)
    :param max_number_pages_enabled: An optional parameter (flag) controlling whether the
        configured max number of pages is taken into account
    :param max_number_pages: An optional parameter specifying the max number of pages for
        downstream processing. Submissions with pages exceeding this configured value will fail.
        The default value is set to 10_000 pages.
    :param notification_workflow: Notification flow name to run when the submission is initialized,
        defaults to workflow_input(Settings.SubmissionBootstrapNotificationWorkflow)
    :param workflow_uuid: UUID of the triggered workflow version,
        defaults to workflow_input(Inputs.WorkflowUuid)
    :param workflow_name: Name of the triggered workflow,
        defaults to workflow_input(Inputs.WorkflowName)
    :param workflow_version: Version of the triggered workflow,
        defaults to workflow_input(Inputs.WorkflowVersion)
    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>`
        object
    :param oauth_client_auth_method:
        How OAuth client credentials are sent to the token endpoint.

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>`
      object.
    * `api_params`: a dictionary containing the parameters with which the submission was
      initialized. Extracted from the block's trigger input.

    Example usage::

        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
    """

    IDENTIFIER = 'SUBMISSION_BOOTSTRAP_4'

    def __init__(
        self,
        reference_name: str | None = None,
        trigger: str = workflow_input(IdpFlowInputs.Trigger),
        layout_release_uuid: str = workflow_input(IdpSystemSettings.LayoutReleaseUuid),
        s3_config: str = workflow_input(Settings.SubmissionBootstrapS3Config),
        s3_endpoint_url: str = workflow_input(Settings.SubmissionBootstrapS3EndpointUrl),
        ocs_config: str = workflow_input(Settings.SubmissionBootstrapOCSConfig),
        ocs_host_url: str | None = workflow_input(Settings.SubmissionBootstrapOCSHostUrl),
        ocs_username: str | None = workflow_input(Settings.SubmissionBootstrapOCSUsername),
        ocs_password: str | None = workflow_input(Settings.SubmissionBootstrapOCSPassword),
        ocs_ssl_cert: str | None = workflow_input(Settings.SubmissionBootstrapOCSSslCert),
        http_config: str | None = workflow_input(Settings.SubmissionBootstrapHTTPConfig),
        oauth_token_url: str | None = workflow_input(Settings.SubmissionBootstrapOAuthTokenUrl),
        oauth_client_id: str | None = workflow_input(Settings.SubmissionBootstrapOAuthClientId),
        oauth_client_secret: str | None = workflow_input(
            Settings.SubmissionBootstrapOAuthClientSecret
        ),
        oauth_scope: str | None = workflow_input(Settings.SubmissionBootstrapOAuthScope),
        abs_auth_type: str | None = workflow_input(Settings.SubmissionBootstrapABSAuthType),
        abs_account_url: str | None = workflow_input(Settings.SubmissionBootstrapABSAccountUrl),
        abs_tenant_id: str | None = workflow_input(Settings.SubmissionBootstrapABSTenantId),
        abs_client_id: str | None = workflow_input(Settings.SubmissionBootstrapABSClientId),
        abs_client_secret: str | None = workflow_input(Settings.SubmissionBootstrapABSClientSecret),
        abs_authority_host: str | None = workflow_input(
            Settings.SubmissionBootstrapABSAuthorityHost
        ),
        abs_account_name: str | None = workflow_input(Settings.SubmissionBootstrapABSAccountName),
        abs_account_key: str | None = workflow_input(Settings.SubmissionBootstrapABSAccountKey),
        gcs_credentials_json: str = workflow_input(Settings.SubmissionBootstrapGCSCredentialsJson),
        gcs_workload_identity: str = workflow_input(
            Settings.SubmissionBootstrapGCSWorkloadIdentity
        ),
        max_number_pages_enabled: str | None = workflow_input(
            Settings.SubmissionBootstrapMaxNumberOfPagesEnabled
        ),
        max_number_pages: str | None = workflow_input(Settings.SubmissionBootstrapMaxNumberOfPages),
        notification_workflow: str | None = workflow_input(
            Settings.SubmissionBootstrapNotificationWorkflow
        ),
        workflow_uuid: str = workflow_input(IdpFlowInputs.WorkflowUuid),
        workflow_name: str = workflow_input(IdpFlowInputs.WorkflowName),
        workflow_version: str = workflow_input(IdpFlowInputs.WorkflowVersion),
        submission: dict[str, Any] | str | None = workflow_input(IdpFlowInputs.Submission),
        oauth_client_auth_method: str | None = workflow_input(
            Settings.SubmissionBootstrapOAuthClientAuthMethod
        ),
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                '$trigger': trigger,
                'layout_release_uuid': layout_release_uuid,
                's3_config': s3_config,
                's3_endpoint_url': s3_endpoint_url,
                'ocs_config': ocs_config,
                'ocs_host_url': ocs_host_url,
                'ocs_username': ocs_username,
                'ocs_password': ocs_password,
                'ocs_ssl_cert': ocs_ssl_cert,
                'http_config': http_config,
                'oauth_token_url': oauth_token_url,
                'oauth_client_id': oauth_client_id,
                'oauth_client_secret': oauth_client_secret,
                'oauth_client_auth_method': oauth_client_auth_method,
                'oauth_scope': oauth_scope,
                'abs_auth_type': abs_auth_type,
                'abs_account_url': abs_account_url,
                'abs_tenant_id': abs_tenant_id,
                'abs_client_id': abs_client_id,
                'abs_client_secret': abs_client_secret,
                'abs_authority_host': abs_authority_host,
                'abs_account_name': abs_account_name,
                'abs_account_key': abs_account_key,
                'gcs_credentials_json': gcs_credentials_json,
                'gcs_workload_identity': gcs_workload_identity,
                'max_number_pages_enabled': max_number_pages_enabled,
                'max_number_pages': max_number_pages,
                'notification_workflow': notification_workflow,
                'workflow_uuid': workflow_uuid,
                'workflow_name': workflow_name,
                'workflow_version': workflow_version,
                'submission': submission,
            },
            title='Submission Initialization',
            description=(
                'Initialize submission and, if necessary, fetch and prepare '
                'external images or other submission data'
            ),
        )
