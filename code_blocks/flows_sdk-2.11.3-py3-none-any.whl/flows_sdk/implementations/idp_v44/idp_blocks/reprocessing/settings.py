from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs


class ReprocessingSettings(BaseInputs):
    ReprocessingEnabled = 'reprocessing_enabled'

    @classmethod
    def create(cls, reprocessing_enabled: bool) -> dict[str, Any]:
        return {
            cls.ReprocessingEnabled: reprocessing_enabled,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.ReprocessingEnabled,
                type='boolean',
                title='Reprocessing Enabled',
                value=True,
            ),
        ]
