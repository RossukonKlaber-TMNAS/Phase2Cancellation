from flows_sdk.implementations.idp_v44.idp_blocks.manual_classification.block import (
    ManualClassificationBlock,
)
from flows_sdk.implementations.idp_v44.idp_blocks.manual_classification.settings import (
    ManualClassificationSettings,
)

__all__ = ['ManualClassificationBlock', 'ManualClassificationSettings']
