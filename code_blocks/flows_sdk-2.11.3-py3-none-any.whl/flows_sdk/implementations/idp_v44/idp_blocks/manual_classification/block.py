from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v44.idp_blocks.manual_classification.settings import (
    ManualClassificationSettings as Settings,
)
from flows_sdk.utils import workflow_input


class ManualClassificationBlock(Block):
    """Manual classification block allows keyers to manually match submissions to their layouts.
    Keyers may perform manual classification if machine classification cannot automatically
    match a submission to a layout with high confidence

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>`
        object
    :param api_params:

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param layout_release_uuid: Layout Release UUID at submission creation time,
        defaults to workflow_input(Settings.LayoutReleaseUuid)
    :param manual_nlc_enabled: Enables manual classification when applicable,
        defaults to workflow_input(Settings.ManualNlcEnabled)
    :param task_restrictions: Defines what users can access Supervision tasks created
        by this block,
        defaults to workflow_input(Settings.ManualClassificationTaskRestrictions)
    :param notification_workflow: Notification flow name to run when the submission
        enters Manual Classification,
        defaults to workflow_input(Settings.ManualClassificationNotificationWorkflow)
    :param vpc_registration_threshold: Structured pages above this threshold will be
        automatically matched to a layout variation when performing light vpc registration
        in the doc-org task,
        defaults to workflow_input(Settings.StructuredLayoutMatchThreshold)
    :param nlc_metadata: Optional NLC metadata containing predictions per page from
        machine classification, used to populate best-guess layout suggestions in
        the manual classification supervision task,
        defaults to None

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>` with
      the `documents` and `unassigned_pages` fields updated with the classification results.
    * `supervision_metadata`: Metadata about the created supervision task.

    Example usage::

        manual_classification = ManualClassificationBlock(
            reference_name='manual_classification',
            submission=machine_classification.output('submission'),
            api_params=submission_bootstrap.output('result.api_params'),
        )
    """

    IDENTIFIER = 'MANUAL_CLASSIFICATION_7'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        api_params: dict[str, Any] | str,
        reference_name: str | None = None,
        layout_release_uuid: str = workflow_input(Settings.LayoutReleaseUuid),
        manual_nlc_enabled: str | bool = workflow_input(Settings.ManualNlcEnabled),
        task_restrictions: list[Any] | str | None = workflow_input(
            Settings.ManualClassificationTaskRestrictions
        ),
        notification_workflow: str | None = workflow_input(
            Settings.ManualClassificationNotificationWorkflow
        ),
        vpc_registration_threshold: str | float | None = workflow_input(
            Settings.StructuredLayoutMatchThreshold
        ),
        nlc_metadata: dict[str, Any] | str | None = None,
    ) -> None:
        if task_restrictions is None:
            task_restrictions = []
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'layout_release_uuid': layout_release_uuid,
                'manual_nlc_enabled': manual_nlc_enabled,
                'task_restrictions': task_restrictions,
                'api_params': api_params,
                'submission': submission,
                'notification_workflow': notification_workflow,
                'vpc_registration_threshold': vpc_registration_threshold,
                'nlc_metadata': nlc_metadata,
            },
            title='Manual Classification',
            description='Manually classify documents that could not be automatically classified',
        )
