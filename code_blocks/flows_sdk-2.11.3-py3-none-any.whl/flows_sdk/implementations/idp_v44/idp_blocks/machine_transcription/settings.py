from dataclasses import dataclass
from enum import Enum
from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.idp_blocks.common_settings import (
    ORCA_ONLY_EXTRACTION_DEPENDENCY,
    ExtractionSettings,
    IdpSystemSettings,
    TranscriptionSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.custom_types import (
    CustomTypes,
    SingleEntityTargetAccuracy,
)
from flows_sdk.implementations.idp_v44.idp_blocks.defaults import EXACT_PERCENT_SCHEMA
from flows_sdk.implementations.idp_v44.licensing.licensing import FeatureGatingCommonDependencies


class FinetuningConfig:
    STRUCTURED_TRAINING_TYPE = 'structured'
    SEMI_STRUCTURED_TRAINING_TYPE = 'semi_structured'


# TODO(FLOWS-2135): this is a duplication from common.utils
class FieldTypeByKind(Enum):
    ENTRY = 'entry'
    SIGNATURE = 'signature'
    CHECKBOX = 'checkbox'
    FLEX_ENTRY = 'flex_entry'
    FLEX_CHECKBOX = 'flex_checkbox'
    FLEX_TABLE_ENTRY = 'flex_table_entry'


@dataclass
class TranscriptionConfig:
    min_samples: int
    max_samples: int
    target_accuracy: float
    confidence_threshold: float
    acceptable_confidence: float


class BaseStructuredSettings(BaseInputs):
    StructuredTranscriptionTraining = 'structured_transcription_training'
    StructuredTranscriptionTrainingPeriod = 'structured_transcription_training_period'
    StructuredImprovedTranscrThresholdAccuracy = 'structured_improved_transcr_threshold_accuracy'

    @classmethod
    def create(
        cls, training_enabled: bool, training_period: int, improved_threshold_accuracy: bool
    ) -> dict[str, Any]:
        return {
            cls.StructuredTranscriptionTraining: training_enabled,
            cls.StructuredTranscriptionTrainingPeriod: training_period,
            cls.StructuredImprovedTranscrThresholdAccuracy: improved_threshold_accuracy,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.StructuredTranscriptionTraining,
                type=CustomTypes.TranscriptionAutomationTraining,
                schema={
                    'type': 'boolean',
                    'training_type': FinetuningConfig.STRUCTURED_TRAINING_TYPE,
                },
                value=True,
                title='Transcription Automation Training',
                description=(
                    'Uses QA data for on-premise machine learning'
                    ' to improve transcription automation.'
                ),
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredTranscriptionTrainingPeriod,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                value=30,
                title='Period of records to use',
                ui={'prefix': 'Past', 'suffix': 'days'},
                dependencies=[
                    Dependency(
                        condition={
                            'properties': {cls.StructuredTranscriptionTraining: {'const': False}}
                        },
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Transcription Automation Training'
                                    ' is disabled.'
                                )
                            }
                        },
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.StructuredImprovedTranscrThresholdAccuracy,
                type='boolean',
                value=True,
                title='Improved threshold accuracy',
                dependencies=[
                    Dependency(
                        condition={
                            'properties': {cls.StructuredTranscriptionTraining: {'const': False}}
                        },
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Transcription Automation Training'
                                    ' is disabled.'
                                )
                            }
                        },
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
        ]


class StructuredTextSettings(BaseStructuredSettings, BaseInputs):
    StructuredTextMinTrainingRecords = 'structured_text_min_training_records'
    StructuredTextMaxTrainingRecords = 'structured_text_max_training_records'
    StructuredTextTargetAccuracy = 'structured_text_target_accuracy'
    StructuredTextAutomation = 'structured_text_automation'
    StructuredTextThreshold = 'structured_text_threshold'
    StructuredTextMinLegThreshold = 'structured_min_leg_threshold'

    @classmethod
    def create(cls, config: TranscriptionConfig) -> dict[str, Any]:  # type: ignore[override]
        return {
            cls.StructuredTextMinTrainingRecords: config.min_samples,
            cls.StructuredTextMaxTrainingRecords: config.max_samples,
            cls.StructuredTextTargetAccuracy: config.target_accuracy,
            cls.StructuredTextThreshold: config.confidence_threshold,
            cls.StructuredTextMinLegThreshold: config.acceptable_confidence,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.StructuredTextMinTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Structured Text Min Training Records',
                value=2000,
                ui={'hidden': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredTextMaxTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Structured Text Max Training Records',
                value=50000,
                ui={'hidden': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredTextTargetAccuracy,
                type='TranscriptionTargetAccuracy',
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.ENTRY.value,
                    'min_training_records_prop': cls.StructuredTextMinTrainingRecords,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Text Target Accuracy',
                value=0.95,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredTextAutomation,
                type=CustomTypes.TranscriptionAutomation,
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.ENTRY.value,
                    'target_accuracy_prop': cls.StructuredTextTargetAccuracy,
                    'min_training_records_prop': cls.StructuredTextMinTrainingRecords,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Text Automation',
                description=(
                    'This number shows the amount of automation you will get based on the '
                    'target accuracy.'
                ),
                value=0,
                ui={'disabled': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredTextThreshold,
                type=CustomTypes.TranscriptionThreshold,
                schema={
                    'type': 'number',
                    'minimum': 0,
                    'maximum': 1,
                    'entity_type': FieldTypeByKind.ENTRY.value,
                    'target_accuracy_prop': cls.StructuredTextTargetAccuracy,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Text Threshold',
                description=(
                    'A Transcription model is deployed for this flow. The threshold is '
                    'automatically calculated based on the Target Accuracy and cannot be edited '
                    'manually.'
                ),
                value=0.52,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredTextMinLegThreshold,
                type='number',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='Structured Text Minimum Legibility Threshold',
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
        ]


class StructuredCheckboxSettings(BaseStructuredSettings, BaseInputs):
    StructuredCheckboxMinTrainingRecords = 'structured_checkbox_min_training_records'
    StructuredCheckboxMaxTrainingRecords = 'structured_checkbox_max_training_records'
    StructuredCheckboxTargetAccuracy = 'structured_checkbox_target_accuracy'
    StructuredCheckboxAutomation = 'structured_checkbox_automation'
    StructuredCheckboxThreshold = 'structured_checkbox_threshold'
    StructuredCheckboxMinLegThreshold = 'checkbox_min_leg_threshold'

    @classmethod
    def create(cls, config: TranscriptionConfig) -> dict[str, Any]:  # type: ignore[override]
        return {
            cls.StructuredCheckboxMinTrainingRecords: config.min_samples,
            cls.StructuredCheckboxMaxTrainingRecords: config.max_samples,
            cls.StructuredCheckboxTargetAccuracy: config.target_accuracy,
            cls.StructuredCheckboxThreshold: config.confidence_threshold,
            cls.StructuredCheckboxMinLegThreshold: config.acceptable_confidence,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.StructuredCheckboxMinTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Structured Checkbox Min Training Records',
                value=2000,
                ui={'hidden': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredCheckboxMaxTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Structured Checkbox Max Training Records',
                value=50000,
                ui={'hidden': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredCheckboxTargetAccuracy,
                type='TranscriptionTargetAccuracy',
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.CHECKBOX.value,
                    'min_training_records_prop': cls.StructuredCheckboxMinTrainingRecords,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Checkbox Target Accuracy',
                value=0.95,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredCheckboxAutomation,
                type=CustomTypes.TranscriptionAutomation,
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.CHECKBOX.value,
                    'target_accuracy_prop': cls.StructuredCheckboxTargetAccuracy,
                    'min_training_records_prop': cls.StructuredCheckboxMinTrainingRecords,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Checkbox Automation',
                description=(
                    'This number shows the amount of automation you will get based on the '
                    'target accuracy.'
                ),
                value=0,
                ui={'disabled': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredCheckboxThreshold,
                type=CustomTypes.TranscriptionThreshold,
                schema={
                    'type': 'number',
                    'minimum': 0,
                    'maximum': 1,
                    'entity_type': FieldTypeByKind.CHECKBOX.value,
                    'target_accuracy_prop': cls.StructuredCheckboxTargetAccuracy,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Checkbox Threshold',
                description=(
                    'A Transcription model is deployed for this flow. The threshold is '
                    'automatically calculated based on the Target Accuracy and cannot be edited '
                    'manually.'
                ),
                value=0.56,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredCheckboxMinLegThreshold,
                type='number',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='Structured Checkbox Minimum Legibility Threshold',
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
        ]


class StructuredSignatureSettings(BaseStructuredSettings, BaseInputs):
    StructuredSignatureMinTrainingRecords = 'structured_signature_min_training_records'
    StructuredSignatureMaxTrainingRecords = 'structured_signature_max_training_records'
    StructuredSignatureTargetAccuracy = 'structured_signature_target_accuracy'
    StructuredSignatureAutomation = 'structured_signature_automation'
    StructuredSignatureThreshold = 'structured_signature_threshold'
    StructuredSignatureMinLegThreshold = 'signature_min_leg_threshold'

    @classmethod
    def create(cls, config: TranscriptionConfig) -> dict[str, Any]:  # type: ignore[override]
        return {
            cls.StructuredSignatureMinTrainingRecords: config.min_samples,
            cls.StructuredSignatureMaxTrainingRecords: config.max_samples,
            cls.StructuredSignatureTargetAccuracy: config.target_accuracy,
            cls.StructuredSignatureThreshold: config.confidence_threshold,
            cls.StructuredSignatureMinLegThreshold: config.acceptable_confidence,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.StructuredSignatureMinTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Structured Signature Min Training Records',
                value=2000,
                ui={'hidden': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredSignatureMaxTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Structured Signature Max Training Records',
                value=50000,
                ui={'hidden': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredSignatureTargetAccuracy,
                type='TranscriptionTargetAccuracy',
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.SIGNATURE.value,
                    'min_training_records_prop': cls.StructuredSignatureMinTrainingRecords,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Signature Target Accuracy',
                value=0.95,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredSignatureAutomation,
                type=CustomTypes.TranscriptionAutomation,
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.SIGNATURE.value,
                    'target_accuracy_prop': cls.StructuredSignatureTargetAccuracy,
                    'min_training_records_prop': cls.StructuredSignatureMinTrainingRecords,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Signature Automation',
                description=(
                    'This number shows the amount of automation you will get based on the '
                    'target accuracy.'
                ),
                value=0,
                ui={'disabled': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredSignatureThreshold,
                type=CustomTypes.TranscriptionThreshold,
                schema={
                    'type': 'number',
                    'minimum': 0,
                    'maximum': 1,
                    'entity_type': FieldTypeByKind.SIGNATURE.value,
                    'target_accuracy_prop': cls.StructuredSignatureTargetAccuracy,
                    'training_period_prop': cls.StructuredTranscriptionTrainingPeriod,
                },
                title='Structured Signature Threshold',
                description=(
                    'A Transcription model is deployed for this flow. The threshold is '
                    'automatically calculated based on the Target Accuracy and cannot be edited '
                    'manually.'
                ),
                value=0.99,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.StructuredSignatureMinLegThreshold,
                type='number',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='Structured Signature Minimum Legibility Threshold',
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
        ]


class BaseSemiStructuredSettings(BaseInputs):
    SemiStructuredTranscriptionTraining = 'semi_structured_transcription_training'
    SemiStructuredTranscriptionTrainingPeriod = 'semi_structured_transcription_training_period'
    SemiStructuredImprovedTranscrThresholdAccuracy = (
        'semi_structured_improved_transcr_threshold_accuracy'
    )

    @classmethod
    def create(
        cls, training_enabled: bool, training_period: int, improved_threshold_accuracy: bool
    ) -> dict[str, Any]:
        return {
            cls.SemiStructuredTranscriptionTraining: training_enabled,
            cls.SemiStructuredTranscriptionTrainingPeriod: training_period,
            cls.SemiStructuredImprovedTranscrThresholdAccuracy: improved_threshold_accuracy,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.SemiStructuredTranscriptionTraining,
                type=CustomTypes.TranscriptionAutomationTraining,
                schema={
                    'type': 'boolean',
                    'training_type': FinetuningConfig.SEMI_STRUCTURED_TRAINING_TYPE,
                },
                value=True,
                title='Transcription Automation Training',
                description=(
                    'Uses QA data for on-premise machine learning'
                    ' to improve transcription automation.'
                ),
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTranscriptionTrainingPeriod,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                value=30,
                title='Period of records to use',
                ui={'prefix': 'Past', 'suffix': 'days'},
                dependencies=[
                    Dependency(
                        condition={
                            'properties': {
                                cls.SemiStructuredTranscriptionTraining: {'const': False}
                            }
                        },
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Transcription Automation Training'
                                    ' is disabled.'
                                )
                            }
                        },
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.SemiStructuredImprovedTranscrThresholdAccuracy,
                type='boolean',
                value=True,
                title='Improved threshold accuracy',
                dependencies=[
                    Dependency(
                        condition={
                            'properties': {
                                cls.SemiStructuredTranscriptionTraining: {'const': False}
                            }
                        },
                        override={
                            'ui': {
                                'na_reason': (
                                    'Not applied when Transcription Automation Training'
                                    ' is disabled.'
                                )
                            }
                        },
                    ),
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
        ]


class SemiStructuredFieldTextSettings(BaseSemiStructuredSettings, BaseInputs):
    SemiStructuredTextMinTrainingRecords = 'semi_structured_text_min_training_records'
    SemiStructuredTextMaxTrainingRecords = 'semi_structured_text_max_training_records'
    SemiStructuredTextTargetAccuracy = 'semi_structured_text_target_accuracy'
    SemiStructuredTextAutomation = 'semi_structured_text_automation'
    SemiStructuredTextThreshold = 'semi_structured_text_threshold'
    SemiStructuredTextMinLegThreshold = 'semi_structured_min_leg_threshold'

    @classmethod
    def create(cls, config: TranscriptionConfig) -> dict[str, Any]:  # type: ignore[override]
        return {
            cls.SemiStructuredTextMinTrainingRecords: config.min_samples,
            cls.SemiStructuredTextMaxTrainingRecords: config.max_samples,
            cls.SemiStructuredTextTargetAccuracy: config.target_accuracy,
            cls.SemiStructuredTextThreshold: config.confidence_threshold,
            cls.SemiStructuredTextMinLegThreshold: config.acceptable_confidence,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.SemiStructuredTextMinTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Semi-Structured Text Min Training Records',
                value=2000,
                ui={'hidden': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTextMaxTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Semi-Structured Text Max Training Records',
                value=50000,
                ui={'hidden': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTextTargetAccuracy,
                type='TranscriptionTargetAccuracy',
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.FLEX_ENTRY.value,
                    'min_training_records_prop': cls.SemiStructuredTextMinTrainingRecords,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Semi-Structured Text Target Accuracy',
                value=0.95,
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTextAutomation,
                type=CustomTypes.TranscriptionAutomation,
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.FLEX_ENTRY.value,
                    'target_accuracy_prop': cls.SemiStructuredTextTargetAccuracy,
                    'min_training_records_prop': cls.SemiStructuredTextMinTrainingRecords,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Semi-Structured Text Automation',
                description=(
                    'This number shows the amount of automation you will get based on the '
                    'target accuracy.'
                ),
                value=0,
                ui={'disabled': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTextThreshold,
                type=CustomTypes.TranscriptionThreshold,
                schema={
                    'type': 'number',
                    'minimum': 0,
                    'maximum': 1,
                    'entity_type': FieldTypeByKind.FLEX_ENTRY.value,
                    'target_accuracy_prop': cls.SemiStructuredTextTargetAccuracy,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Semi-Structured Text Threshold',
                description=(
                    'A Transcription model is deployed for this flow. The threshold is '
                    'automatically calculated based on the Target Accuracy and cannot be edited '
                    'manually.'
                ),
                value=0.52,
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTextMinLegThreshold,
                type='number',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='Semi-Structured Text Minimum Legibility Threshold',
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
        ]


class SemiStructuredTableTextSettings(BaseSemiStructuredSettings, BaseInputs):
    SemiStructuredTableMinTrainingRecords = 'semi_structured_table_min_training_records'
    SemiStructuredTableMaxTrainingRecords = 'semi_structured_table_max_training_records'
    SemiStructuredTableTargetAccuracy = 'semi_structured_table_target_accuracy'
    SemiStructuredTableAutomation = 'semi_structured_table_automation'
    SemiStructuredTableThreshold = 'semi_structured_table_threshold'
    SemiStructuredTableMinLegThreshold = 'semi_structured_table_min_leg_threshold'

    @classmethod
    def create(cls, config: TranscriptionConfig) -> dict[str, Any]:  # type: ignore[override]
        return {
            cls.SemiStructuredTableMinTrainingRecords: config.min_samples,
            cls.SemiStructuredTableMaxTrainingRecords: config.max_samples,
            cls.SemiStructuredTableTargetAccuracy: config.target_accuracy,
            cls.SemiStructuredTableThreshold: config.confidence_threshold,
            cls.SemiStructuredTableMinLegThreshold: config.acceptable_confidence,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.SemiStructuredTableMinTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Table Min Training Records',
                value=2000,
                ui={'hidden': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTableMaxTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Table Max Training Records',
                value=50000,
                ui={'hidden': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTableTargetAccuracy,
                type='TranscriptionTargetAccuracy',
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.FLEX_TABLE_ENTRY.value,
                    'min_training_records_prop': cls.SemiStructuredTableMinTrainingRecords,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Table Target Accuracy',
                value=0.95,
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTableAutomation,
                type=CustomTypes.TranscriptionAutomation,
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.FLEX_TABLE_ENTRY.value,
                    'target_accuracy_prop': cls.SemiStructuredTableTargetAccuracy,
                    'min_training_records_prop': cls.SemiStructuredTableMinTrainingRecords,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Table Automation',
                description=(
                    'This number shows the amount of automation you will get based on the '
                    'target accuracy.'
                ),
                value=0,
                ui={'disabled': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTableThreshold,
                type=CustomTypes.TranscriptionThreshold,
                schema={
                    'type': 'number',
                    'minimum': 0,
                    'maximum': 1,
                    'entity_type': FieldTypeByKind.FLEX_TABLE_ENTRY.value,
                    'target_accuracy_prop': cls.SemiStructuredTableTargetAccuracy,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Table Threshold',
                description=(
                    'A Transcription model is deployed for this flow. The threshold is '
                    'automatically calculated based on the Target Accuracy and cannot be edited '
                    'manually.'
                ),
                value=0.52,
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredTableMinLegThreshold,
                type='number',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='Table Minimum Legibility Threshold',
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
        ]


class SemiStructuredCheckboxSettings(BaseSemiStructuredSettings, BaseInputs):
    SemiStructuredCheckboxMinTrainingRecords = 'semi_structured_checkbox_min_training_records'
    SemiStructuredCheckboxMaxTrainingRecords = 'semi_structured_checkbox_max_training_records'
    SemiStructuredCheckboxTargetAccuracy = 'semi_structured_checkbox_target_accuracy'
    SemiStructuredCheckboxAutomation = 'semi_structured_checkbox_automation'
    SemiStructuredCheckboxThreshold = 'semi_structured_checkbox_threshold'
    SemiStructuredCheckboxMinLegThreshold = 'semi_structured_checkbox_min_leg_threshold'

    @classmethod
    def create(cls, config: TranscriptionConfig) -> dict[str, Any]:  # type: ignore[override]
        return {
            cls.SemiStructuredCheckboxMinTrainingRecords: config.min_samples,
            cls.SemiStructuredCheckboxMaxTrainingRecords: config.max_samples,
            cls.SemiStructuredCheckboxTargetAccuracy: config.target_accuracy,
            cls.SemiStructuredCheckboxThreshold: config.confidence_threshold,
            cls.SemiStructuredCheckboxMinLegThreshold: config.acceptable_confidence,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.SemiStructuredCheckboxMinTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Semi-Structured Checkbox Min Training Records',
                value=2000,
                ui={'hidden': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredCheckboxMaxTrainingRecords,
                type='integer',
                schema={'type': 'integer', 'minimum': 0},
                title='Semi-Structured Checkbox Max Training Records',
                value=50000,
                ui={'hidden': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredCheckboxTargetAccuracy,
                type='TranscriptionTargetAccuracy',
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.FLEX_CHECKBOX.value,
                    'min_training_records_prop': cls.SemiStructuredCheckboxMinTrainingRecords,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Semi-Structured Checkbox Target Accuracy',
                value=0.95,
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredCheckboxAutomation,
                type=CustomTypes.TranscriptionAutomation,
                schema={
                    **EXACT_PERCENT_SCHEMA,
                    'entity_type': FieldTypeByKind.FLEX_CHECKBOX.value,
                    'target_accuracy_prop': cls.SemiStructuredCheckboxTargetAccuracy,
                    'min_training_records_prop': cls.SemiStructuredCheckboxMinTrainingRecords,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Semi-Structured Checkbox Automation',
                description=(
                    'This number shows the amount of automation you will get based on the '
                    'target accuracy.'
                ),
                value=0,
                ui={'disabled': True},
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredCheckboxThreshold,
                type=CustomTypes.TranscriptionThreshold,
                schema={
                    'type': 'number',
                    'minimum': 0,
                    'maximum': 1,
                    'entity_type': FieldTypeByKind.FLEX_CHECKBOX.value,
                    'target_accuracy_prop': cls.SemiStructuredCheckboxTargetAccuracy,
                    'training_period_prop': cls.SemiStructuredTranscriptionTrainingPeriod,
                },
                title='Semi-Structured Checkbox Threshold',
                description=(
                    'A Transcription model is deployed for this flow. The threshold is '
                    'automatically calculated based on the Target Accuracy and cannot be edited '
                    'manually.'
                ),
                value=0.56,
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.SemiStructuredCheckboxMinLegThreshold,
                type='number',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='Semi-Structured Checkbox Minimum Legibility Threshold',
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
        ]


class MachineTranscriptionSettings(
    IdpSystemSettings,
    StructuredTextSettings,
    StructuredCheckboxSettings,
    StructuredSignatureSettings,
    SemiStructuredFieldTextSettings,
    SemiStructuredTableTextSettings,
    SemiStructuredCheckboxSettings,
    TranscriptionSettings,
    ExtractionSettings,
    BaseInputs,
):
    TranscriptionModel = 'transcription_model'
    TranscriptionOverrides = 'transcription_overrides'
    FieldTranscriptionTargetAccuracies = 'field_transcription_target_accuracies'
    FinetuningOnlyTrainedLayouts = 'finetuning_only_trained_layouts'

    ForceNormalizationErrorsToSV = 'force_normalization_errors_to_sv'

    @classmethod
    def create(  # type: ignore[override]
        cls,
        transcription_model: str,
        target_accuracies: list[SingleEntityTargetAccuracy] | None,
        finetuning_only_trained_layouts: bool,
        manual_transcription_enabled: bool,
        always_supervise_blank_cells: bool,
        structured_training_enabled: bool,
        structured_training_period: int,
        structured_improved_threshold_accuracy: bool,
        structured_text_config: TranscriptionConfig,
        structured_checkbox_config: TranscriptionConfig,
        structured_signature_config: TranscriptionConfig,
        semi_structured_training_enabled: bool,
        semi_structured_training_period: int,
        semi_structured_improved_threshold_accuracy: bool,
        semi_structured_field_text_config: TranscriptionConfig,
        semi_structured_table_text_config: TranscriptionConfig,
        semi_structured_checkbox_config: TranscriptionConfig,
    ) -> dict[str, Any]:
        return {
            cls.TranscriptionModel: transcription_model,
            cls.FieldTranscriptionTargetAccuracies: target_accuracies,
            cls.FinetuningOnlyTrainedLayouts: finetuning_only_trained_layouts,
            cls.ManualTranscriptionEnabled: manual_transcription_enabled,
            cls.ManualTranscriptionAlwaysSuperviseBlankCells: always_supervise_blank_cells,
            **BaseStructuredSettings.create(
                structured_training_enabled,
                structured_training_period,
                structured_improved_threshold_accuracy,
            ),
            **StructuredTextSettings.create(structured_text_config),
            **StructuredCheckboxSettings.create(structured_checkbox_config),
            **StructuredSignatureSettings.create(structured_signature_config),
            **BaseSemiStructuredSettings.create(
                semi_structured_training_enabled,
                semi_structured_training_period,
                semi_structured_improved_threshold_accuracy,
            ),
            **SemiStructuredFieldTextSettings.create(semi_structured_field_text_config),
            **SemiStructuredTableTextSettings.create(semi_structured_table_text_config),
            **SemiStructuredCheckboxSettings.create(semi_structured_checkbox_config),
        }

    @classmethod
    def get_general_settings(cls, exclude: set[str] | None = None) -> list[str]:
        exclude = exclude or set()

        general_settings = [
            cls.LayoutReleaseUuid,
            cls.OrcaOnlyExtraction,
            cls.TranscriptionModel,
            cls.TranscriptionOverrides,
            cls.FieldTranscriptionTargetAccuracies,
            cls.FinetuningOnlyTrainedLayouts,
            cls.ForceNormalizationErrorsToSV,
            cls.ForceRequiredEntriesToSV,
            cls.ManualTranscriptionEnabled,
            cls.ManualTranscriptionAlwaysSuperviseBlankCells,
        ]
        return [setting for setting in general_settings if setting not in exclude]

    @classmethod
    def get_structured_settings(cls) -> list[str]:
        base_settings = BaseStructuredSettings.get_all()
        return [
            *base_settings,
            *StructuredTextSettings.get_all(exclude=set(base_settings)),
            *StructuredCheckboxSettings.get_all(exclude=set(base_settings)),
            *StructuredSignatureSettings.get_all(exclude=set(base_settings)),
        ]

    @classmethod
    def get_semi_structured_settings(cls) -> list[str]:
        base_settings = BaseSemiStructuredSettings.get_all()
        return [
            *base_settings,
            *SemiStructuredFieldTextSettings.get_all(exclude=set(base_settings)),
            *SemiStructuredTableTextSettings.get_all(exclude=set(base_settings)),
            *SemiStructuredCheckboxSettings.get_all(exclude=set(base_settings)),
        ]

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.TranscriptionModel,
                type='string',
                title='Transcription Model',
                description='The transcription model that will be used for this flow',
                ui={'hidden': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.TranscriptionOverrides,
                type='object',
                title='Transcription Overrides',
                optional=True,
                value={},
                ui={'hidden': True},
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.FieldTranscriptionTargetAccuracies,
                type=CustomTypes.FieldTranscriptionTargetAccuracies,
                title='Field Transcription Accuracy Targets',
                description='Field Transcription Accuracy Targets',
                ui={'hidden': False},
                optional=True,
                value=[],
                schema={
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'source_uuid': {'type': 'string'},
                            'target_accuracy': {'type': 'number'},
                        },
                    },
                },
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.FinetuningOnlyTrainedLayouts,
                type='boolean',
                title='Finetuning only for trained layouts',
                description='Run finetuning only for trained layouts.',
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.ForceNormalizationErrorsToSV,
                type='boolean',
                value=False,
                title='Force normalization errors to Supervision',
                description=(
                    'Enable this option to ensure that fields or table cells with normalization '
                    'errors are sent to Supervision for additional human review, preventing '
                    'uncorrected errors from proceeding to downstream processing.'
                ),
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
        ]
