from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v44.additional_blocks.address_parsing.settings import (
    AddressParserSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_transcription.settings import (
    MachineTranscriptionSettings as Settings,
)
from flows_sdk.utils import workflow_input


class MachineTranscriptionBlock(Block):
    """Machine transcription automatically transcribes the content of your submission

    Mandatory parameters:

    :param submission: Submission object
    :param api_params:

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param layout_release_uuid: Layout Release UUID at submission creation time,
        defaults to workflow_input(Settings.LayoutReleaseUuid)
    :param transcription_model: The transcription model that will be used for this flow,
        defaults to workflow_input(Settings.TranscriptionModel)
    :param finetuning_only_trained_layouts:
        defaults to workflow_input(Settings.FinetuningOnlyTrainedLayouts)
    :param force_normalization_errors_to_sv:
        defaults to workflow_input(Settings.ForceNormalizationErrorsToSV)
    :param force_required_blank_entries_to_sv:
        defaults to workflow_input(Settings.ForceRequiredEntriesToSV)
    :param transcription_overrides:
        defaults to workflow_input(Settings.TranscriptionOverrides)
    :param structured_text_target_accuracy:
        defaults to workflow_input(Settings.StructuredTextTargetAccuracy)
    :param structured_text_confidence_threshold:
        defaults to workflow_input(Settings.StructuredTextThreshold)
    :param structured_text_acceptable_confidence:
        defaults to workflow_input(Settings.StructuredTextMinLegThreshold)
    :param semi_structured_text_target_accuracy:
        defaults to workflow_input(Settings.SemiStructuredTextTargetAccuracy)
    :param semi_structured_text_confidence_threshold:
        defaults to workflow_input(Settings.SemiStructuredTextThreshold)
    :param semi_structured_text_acceptable_confidence:
        defaults to workflow_input(Settings.SemiStructuredTextMinLegThreshold)
    :param semi_structured_table_target_accuracy:
        defaults to workflow_input(Settings.SemiStructuredTableTargetAccuracy)
    :param semi_structured_table_confidence_threshold:
        defaults to workflow_input(Settings.SemiStructuredTableThreshold)
    :param semi_structured_table_acceptable_confidence:
        defaults to workflow_input(Settings.SemiStructuredTableMinLegThreshold)
    :param structured_checkbox_target_accuracy:
        defaults to workflow_input(Settings.StructuredCheckboxTargetAccuracy)
    :param structured_checkbox_confidence_threshold:
        defaults to workflow_input(Settings.StructuredCheckboxThreshold)
    :param structured_checkbox_acceptable_confidence:
        defaults to workflow_input(Settings.StructuredCheckboxMinLegThreshold)
    :param structured_signature_target_accuracy:
        defaults to workflow_input(Settings.StructuredSignatureTargetAccuracy)
    :param structured_signature_confidence_threshold:
        defaults to workflow_input(Settings.StructuredSignatureThreshold)
    :param structured_signature_acceptable_confidence:
        defaults to workflow_input(Settings.StructuredSignatureMinLegThreshold)
    :param semi_structured_checkbox_target_accuracy:
        defaults to workflow_input(Settings.SemiStructuredCheckboxTargetAccuracy)
    :param semi_structured_checkbox_confidence_threshold:
        defaults to workflow_input(Settings.SemiStructuredCheckboxThreshold)
    :param semi_structured_checkbox_acceptable_confidence:
        defaults to workflow_input(Settings.SemiStructuredCheckboxMinLegThreshold)
    :param field_target_accuracies:
        defaults to workflow_input(Settings.FieldTranscriptionTargetAccuracies)
    :param always_supervise_blank_cells: Available from V41.2; if enabled, always send blank cells
        in transcribed tables to be supervised manually, regardless of confidence
        defaults to workflow_input(Settings.ManualTranscriptionAlwaysSuperviseBlankCells)
    :param manual_transcription_enabled: Available from V41.2; enables manual transcription when
        applicable, defaults to workflow_input(Settings.ManualTranscriptionEnabled)
    :param address_parsing_enabled: Available from V43.2; toggles AddressParser invocation on
        machine-transcribed address fields,
        defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
    :param address_parser_api_provider: Available from V43.2; selects the address parsing
        provider ('none' / 'google' / 'smarty' / 'geoapify'),
        defaults to workflow_input(AddressParserSettings.ApiProvider)
    :param address_parser_api_key: Available from V43.2; API key for the configured provider,
        defaults to workflow_input(AddressParserSettings.ApiKey)
    :param address_parser_api_options: Available from V43.2; provider-specific JSON options,
        defaults to workflow_input(AddressParserSettings.ApiOptions)

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>` with
      the transcribed field values.
    * `transcription_metadata`: Metadata related to the transcription process.
    * `needs_manual_transcription`: A boolean flag indicating whether the submission needs
      manual transcription.
    * `needs_flexible_extraction`: A boolean flag indicating whether the submission needs
      flexible extraction.

    Example usage::

        machine_transcription = MachineTranscriptionBlock(
            reference_name='machine_transcription',
            submission=manual_identification.output('submission'),
            api_params=submission_bootstrap.output('result.api_params'),
        )
    """

    IDENTIFIER = 'MACHINE_TRANSCRIPTION_10'

    def __init__(
        self,
        submission: Any,
        api_params: Any,
        reference_name: str | None = None,
        layout_release_uuid: str = workflow_input(Settings.LayoutReleaseUuid),
        transcription_model: str = workflow_input(Settings.TranscriptionModel),
        finetuning_only_trained_layouts: str | bool = workflow_input(
            Settings.FinetuningOnlyTrainedLayouts
        ),
        force_normalization_errors_to_sv: str | bool = workflow_input(
            Settings.ForceNormalizationErrorsToSV
        ),
        force_required_blank_entries_to_sv: str | bool = workflow_input(
            Settings.ForceRequiredEntriesToSV
        ),
        transcription_overrides: str = workflow_input(Settings.TranscriptionOverrides),
        structured_text_target_accuracy: str | float = workflow_input(
            Settings.StructuredTextTargetAccuracy
        ),
        structured_text_confidence_threshold: str | float = workflow_input(
            Settings.StructuredTextThreshold
        ),
        structured_text_acceptable_confidence: str | float = workflow_input(
            Settings.StructuredTextMinLegThreshold
        ),
        semi_structured_text_target_accuracy: str | float = workflow_input(
            Settings.SemiStructuredTextTargetAccuracy
        ),
        semi_structured_text_confidence_threshold: str | float = workflow_input(
            Settings.SemiStructuredTextThreshold
        ),
        semi_structured_text_acceptable_confidence: str | float = workflow_input(
            Settings.SemiStructuredTextMinLegThreshold
        ),
        semi_structured_table_target_accuracy: str | float = workflow_input(
            Settings.SemiStructuredTableTargetAccuracy
        ),
        semi_structured_table_confidence_threshold: str | float = workflow_input(
            Settings.SemiStructuredTableThreshold
        ),
        semi_structured_table_acceptable_confidence: str | float = workflow_input(
            Settings.SemiStructuredTableMinLegThreshold
        ),
        structured_checkbox_target_accuracy: str | float = workflow_input(
            Settings.StructuredCheckboxTargetAccuracy
        ),
        structured_checkbox_confidence_threshold: str | float = workflow_input(
            Settings.StructuredCheckboxThreshold
        ),
        structured_checkbox_acceptable_confidence: str | float = workflow_input(
            Settings.StructuredCheckboxMinLegThreshold
        ),
        structured_signature_target_accuracy: str | float = workflow_input(
            Settings.StructuredSignatureTargetAccuracy
        ),
        structured_signature_confidence_threshold: str | float = workflow_input(
            Settings.StructuredSignatureThreshold
        ),
        structured_signature_acceptable_confidence: str | float = workflow_input(
            Settings.StructuredSignatureMinLegThreshold
        ),
        semi_structured_checkbox_target_accuracy: str | float = workflow_input(
            Settings.SemiStructuredCheckboxTargetAccuracy
        ),
        semi_structured_checkbox_confidence_threshold: str | float = workflow_input(
            Settings.SemiStructuredCheckboxThreshold
        ),
        semi_structured_checkbox_acceptable_confidence: str | float = workflow_input(
            Settings.SemiStructuredCheckboxMinLegThreshold
        ),
        field_target_accuracies: str = workflow_input(Settings.FieldTranscriptionTargetAccuracies),
        always_supervise_blank_cells: str | bool | None = workflow_input(
            Settings.ManualTranscriptionAlwaysSuperviseBlankCells
        ),
        manual_transcription_enabled: str | bool | None = workflow_input(
            Settings.ManualTranscriptionEnabled
        ),
        address_parsing_enabled: str | bool = workflow_input(
            AddressParserSettings.AddressParsingEnabled
        ),
        address_parser_api_provider: str = workflow_input(AddressParserSettings.ApiProvider),
        address_parser_api_key: str | None = workflow_input(AddressParserSettings.ApiKey),
        address_parser_api_options: str | dict | None = workflow_input(
            AddressParserSettings.ApiOptions
        ),
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'layout_release_uuid': layout_release_uuid,
                'submission': submission,
                'api_params': api_params,
                'transcription_model': transcription_model,
                'finetuning_only_trained_layouts': finetuning_only_trained_layouts,
                'force_normalization_errors_to_sv': force_normalization_errors_to_sv,
                'force_required_blank_entries_to_sv': force_required_blank_entries_to_sv,
                'transcription_overrides': transcription_overrides,
                'structured_text_target_accuracy': structured_text_target_accuracy,
                'structured_text_confidence_threshold': structured_text_confidence_threshold,
                'structured_text_acceptable_confidence': structured_text_acceptable_confidence,
                'semi_structured_text_target_accuracy': semi_structured_text_target_accuracy,
                'semi_structured_text_confidence_threshold': (
                    semi_structured_text_confidence_threshold
                ),
                'semi_structured_text_acceptable_confidence': (
                    semi_structured_text_acceptable_confidence
                ),
                'semi_structured_table_target_accuracy': semi_structured_table_target_accuracy,
                'semi_structured_table_confidence_threshold': (
                    semi_structured_table_confidence_threshold
                ),
                'semi_structured_table_acceptable_confidence': (
                    semi_structured_table_acceptable_confidence
                ),
                'structured_checkbox_target_accuracy': structured_checkbox_target_accuracy,
                'structured_checkbox_confidence_threshold': (
                    structured_checkbox_confidence_threshold
                ),
                'structured_checkbox_acceptable_confidence': (
                    structured_checkbox_acceptable_confidence
                ),
                'structured_signature_target_accuracy': structured_signature_target_accuracy,
                'structured_signature_confidence_threshold': (
                    structured_signature_confidence_threshold
                ),
                'structured_signature_acceptable_confidence': (
                    structured_signature_acceptable_confidence
                ),
                'semi_structured_checkbox_target_accuracy': (
                    semi_structured_checkbox_target_accuracy
                ),
                'semi_structured_checkbox_confidence_threshold': (
                    semi_structured_checkbox_confidence_threshold
                ),
                'semi_structured_checkbox_acceptable_confidence': (
                    semi_structured_checkbox_acceptable_confidence
                ),
                'field_target_accuracies': field_target_accuracies,
                'always_supervise_blank_cells': (
                    always_supervise_blank_cells
                    if always_supervise_blank_cells is not None
                    else False
                ),
                'manual_transcription_enabled': (
                    manual_transcription_enabled
                    if manual_transcription_enabled is not None
                    else True
                ),
                AddressParserSettings.AddressParsingEnabled: address_parsing_enabled,
                AddressParserSettings.ApiProvider: address_parser_api_provider,
                AddressParserSettings.ApiKey: address_parser_api_key,
                AddressParserSettings.ApiOptions: address_parser_api_options,
            },
            title='Machine Transcription',
            description='Automatically transcribe fields',
        )
