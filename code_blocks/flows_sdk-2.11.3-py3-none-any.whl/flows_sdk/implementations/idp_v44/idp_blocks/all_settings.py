from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v44.additional_blocks.address_parsing import (
    AddressParserSettings,
)
from flows_sdk.implementations.idp_v44.additional_blocks.common_settings import (
    ORCA_ENABLED_DEPENDENCIES,
)
from flows_sdk.implementations.idp_v44.additional_blocks.file_filter import FileFilterSettings
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.idp_blocks.document_renderer import DocumentRendererSettings
from flows_sdk.implementations.idp_v44.idp_blocks.flexible_extraction import (
    FlexibleExtractionSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_classification import (
    MachineClassificationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_collation import (
    MachineCollationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_identification import (
    MachineIdentificationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.machine_transcription import (
    MachineTranscriptionSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.manual_classification import (
    ManualClassificationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.manual_identification import (
    ManualIdentificationSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.manual_transcription import (
    ManualTranscriptionSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.orca_extraction import OrcaExtractionSettings
from flows_sdk.implementations.idp_v44.idp_blocks.reprocessing import ReprocessingSettings
from flows_sdk.implementations.idp_v44.idp_blocks.submission_bootstrap import (
    SubmissionBootstrapSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.submission_complete import (
    SubmissionCompleteSettings,
)
from flows_sdk.implementations.idp_v44.licensing.licensing import FeatureGatingCommonDependencies


class Settings(
    FileFilterSettings,
    SubmissionBootstrapSettings,
    MachineCollationSettings,
    MachineClassificationSettings,
    ManualClassificationSettings,
    MachineIdentificationSettings,
    ManualIdentificationSettings,
    MachineTranscriptionSettings,
    ManualTranscriptionSettings,
    FlexibleExtractionSettings,
    ReprocessingSettings,
    DocumentRendererSettings,
    SubmissionCompleteSettings,
    OrcaExtractionSettings,
    AddressParserSettings,
    BaseInputs,
):
    # ORCA QA Settings
    OrcaQaFlowIdentifier = 'orca_qa_flow_identifier'
    OrcaQaSampleRate = 'orca_qa_sample_rate'
    OrcaQaTaskRestrictions = 'orca_qa_task_restrictions'

    @classmethod
    def create(cls) -> dict[str, Any]:  # type: ignore[override]
        return {}

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.OrcaQaFlowIdentifier,
                type='FlowIdentifier',
                type_spec={'filter_roles': ['quality_assurance']},
                title='Quality Assurance Flow',
                optional=True,
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.OrcaEnabled: {'const': False}}},
                        override={
                            'ui': {'hidden': True},
                        },
                    ),
                    Dependency(
                        condition={'properties': {cls.OrcaQaFlowIdentifier: {'const': None}}},
                        override={
                            'ui': {
                                'warning': 'Select a QA subflow to enable accuracy reporting for '
                                'this model.'
                            }
                        },
                    ),
                    *FeatureGatingCommonDependencies.LargeLanguageModels,
                ],
            ),
            Parameter(
                name=cls.OrcaQaTaskRestrictions,
                type='TaskRestrictions',
                title='Task Restrictions',
                description=(
                    'Defines what users can access Supervision tasks created by this flow.'
                ),
                optional=True,
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.OrcaQaFlowIdentifier: {'const': None}}},
                        override={'ui': {'hide_and_retain': True}},
                    ),
                    *ORCA_ENABLED_DEPENDENCIES,
                ],
            ),
            Parameter(
                name=cls.OrcaQaSampleRate,
                type='Percentage',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='ORCA QA Sample Rate',
                description='Defines the percentage of documents sampled for QA.',
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.OrcaQaFlowIdentifier: {'const': None}}},
                        override={'optional': True, 'ui': {'hide_and_retain': True}},
                    ),
                    *ORCA_ENABLED_DEPENDENCIES,
                ],
            ),
        ]
