from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs


class MachineCollationSettings(BaseInputs):
    CollationDedupeFiles = 'machine_collation_dedupe_files'
    CollationRemoveFromCases = 'machine_collation_remove_from_cases'
    CollationRetentionPeriod = 'machine_collation_retention_period'
    CollationRefreshRetentionPeriod = 'machine_collation_refresh_retention_period'

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.CollationDedupeFiles,
                type='boolean',
                value=False,
                title='Replace case data from duplicate file names',
                description=(
                    'Enabling this setting will replace case data from repeated file names within '
                    'the same case. Cases will retain data from the most recently submitted '
                    'version of a particular file. Note that this setting does not delete the old '
                    'data, it just removes it from the case. Keep in mind this option is only '
                    'relevant when adding to cases'
                ),
            ),
            Parameter(
                name=cls.CollationRemoveFromCases,
                type='array',
                optional=True,
                title='Remove from Cases Information',
                ui={'hidden': True},
                description='This parameter accepts an array of JSON objects that contains '
                'information on how documents or pages should be removed from a pre-existing '
                'case. Currently, the only way to de-collate from a case is by the ids of the '
                'Documents or Pages within a given case',
            ),
            Parameter(
                name=cls.CollationRetentionPeriod,
                type='integer',
                optional=True,
                value=None,
                title='Retention Period',
                description='The number of days to retain cases after they are updated by this '
                'block. If None, no changes to the deletion date will be made.',
            ),
            Parameter(
                name=cls.CollationRefreshRetentionPeriod,
                type='boolean',
                optional=True,
                value=True,
                title='Refresh Retention Period',
                description='If True, applies Retention Period to all cases in the block. '
                'If False, only updates those without a pre-existing deletion date.',
            ),
        ]
