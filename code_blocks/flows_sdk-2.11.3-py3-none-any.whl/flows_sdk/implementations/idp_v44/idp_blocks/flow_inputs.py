from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.flow_inputs import FlowInputs


class IdpFlowInputs(FlowInputs, BaseInputs):
    Submission = 'submission'

    @classmethod
    def create(cls) -> dict[str, Any]:
        return FlowInputs.create()

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.Submission,
                title='Submission',
                type='object',
                optional=True,
                ui={'hidden': True},
            ),
        ]
