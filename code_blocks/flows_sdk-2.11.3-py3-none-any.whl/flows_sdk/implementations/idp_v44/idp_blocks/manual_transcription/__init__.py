from flows_sdk.implementations.idp_v44.idp_blocks.manual_transcription.block import (
    ManualTranscriptionBlock,
)
from flows_sdk.implementations.idp_v44.idp_blocks.manual_transcription.settings import (
    ManualTranscriptionSettings,
)

__all__ = ['ManualTranscriptionBlock', 'ManualTranscriptionSettings']
