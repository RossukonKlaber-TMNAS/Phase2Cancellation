from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v44.idp_blocks.orca_extraction.settings import (
    OrcaExtractionSettings as Settings,
)
from flows_sdk.utils import workflow_input


class OpticalReasoningCognitionAgentBlock(Block):
    """
    Optical Reasoning Cognition Agent block extracts the textual content
    from your submission. It acts like an intelligent agent that uses visual understanding
    and reasoning to process submitted documents and pull out the relevant fields.
    This block requires a GPU to function.

    Mandatory parameters:

    :param submission: Submission object
    :param api_params:

    Parameters with defaults:

    :param model_type: The model you would like to install, which will be used
        to process submissions
    :param use_live_model: Available from V43.2; Whether to use the live ORCA model or a
        specific version of the model. Default value is set to False.
    :param base_model_id: The UUID of the block asset containing ORCA model weights
    :param target_accuracy: The submission-level machine + human transcription
        accuracy targeted by the system (fraction between 0.0 and 1.0, e.g. 0.95 for 95 %).
        Default value is set to 0.95.
    :param sliding_window_size: The number of pages processed by the model at once.
        Larger values improve throughput but raise GPU memory usage.
        Default value is set to 10.
    :param max_image_tokens: The maximum number of tokens allocated per image by the model.
        @deprecated since v44.0; will be removed in v47.0. Use ``max_tokens_per_image``
        instead; this one is applied against the legacy image-token grid rather than the
        selected model's own, so existing flows keep the resolution they ran at.
    :param max_tokens_per_image: Available from V44.0; The maximum number of tokens allocated
        per image by the model. This is conceptually similar to setting image resolution.
        Larger values may increase accuracy on dense / hard to read images but will raise GPU
        memory usage. Defaults to ``None``, letting the selected base model choose a budget
        suited to its own vision grid.
    :param max_new_tokens: The maximum number of tokens the model can extract, which
        should be scaled based on the number and length of field values.
        Default value is set to 1024.
    :param max_num_bboxes: The maximum number of candidate bounding boxes per field occurrence.
        Larger values may improve the likelihood of identifying the correct location
        but may also increase false positives.
        Default value is set to 3.
    :param thresholds_dict: Available from V42.2; Field level thresholds passed as a JSON dict.
        When provided, these will take precedence over any threshold dictionary present in the
        Binary KV. Default value is set to None.
    :param enable_location_hint: Available from V44.0; When set to True, the model computes
        approximate locations (bounding boxes) for the extracted fields. Setting it to False
        lowers GPU memory usage and inference latency, but extracted fields will carry no
        location information. Default value is set to True.
    :param disable_log_redaction: Available from V44.0; Debug only. When set to True, the VLM
        blocks skip the redaction of document content (which may contain PII) in their logs.
        Default value is set to False.
    :param reference_name: unique reference name within a flow, a unique one will be generated
        when not provided

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>` with
      the fields extracted by the model.
    * `needs_flexible_extraction`: A boolean flag indicating whether the submission needs
      flexible extraction.

    Example usage::

        orca_extraction = OpticalReasoningCognitionAgentBlock(
            reference_name='orca_extraction',
            submission=manual_classification.output('submission'),
            api_params=submission_bootstrap.output('api_params'),
        )
    """

    IDENTIFIER = 'OPTICAL_REASONING_COGNITION_AGENT_GPU'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        api_params: str | dict[str, Any],
        model_type: str = workflow_input(Settings.OrcaType),
        use_live_model: bool | str | None = workflow_input(Settings.OrcaUseLiveModel),
        base_model_id: str | None = workflow_input(Settings.OrcaBaseModelUUID),
        target_accuracy: float | str = workflow_input(Settings.OrcaTargetAccuracy),
        sliding_window_size: int | str = workflow_input(Settings.OrcaSlidingWindowSize),
        # @deprecated since v44.0; will be removed in v47.0.
        max_image_tokens: int | str | None = workflow_input(Settings.OrcaMaxImageTokens),
        max_tokens_per_image: int | str | None = workflow_input(Settings.OrcaMaxTokensPerImage),
        max_new_tokens: int | str = workflow_input(Settings.OrcaMaxNewTokens),
        max_num_bboxes: int | str = workflow_input(Settings.OrcaMaxNumBBoxes),
        thresholds_dict: dict[str, Any] | None = None,
        enable_location_hint: bool | str | None = workflow_input(Settings.OrcaEnableLocationHint),
        disable_log_redaction: bool | str | None = False,
        reference_name: str | None = None,
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'submission': submission,
                'api_params': api_params,
                'model_type': model_type,
                'use_live_model': use_live_model,
                'base_model_id': base_model_id,
                'target_accuracy': target_accuracy,
                'max_new_tokens': max_new_tokens,
                'sliding_window_size': sliding_window_size,
                'max_image_tokens': max_image_tokens,
                'max_tokens_per_image': max_tokens_per_image,
                'max_num_bboxes': max_num_bboxes,
                'enable_location_hint': enable_location_hint,
                'thresholds_dict': thresholds_dict,
                'disable_log_redaction': disable_log_redaction,
            },
            title='Optical Reasoning & Cognition Agent',
            description='Extracts the transcriptions of relevant document fields',
        )
