from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.idp_blocks.common_settings import (
    ClassificationSettings,
    IdpSystemSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.defaults import EXACT_PERCENT_SCHEMA
from flows_sdk.implementations.idp_v44.licensing.licensing import FeatureGatingCommonDependencies

CONSECUTIVE_PAGE_BEHAVIOR_GROUP_PAGES = 'group_pages'
CONSECUTIVE_PAGE_BEHAVIOR_SPLIT_PAGES = 'split_pages'
CONSECUTIVE_PAGE_BEHAVIOR_MANUAL = 'manual'
CONSECUTIVE_PAGE_BEHAVIOR_GROUP_FILE = 'group_file'


class MachineClassificationSettings(IdpSystemSettings, ClassificationSettings, BaseInputs):
    LayoutIdDealbreaker = 'layout_id_dealbreaker'
    LayoutIdDealbreakerBypass = 'layout_id_dealbreaker_bypass'
    SemiStructuredClassification = 'semi_structured_classification'
    SemiTargetAccuracy = 'semi_target_accuracy'
    SemiDocGroupingLogic = 'semi_doc_grouping_logic'
    RotationCorrectionEnabled = 'machine_classification_rotation_correction_enabled'
    MobileProcessingEnabled = 'machine_classification_mobile_processing_enabled'
    FileTranscriptionEnabled = 'machine_classification_file_transcription_enabled'

    @classmethod
    def create(  # type: ignore[override]
        cls,
        structured_layout_match_threshold: float,
        layout_id_dealbreaker: bool | None,
        layout_id_dealbreaker_bypass: bool | None,
        semi_structured_classification: bool,
        semi_structured_target_accuracy: float,
        semi_structured_doc_grouping_logic: str,
        rotation_correction_enabled: bool,
        mobile_processing_enabled: bool,
        file_transcription_enabled: bool,
        manual_classification_enabled: bool,
    ) -> dict[str, Any]:
        return {
            cls.StructuredLayoutMatchThreshold: structured_layout_match_threshold,
            cls.LayoutIdDealbreaker: layout_id_dealbreaker,
            cls.LayoutIdDealbreakerBypass: layout_id_dealbreaker_bypass,
            cls.SemiStructuredClassification: semi_structured_classification,
            cls.SemiTargetAccuracy: semi_structured_target_accuracy,
            cls.SemiDocGroupingLogic: semi_structured_doc_grouping_logic,
            cls.RotationCorrectionEnabled: rotation_correction_enabled,
            cls.MobileProcessingEnabled: mobile_processing_enabled,
            cls.FileTranscriptionEnabled: file_transcription_enabled,
            cls.ManualNlcEnabled: manual_classification_enabled,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.LayoutIdDealbreaker,
                type='boolean',
                value=False,
                title='Validate classification using LayoutID',
                description=(
                    'Validates structured document matching by ensuring that the Form ID on the '
                    'document matches the Layout ID on the corresponding layout.'
                ),
            ),
            Parameter(
                name=cls.LayoutIdDealbreakerBypass,
                type='boolean',
                value=False,
                title='Bypass validation if LayoutID missing',
                description=(
                    'Bypasses Form ID and Layout ID validation if there is no Layout ID present '
                    'on the Layout Page.'
                ),
                dependencies=[
                    Dependency(
                        condition={'properties': {cls.LayoutIdDealbreaker: {'const': True}}},
                        override={'ui': {'hidden': False}},
                    )
                ],
                ui={'hidden': True},
            ),
            Parameter(
                name=cls.SemiStructuredClassification,
                type='boolean',
                title='Semi-Structured Classification',
                description=(
                    'Enables workflow to manage a model for automated classification of '
                    'semi-structured and additional layout variations.'
                ),
                dependencies=FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.SemiTargetAccuracy,
                schema=EXACT_PERCENT_SCHEMA,
                type='Percentage',
                title='Semi-Structured Classification Target Accuracy',
                dependencies=FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.SemiDocGroupingLogic,
                type='string',
                schema={
                    'type': 'string',
                    'oneOf': [
                        {
                            'title': 'Consecutive pages as a document',
                            'const': CONSECUTIVE_PAGE_BEHAVIOR_GROUP_PAGES,
                        },
                        {
                            'title': 'Consecutive pages as separate documents',
                            'const': CONSECUTIVE_PAGE_BEHAVIOR_SPLIT_PAGES,
                        },
                        {
                            'title': 'Manual review of consecutive pages',
                            'const': CONSECUTIVE_PAGE_BEHAVIOR_MANUAL,
                        },
                    ],
                },
                title='Semi-Structured Classification Grouping Logic',
                description=(
                    'Flow level grouping logic setting will default to the defined layout level '
                    'grouping logic when configured.'
                ),
                dependencies=FeatureGatingCommonDependencies.SemiStructured,
            ),
            Parameter(
                name=cls.RotationCorrectionEnabled,
                type='boolean',
                value=True,
                title='Image correction',
                description='Identifies and corrects the orientation of semi-structured images.',
            ),
            Parameter(
                name=cls.MobileProcessingEnabled,
                type='boolean',
                value=False,
                title='Mobile processing',
                description='Improves the machine readability of photo captured documents',
            ),
            Parameter(
                name=cls.FileTranscriptionEnabled,
                type='boolean',
                value=False,
                title='Faster PDF transcription',
                description=(
                    'Improves the transcription speed of pdf files. Make sure that '
                    'the pdfs you submit do not contain any rotated images'
                ),
            ),
        ]
