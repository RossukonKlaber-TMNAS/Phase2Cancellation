from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v44.idp_blocks.machine_identification.settings import (
    MachineIdentificationSettings as Settings,
)
from flows_sdk.utils import workflow_input


class MachineIdentificationBlock(Block):
    """Machine identification automatically identifies fields and tables in the submission

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>`
        object
    :param api_params:

    Parameters with defaults:

    :param layout_release_uuid: Layout Release UUID at submission creation time,
        defaults to workflow_input(Settings.LayoutReleaseUuid)
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param manual_field_id_enabled: Enables manual identification when applicable,
        defaults to workflow_input(Settings.ManualFieldIdEnabled)
    :param force_required_missing_entries_to_sv:
        defaults to workflow_input(Settings.ForceRequiredEntriesToSV)
    :param field_id_target_accuracy: Field ID Target Accuracy,
        defaults to workflow_input(Settings.FieldIdTargetAccuracy)
    :param table_id_target_accuracy: Table ID Target Accuracy,
        defaults to workflow_input(Settings.TableIdTargetAccuracy)
    :param id_target_accuracies:
        defaults to workflow_input(Settings.IdentificationTargetAccuracies)

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>` with
      its `documents` updated with the identified fields and tables.
    * `needs_manual_identification`: A boolean flag indicating whether the submission needs
      Identification Supervision.
    * `fl_metadata`: Metadata related to the Field Identification process.
    * `tl_metadata`: Metadata related to the Table Identification process.

    Example usage::

        machine_identification = MachineIdentificationBlock(
            reference_name='machine_identification',
            submission=manual_classification.output('submission'),
            api_params=submission_bootstrap.output('result.api_params'),
        )
    """

    IDENTIFIER = 'MACHINE_IDENTIFICATION_9'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        api_params: dict[str, Any] | str,
        layout_release_uuid: str = workflow_input(Settings.LayoutReleaseUuid),
        reference_name: str | None = None,
        manual_field_id_enabled: bool | str = workflow_input(Settings.ManualFieldIdEnabled),
        force_required_missing_entries_to_sv: bool | str = workflow_input(
            Settings.ForceRequiredEntriesToSV
        ),
        field_id_target_accuracy: float | str = workflow_input(Settings.FieldIdTargetAccuracy),
        table_id_target_accuracy: float | str = workflow_input(Settings.TableIdTargetAccuracy),
        id_target_accuracies: list[dict[str, Any]] | str = workflow_input(
            Settings.IdentificationTargetAccuracies
        ),
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'submission': submission,
                'layout_release_uuid': layout_release_uuid,
                'api_params': api_params,
                'manual_field_id_enabled': manual_field_id_enabled,
                'force_required_missing_entries_to_sv': force_required_missing_entries_to_sv,
                'field_id_target_accuracy': field_id_target_accuracy,
                'table_id_target_accuracy': table_id_target_accuracy,
                'id_target_accuracies': id_target_accuracies,
            },
            title='Machine Identification',
            description='Automatically locate fields on semi-structured documents',
        )
