from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.idp_blocks.common_settings import (
    ORCA_ONLY_EXTRACTION_DEPENDENCY,
    ExtractionSettings,
    IdentificationSettings,
    IdpSystemSettings,
)
from flows_sdk.implementations.idp_v44.idp_blocks.custom_types import (
    CustomTypes,
    SingleEntityTargetAccuracy,
)
from flows_sdk.implementations.idp_v44.idp_blocks.defaults import EXACT_PERCENT_SCHEMA
from flows_sdk.implementations.idp_v44.licensing.licensing import FeatureGatingCommonDependencies


class MachineIdentificationSettings(
    IdpSystemSettings, ExtractionSettings, IdentificationSettings, BaseInputs
):
    IdentificationTargetAccuracies = 'identification_target_accuracies'
    FieldIdTargetAccuracy = 'field_id_target_accuracy'
    TableIdTargetAccuracy = 'table_id_target_accuracy'

    @classmethod
    def create(  # type: ignore[override]
        cls,
        field_id_target_accuracy: float,
        table_id_target_accuracy: float,
        id_target_accuracies: list[SingleEntityTargetAccuracy] | None,
        manual_id_enabled: bool,
    ) -> dict[str, Any]:
        return {
            cls.FieldIdTargetAccuracy: field_id_target_accuracy,
            cls.TableIdTargetAccuracy: table_id_target_accuracy,
            cls.IdentificationTargetAccuracies: id_target_accuracies or [],
            cls.ManualFieldIdEnabled: manual_id_enabled,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.IdentificationTargetAccuracies,
                type=CustomTypes.IdentificationTargetAccuracies,
                title='Identification Target Accuracies',
                description='Identification Target Accuracies',
                ui={'hidden': False},
                optional=True,
                value=[],
                schema={
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'source_uuid': {'type': 'string'},
                            'target_accuracy': {'type': 'number'},
                        },
                    },
                },
                dependencies=[
                    *FeatureGatingCommonDependencies.IdentificationTargetAccuraciesEnabled,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.FieldIdTargetAccuracy,
                type='Percentage',
                schema=EXACT_PERCENT_SCHEMA,
                title='Field Identification Target Accuracy',
                dependencies=[
                    *FeatureGatingCommonDependencies.FieldId,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.TableIdTargetAccuracy,
                type='Percentage',
                schema=EXACT_PERCENT_SCHEMA,
                title='Table Identification Target Accuracy',
                value=0.96,
                dependencies=[
                    *FeatureGatingCommonDependencies.TableId,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
        ]
