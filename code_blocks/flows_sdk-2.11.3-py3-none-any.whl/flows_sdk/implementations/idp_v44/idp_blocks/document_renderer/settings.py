from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v44.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v44.licensing.gated_features import LicenseGatedFeature
from flows_sdk.implementations.idp_v44.licensing.licensing import (
    FeatureGatingCommonDependencies,
    field_validation_context_not_contains_all_features,
)

PDF_MIME_TYPE = 'application/pdf'

DEFAULT_QUALITY = 50

MODE_BW = '1'
MODE_RGB = 'RGB'
MODE_GRAYSCALE = 'L'

INCHES = 'in'
LETTER_WIDTH_IN_INCHES = 8.5
LETTER_HEIGHT_IN_INCHES = 11

MILLIMETERS = 'mm'
LETTER_WIDTH_IN_MM = 215.9
LETTER_HEIGHT_IN_MM = 279.4


class DocumentRendererSettings(BaseInputs):
    DocumentRenderingEnabled = 'document_rendering_enabled'
    DocumentRenderingMimeType = 'document_rendering_mime_type'
    DocumentRenderingUnit = 'document_rendering_unit'
    DocumentRenderingWidth = 'document_rendering_width'
    DocumentRenderingHeight = 'document_rendering_height'
    DocumentRenderingQuality = 'document_rendering_quality'
    DocumentRenderingMode = 'document_rendering_mode'
    DocumentRenderingSearchablePdfEnabled = 'document_rendering_searchable_pdf_enabled'

    @classmethod
    def create(
        cls,
        enabled: bool,
        mime_type: str,
        unit: str,
        width: float | None,
        height: float | None,
        quality: int,
        mode: str | None,
        searchable_pdf_enabled: bool = False,
    ) -> dict[str, Any]:
        return {
            cls.DocumentRenderingEnabled: enabled,
            cls.DocumentRenderingMimeType: mime_type,
            cls.DocumentRenderingUnit: unit,
            cls.DocumentRenderingWidth: width,
            cls.DocumentRenderingHeight: height,
            cls.DocumentRenderingQuality: quality,
            cls.DocumentRenderingMode: mode,
            cls.DocumentRenderingSearchablePdfEnabled: searchable_pdf_enabled,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        common_dependencies = [
            Dependency(
                condition={'properties': {cls.DocumentRenderingEnabled: {'const': False}}},
                override={'ui': {'hidden': True}},
            ),
            Dependency(
                condition={
                    'properties': {
                        **field_validation_context_not_contains_all_features(
                            [LicenseGatedFeature.DOCUMENT_RENDERER]
                        )
                    }
                },
                override={'ui': {'hide_and_retain': True}},
            ),
        ]

        return [
            Parameter(
                name=cls.DocumentRenderingEnabled,
                type='boolean',
                title='Document Rendering Enabled',
                description=(
                    'When enabled, documents are rendered as downloadable PDFs after '
                    'Classification. The generated PDF is stored in Blob storage, and a '
                    "download URL is included in the submission's JSON output upon completion."
                ),
                value=False,
                ui={
                    'warning': (
                        'Enabling document rendering will result in a higher compute utilization '
                        'and require more storage for storing all documents.'
                    )
                },
                dependencies=[FeatureGatingCommonDependencies.DocumentRendererEnabled],
            ),
            Parameter(
                name=cls.DocumentRenderingMimeType,
                type='string',
                value=PDF_MIME_TYPE,
                title='Rendered Document Format',
                schema={
                    'type': 'string',
                    'oneOf': [
                        {
                            'title': 'PDF',
                            'const': 'application/pdf',
                        }
                    ],
                },
                description=(
                    'Format in which the document will be rendered. Currently only PDF is '
                    'supported.'
                ),
                ui={'hidden': True},
                dependencies=common_dependencies,
            ),
            Parameter(
                name=cls.DocumentRenderingUnit,
                type='string',
                title='Document Measurement Unit',
                description='Unit of measurement for the document rendering.',
                schema={
                    'type': 'string',
                    'oneOf': [
                        {
                            'title': 'Inches',
                            'const': INCHES,
                        },
                        {
                            'title': 'Millimeters',
                            'const': MILLIMETERS,
                        },
                    ],
                },
                value=INCHES,
                dependencies=common_dependencies,
            ),
            Parameter(
                name=cls.DocumentRenderingWidth,
                type='number',
                title='Document Width',
                description='Width of the rendered document.',
                schema={'type': 'number', 'minimum': 0, 'maximum': 600},
                dependencies=common_dependencies
                + [
                    Dependency(
                        condition={'properties': {cls.DocumentRenderingUnit: {'const': INCHES}}},
                        override={'value': LETTER_WIDTH_IN_INCHES},
                    ),
                    Dependency(
                        condition={
                            'properties': {cls.DocumentRenderingUnit: {'const': MILLIMETERS}}
                        },
                        override={'value': LETTER_WIDTH_IN_MM},
                    ),
                ],
                optional=True,
                value=LETTER_WIDTH_IN_INCHES,
            ),
            Parameter(
                name=cls.DocumentRenderingHeight,
                type='number',
                title='Document Height',
                description='Height of the rendered document.',
                schema={'type': 'number', 'minimum': 0, 'maximum': 600},
                dependencies=common_dependencies
                + [
                    Dependency(
                        condition={'properties': {cls.DocumentRenderingUnit: {'const': INCHES}}},
                        override={'value': LETTER_HEIGHT_IN_INCHES},
                    ),
                    Dependency(
                        condition={
                            'properties': {cls.DocumentRenderingUnit: {'const': MILLIMETERS}}
                        },
                        override={'value': LETTER_HEIGHT_IN_MM},
                    ),
                ],
                optional=True,
                value=LETTER_HEIGHT_IN_INCHES,
            ),
            Parameter(
                name=cls.DocumentRenderingQuality,
                type='integer',
                title='Quality',
                description='Controls the quality of page images in the final PDF'
                ' (recommended: 50%). Higher values produce better visual quality,'
                ' but they also increase file size. This setting only applies when'
                ' the Output Image Mode is set to Original or Grayscale.',
                schema={'type': 'integer', 'minimum': 5, 'maximum': 100},
                value=DEFAULT_QUALITY,
                optional=True,
                dependencies=common_dependencies
                + [
                    Dependency(
                        condition={'properties': {cls.DocumentRenderingMode: {'const': MODE_BW}}},
                        override={
                            'ui': {
                                'na_reason': 'Not applied when Output image mode is set'
                                ' to Black & White.'
                            }
                        },
                    )
                ],
            ),
            Parameter(
                name=cls.DocumentRenderingMode,
                type='string',
                schema={
                    'type': 'string',
                    'oneOf': [
                        {'title': 'Keep original colors', 'const': MODE_RGB},
                        {'title': 'Convert to grayscale', 'const': MODE_GRAYSCALE},
                        {'title': 'Convert to black & white', 'const': MODE_BW},
                    ],
                },
                dependencies=common_dependencies,
                description='Select how the images in the document should be processed'
                ' during document rendering. Converting images to grayscale'
                ' or black and white can significantly reduce the file size of the output.',
                title='Output image mode',
                value=MODE_RGB,
            ),
            Parameter(
                name=cls.DocumentRenderingSearchablePdfEnabled,
                type='boolean',
                title='Searchable PDF Output',
                description=(
                    'Add a hidden searchable text layer to rendered PDFs. If page segment '
                    'geometry is not already available, it will be generated automatically, '
                    'which adds processing time for each affected page.'
                ),
                value=False,
                dependencies=common_dependencies,
            ),
        ]
