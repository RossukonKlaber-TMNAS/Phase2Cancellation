from flows_sdk.implementations.idp_v44.idp_blocks.document_renderer.block import (
    DocumentRendererBlock,
)
from flows_sdk.implementations.idp_v44.idp_blocks.document_renderer.settings import (
    DocumentRendererSettings,
)

__all__ = ['DocumentRendererBlock', 'DocumentRendererSettings']
