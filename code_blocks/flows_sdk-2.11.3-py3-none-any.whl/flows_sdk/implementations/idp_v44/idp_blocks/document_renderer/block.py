from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v44.idp_blocks.document_renderer.settings import (
    DocumentRendererSettings as Settings,
)
from flows_sdk.utils import workflow_input


class DocumentRendererBlock(Block):
    """
    Document File Generator Block renders a document into a PDF and stores it in the Blob storage.

    This block should be placed ALWAYS after a Reprocessing block (if there is any) so that it
    is not possible to have more changes in the documents' organisation.

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>`
        object that includes the documents that need to be rendered.

    Optional parameters:

    :param is_reprocessing: boolean to handle execution when reprocessing.
        Defaults to False.
    :param title: overrides the block's default title shown in Flow Studio,
        defaults to 'Document Renderer'
    :param description: overrides the block's default description shown in Flow Studio,
        defaults to 'Renders a document into a PDF'
    :param document_rendering_enabled: a boolean that enables or disables the document rendering.
      Default is False.
    :param document_rendering_mime_type: the mime type of the document to be generated. Default is
        'application/pdf'
    :param document_rendering_unit: the unit of the document to be generated. Default is 'in'
    :param document_rendering_height: the height of the document to be generated. Default is 11
    :param document_rendering_width: the width of the document to be generated. Default is 8.5
    :param document_rendering_quality: Quality of pages (images) appended to the resulting document
      as a percentage (recommended 50%). Higher quality results in a larger file size for the
      generated PDF.
    :param document_rendering_mode: Available from V42.0;
      Mode of the images appended to the resulting document.
      Supported modes are RGB (default), L (grayscale) and 1 (black-and-white)
    :param document_rendering_searchable_pdf_enabled: Available from V43.2; add a hidden
      searchable text layer to rendered PDFs using existing page segment geometry where
      available. Default is False.

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v44.contracts.Submission>` with
      the `document_file` field populated on its documents with the rendered document file
      information.


    Example usage::

        # Use the output of the reprocessing block.
        reprocessing = ReprocessingBlock(reference_name='reprocessing')

        document_renderer_block = DocumentRendererBlock(
            reference_name='document_renderer',
            submission=reprocessing.output('submission'),
            document_rendering_enabled=True,
            document_rendering_unit='in',
            document_rendering_width=8.5,
            document_rendering_height=11,
            document_rendering_quality=50,
            is_reprocessing=reprocessing.output('is_reprocessing'),
            document_rendering_mode='L'
        )

        output_ref = document_renderer_block.output()
    """

    IDENTIFIER = 'DOCUMENT_RENDERER_2'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        is_reprocessing: str | bool = False,
        title: str = 'Document Renderer',
        description: str = 'Renders a document into a PDF',
        reference_name: str | None = None,
        document_rendering_enabled: bool | str = workflow_input(Settings.DocumentRenderingEnabled),
        document_rendering_mime_type: str = workflow_input(Settings.DocumentRenderingMimeType),
        document_rendering_unit: str = workflow_input(Settings.DocumentRenderingUnit),
        document_rendering_height: str | float = workflow_input(Settings.DocumentRenderingHeight),
        document_rendering_width: str | float = workflow_input(Settings.DocumentRenderingWidth),
        document_rendering_quality: str | int = workflow_input(Settings.DocumentRenderingQuality),
        document_rendering_mode: str = workflow_input(Settings.DocumentRenderingMode),
        document_rendering_searchable_pdf_enabled: bool | str = workflow_input(
            Settings.DocumentRenderingSearchablePdfEnabled
        ),
    ) -> None:
        inputs = {
            'submission': submission,
            'is_reprocessing': is_reprocessing,
            'document_rendering_enabled': document_rendering_enabled,
            'document_rendering_mime_type': document_rendering_mime_type,
            'document_rendering_unit': document_rendering_unit,
            'document_rendering_height': document_rendering_height,
            'document_rendering_width': document_rendering_width,
            'document_rendering_quality': document_rendering_quality,
            'document_rendering_mode': document_rendering_mode,
            'document_rendering_searchable_pdf_enabled': (
                document_rendering_searchable_pdf_enabled
            ),
        }
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )
