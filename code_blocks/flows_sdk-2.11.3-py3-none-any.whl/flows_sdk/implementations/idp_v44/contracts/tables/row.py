from dataclasses import dataclass


@dataclass(kw_only=True)
class Row:
    """
    Represents a row of cells in a table that has been defined for extraction as part of a layout.
    """

    row_number: int
    '''
    Indicates the order in which this Row appears in the Table.
    '''

    parent_row_number: int | None = None
    '''
    Indicates the ``row_number`` of the parent Row, if part of a child Table.
    '''

    missing_row_iteration: int | None = None
    '''
    Indicates which iteration of the missing-row-detection algorithm identified this Row.
    '''
