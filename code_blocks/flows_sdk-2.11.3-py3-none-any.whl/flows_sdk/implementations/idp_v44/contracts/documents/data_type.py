from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v44.contracts.documents.constants import EntryTypeLiteral, MlModelLiteral


@dataclass(kw_only=True)
class DataType:
    """
    Provides means for configuring the data-extraction and normalization processes.
    """

    uuid: UUID
    '''
    Unique system-generated identifier.
    '''

    name: str
    '''
    Human-readable name of the DataType.
    '''

    entry_type: EntryTypeLiteral
    '''
    Represents the method by which the data is extracted. Possible values are:

        * ``1`` (builtin) - extraction using a built-in model.
        * ``2`` (pattern) - extraction using a regex pattern.
        * ``3`` (list) - extraction by matching against a list of accepted values.
    '''

    ml_model: MlModelLiteral
    '''
    Top-level category of the DataType.
    '''

    meta_type: str | None
    '''
    Sub-category of the DataType. For example, for an ``entry`` DataType, the ``meta_type`` could be
    ``date``, ``address``, etc.
    '''
