from dataclasses import dataclass
from datetime import datetime
from uuid import UUID


@dataclass(kw_only=True)
class PageSegments:
    """
    Represents the segmentation details of a page, including the number of text, checkbox, and
    signature segments.
    """

    uuid: UUID
    '''
    Unique identifier used to link the Page to its corresponding segments in the file store.
    '''

    model_version: str
    '''
    The version of the segmentation model used to extract the segments.
    '''

    segmentation_date: datetime
    '''
    The date and time when the segmentation was performed.
    '''

    n_text_segments: int
    '''
    The number of text segments identified on the Page.
    '''

    n_checkbox_segments: int
    '''
    The number of checkbox segments identified on the Page.
    '''

    n_signature_segments: int
    '''
    The number of signature segments identified on the Page.
    '''
