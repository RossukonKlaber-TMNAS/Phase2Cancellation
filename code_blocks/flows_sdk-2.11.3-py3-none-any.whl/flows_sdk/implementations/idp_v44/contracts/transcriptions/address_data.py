from dataclasses import dataclass
from typing import Any, Literal
from uuid import UUID


@dataclass(kw_only=True)
class ParsedAddress:
    """
    Represents the parsed address data extracted by the specified parser.
    """

    parser: Literal['geoapify', 'google', 'smarty', 'usaddress', 'deepparse']
    '''
    The parser used to extract the address data.
    '''

    recipient: str | None = None
    '''
    The recipient name, if available.
    '''

    street_number: str | None = None
    '''
    The street number, if available.
    '''

    street_name: str | None = None
    '''
    The street name, if available.
    '''

    unit: str | None = None
    '''
    The unit or apartment number, if available.
    '''

    po_box: str | None = None
    '''
    The PO box number, if available.
    '''

    city: str | None = None
    '''
    The city name, if available.
    '''

    state: str | None = None
    '''
    The state or province name, if available.
    '''

    postal_code: str | None = None
    '''
    The postal code, if available.
    '''

    country: str | None = None
    '''
    The country name, if available.
    '''

    country_code: str | None = None
    '''
    The country code, if available.
    '''

    raw: dict[str, Any] | None = None
    '''
    The raw address data as a dictionary, if available.
    '''


@dataclass(kw_only=True)
class AddressData:
    """
    Represents the address data structure, including parsed, normalized, and verification details.
    """

    uuid: UUID
    '''
    The unique identifier for the address data.
    '''

    parse_error: str | None = None
    '''
    The error encountered during the parsing of the address, if any.
    '''

    normalized_address: str | None = None
    '''
    The normalized address as a string.
    '''

    parsed_address_json: ParsedAddress | None = None
    '''
    The parsed address data, if available.
    '''

    verification_json: dict[str, Any] | None = None
    '''
    The verification details of the parsed address, if available.
    '''
