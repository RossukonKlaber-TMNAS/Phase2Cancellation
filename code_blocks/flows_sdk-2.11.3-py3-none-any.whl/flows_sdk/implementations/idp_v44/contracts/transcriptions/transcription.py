from dataclasses import dataclass
from uuid import UUID


@dataclass(kw_only=True)
class Transcription:
    """
    Represents a transcription of text with a unique identifier.
    """

    uuid: UUID
    '''
    Unique system-generated identifier.
    '''

    value: str
    '''
    The transcribed text value.
    '''
