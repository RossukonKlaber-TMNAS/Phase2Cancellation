from dataclasses import dataclass

from flows_sdk.implementations.idp_v44.contracts.pages.page import InternalPage
from flows_sdk.implementations.idp_v44.contracts.redaction.redaction import Redaction


@dataclass(kw_only=True)
class PageRedactionData:
    """
    Contains the redaction data for a Page.
    """

    image_uuid: str
    '''
    Unique identifier of the primary redacted image for the Page.
    '''

    debug_image_uuid: str
    '''
    Unique identifier of a separate debug rendering of the same redacted Page. Contains visual
    indicators of where redactions were applied.
    '''

    redactions: list[Redaction]
    '''
    Array of Redaction objects associated with the Page.
    '''


@dataclass(kw_only=True)
class InternalRedactedPage(InternalPage):
    redaction_data: PageRedactionData
    '''
    A PageRedactionData object containing the redaction data for the Page.
    '''


@dataclass(kw_only=True)
class RedactedPage(InternalRedactedPage):
    """
    Represents a page with redaction data.
    """

    id: int
    '''
    Unique system-generated identifier.
    '''
