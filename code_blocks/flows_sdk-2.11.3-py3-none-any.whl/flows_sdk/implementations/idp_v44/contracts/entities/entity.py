from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v44.contracts.entities.constants import EntityOriginLiteral
from flows_sdk.implementations.idp_v44.contracts.entities.location import EntityLocation


@dataclass(kw_only=True)
class Entity:
    """
    The Entity object presents a single extracted occurrence of a given type.
    """

    uuid: UUID
    '''
    Unique system-generated identifier.
    '''

    origin: EntityOriginLiteral
    '''
    The origin of the Entity, indicating which method was used for extracting it.
    '''

    type: str
    '''
    The type of the Entity (e.g., ``Person Name``, ``Location``, etc.).
    '''

    text: str
    '''
    The text extracted from the Entity.
    '''

    locations: list[EntityLocation]
    '''
    Array of locations where the Entity appears.
    '''

    confidence: float
    '''
    A number between 0 and 1 indicating the confidence the machine has in the accuracy of the
    Entity's extraction.
    '''
