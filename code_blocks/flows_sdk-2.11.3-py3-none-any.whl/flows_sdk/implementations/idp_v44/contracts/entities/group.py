from dataclasses import dataclass

from flows_sdk.implementations.idp_v44.contracts.entities.entity import Entity
from flows_sdk.implementations.idp_v44.contracts.pages.page import InternalPage, Page


@dataclass(kw_only=True)
class InternalEntityGroup:
    identifier: str
    '''
    Unique system-generated identifier.
    '''

    pages: list[InternalPage]
    '''
    Array of Page objects included in this EntityGroup.
    '''

    entities: list[Entity]
    '''
    Array of Entity objects included in this EntityGroup.
    '''


@dataclass(kw_only=True)
class EntityGroup(InternalEntityGroup):
    """
    The EntityGroup object represents a group of pages and entities extracted from those pages.
    """

    pages: list[Page]  # type: ignore[assignment]
