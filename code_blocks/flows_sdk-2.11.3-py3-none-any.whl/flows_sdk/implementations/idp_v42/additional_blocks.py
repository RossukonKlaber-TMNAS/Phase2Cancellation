from collections.abc import Sequence
from typing import Any
from uuid import UUID

from flows_sdk.blocks import Block, IOBlock, Outputs
from flows_sdk.implementations.idp_v42.additional_values import (
    DEFAULT_ENTITY_RECOGNITION_PAGE_OVERLAP,
    JSON_OUTPUT_ROLE,
)
from flows_sdk.implementations.idp_v42.idp_values import (
    DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER,
    HttpHeaderAuthorizationParams,
    Inputs,
    OAuth2AuthorizationParams,
    Settings,
)
from flows_sdk.utils import workflow_input


class JSONOutputsBlock(Outputs):
    """Output block allows users to send JSON data extracted by an IDP flow to other systems
    for downstream processing
    Mandatory parameters:

    :param inputs: Used by the UI to automatically pre-populate the input of
        newly added blocks. Extended in this class to include ``'enabled': True``
        to visualize an enabled/disabled trigger that is controllable via Flow Studio.

    Usage when parameters are to be defined in Flow Studio::

        outputs = JSONOutputBlock(
            inputs={'result': }
        )
    """

    def __init__(self, inputs: dict[str, Any], blocks: Sequence[IOBlock] | None = None) -> None:
        if not blocks:
            blocks = []

        super().__init__(
            reference_name='json_outputs',
            title='JSON Outputs',
            description='Send JSON submission data to external systems',
            role_filter=[JSON_OUTPUT_ROLE],
            input_template=inputs,
            blocks=blocks,
        )


class ImageCorrectionBlock(Block):
    """
    Image Correction Block rotates and de-skews tilted/skewed images so that they are more
    transcription-friendly
    Mandatory parameters:

    :param pages: list of page object that includes the raw documents that need to be
        image-corrected

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param rotation_correction_enabled: Identifies and corrects the orientation of images.
        Enabled by default.
    :param mobile_processing_enabled: Improves the machine readability of photo captured documents.
        Disabled by default.
    :param language_family: language family to use when performing image correction.
        If not provided, the system will default to `latin`. Language families are single
        word lowercase strings, e.g., `latin`, `arabic`, `korean`, `chinese`.
        You can read more about language families in the
        "Supported Languages" article in the application documentation:
        https://help.hyperscience.ai/v42/docs/supported-languages.
    :param app_metadata: used for capturing information about the flow

    Example usage::

        # This is one way to obtain the submission object (using SubmissionBootstrapBlock)
        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
        # ImageCorrectionBlock takes in the submission object and outputs in the same format with
        # its images
        image_correct_block = ImageCorrectionBlock(
            reference_name='image_correct',
            pages=submission_bootstrap.output(submission.unassigned_pages),
        )
        # reference to the output of IDPImageCorrectionBlock which can be passed as input to the
        # next block. For more information on output() and output references, please take a look
        # at class Block and its output() method
        output_ref = image_correct_block.output()
    """

    IDENTIFIER = 'IMAGE_CORRECTION_PAGES'

    def __init__(
        self,
        pages: str,
        reference_name: str | None = None,
        rotation_correction_enabled: bool = True,
        mobile_processing_enabled: bool = False,
        language_family: str | None = None,
        title: str = 'Image Correction (Pages)',
        description: str = 'Rotate and de-skew documents',
        app_metadata: list[str] | None = None,
    ) -> None:
        inputs: dict[Any, Any] = {
            'pages': pages,
            'rotation_correction_enabled': rotation_correction_enabled,
            'mobile_processing_enabled': mobile_processing_enabled,
            'language_family': language_family,
        }
        if app_metadata is not None:
            inputs['app_metadata'] = app_metadata

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class FullPageTranscriptionBlock(Block):
    """
    Full Page Transcription Block machine-transcribes the documents contained in a submission

    Mandatory parameters:

    :param pages: list of pages that includes the raw documents that need to be transcribed

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param language_family: language family to use when instantiating the underlying transcription
        model. If not provided, the system will default to `latin`. Language families are single
        word lowercase strings, e.g., `latin`, `arabic`, `korean`, `chinese`.
        You can read more about language families in the
        "Supported Languages" article in the application documentation:
        https://help.hyperscience.ai/v42/docs/supported-languages.
    :param include_raw_segments: Available from V42.2; controls whether the extracted segments
        should be included directly in the output.
    :param rerun_segmentation: Available from V42.3; controls whether segmentation should be
        rerun for already segmented pages.
    :param app_metadata: used for capturing information about the flow

    Example usage::

        # This is one way to obtain the submission object (using SubmissionBootstrapBlock)
        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
        # FullPageTranscriptionBlock transcribes the documents contained in the submission object
        fpt_block = FullPageTranscriptionBlock(
            reference_name='fpt',
            pages=submission_bootstrap.output(submission.unassigned_pages),
        )
        # reference to the output of FullPageTranscriptionBlock which can be passed as input to the
        # next block. For more information on output() and output references, please take a look at
        # class Block and its output() method
        output_ref = fpt_block.output()
    """

    IDENTIFIER = 'FULL_PAGE_TRANSCRIPTION_PAGES_2'

    def __init__(
        self,
        pages: str,
        reference_name: str | None = None,
        title: str = 'Full Page Transcription (Pages)',
        description: str = 'Transcribes documents',
        language_family: str | None = None,
        app_metadata: list[str] | None = None,
        include_raw_segments: bool = True,
        rerun_segmentation: bool = True,
    ) -> None:
        inputs: dict[Any, Any] = {
            'pages': pages,
            'language_family': language_family,
            'include_raw_segments': include_raw_segments,
            'rerun_segmentation': rerun_segmentation,
        }
        if app_metadata is not None:
            inputs['app_metadata'] = app_metadata

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class QASchedulerBlock(Block):
    """
    Available from V41.2

    Schedules Quality Assurance (QA) tasks for a specific workflow.

    This class serves as a specialized block within a flow for scheduling Quality
    Assurance tasks. It ensures the proper configuration and scheduling processes
    for a given workflow instance. It leverages provided data and parameters such
    as identification of the workflow, submission details, QA configuration, and
    optional reprocessing cases.

    Mandatory parameters:

    :param flow_identifier: A unique string identifying the flow to associate this QA
        scheduler with.
    :param submission: A dictionary containing submission details.
        Will be used as payload to trigger
        the target flow to be QA'd.
    :param qa_config: A dictionary containing QA configuration. Will be used as payload to trigger
        the target flow to be QA'd.

    Optional parameters:

    :param is_reprocessing: An optional value indicating whether this block is part of
        a reprocessing workflow. Defaults to False.
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided

    Example usage::

        qa_scheduler = QASchedulerBlock(
            flow_identifier='my_qa_flow',
            submission={'submission_id': 12345, 'data': 'example_data'},
            qa_config={'sample_rate': 0.1, 'language_family': 'latin'},
            is_reprocessing=False,
        )

        # reference to the output of QASchedulerBlock which can be passed
         as input to the next block.
        # For more information on output() and output references, please take a look at class Block
        # and its output() method
        output_ref = qa_scheduler.output()
    """

    IDENTIFIER = 'QA_SCHEDULER'

    def __init__(
        self,
        flow_identifier: str,
        submission: dict[str, Any] | str,
        qa_config: dict[str, Any] | str,
        is_reprocessing: bool | str | None = False,
        reference_name: str | None = None,
    ) -> None:
        inputs: dict[str, Any] = {
            'flow_identifier': flow_identifier,
            'submission': submission,
            'qa_config': qa_config,
            'is_reprocessing': is_reprocessing,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title='QA Scheduler',
            description='Schedules Quality Assurance tasks for a given flow',
        )


class FullPageTranscriptionQABlock(Block):
    """
    Available from V41.2

    Full Page Transcription QA Block performs Quality Assurance on the output of
    Full Page Transcription Block. It samples a percentage of segments for QA
    and allows users to split segments into smaller tokens for easier QA.

    Mandatory parameters:

    :param submission: Submission object
    :param sample_rate: Defines the percentage of segments the system samples
        for Quality Assurance
    :param language_family: Specifies the language family for the class
    :param split_text_segments: Enabling this option splits segments into smaller, more
        manageable tokens for easier QA

    Parameters with defaults:

    :param min_characters_in_segment: Minimum number of characters in a token.
        Defaults to 4. Minimum value is 1, maximum is 100.
    :type min_characters_in_segment: integer
    :param task_restrictions: Defines what users can access tasks created
        by this block. Defaults to None, which is treated as an empty list.
    :type task_restrictions: Optional[TaskRestrictions]
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided

    Example usage::

        full_page_transcription_qa = FullPageTranscriptionQABlock(
            reference_name='full_page_transcription_qa',
            submission=manual_transcription.output('submission'),
            sample_rate=10,
            language_family='latin',
            split_text_segments=True,
            min_characters_in_segment=4,
            task_restrictions=[],
        )

        # reference to the output of FullPageTranscriptionQABlock which can be passed
        as input to the
        # next block. For more information on output() and output references, please take a look
        # at class Block and its output() method
        output_ref = full_page_transcription_qa.output()
    """

    IDENTIFIER = 'FULL_PAGE_TRANSCRIPTION_QA'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        sample_rate: int | str,
        language_family: str,
        split_text_segments: bool | str,
        min_characters_in_segment: int | str = 4,
        task_restrictions: list[Any] | str | None = None,
        reference_name: str | None = None,
    ) -> None:
        if task_restrictions is None:
            task_restrictions = []

        inputs: dict[str, Any] = {
            'submission': submission,
            'sample_rate': sample_rate,
            'language_family': language_family,
            'split_text_segments': split_text_segments,
            'min_characters_in_segment': min_characters_in_segment,
            'task_restrictions': task_restrictions,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title='Full Page Transcription QA',
            description='Quality Assurance for Full Page Transcription',
        )


class CustomSupervisionBlock(Block):
    """The CustomSupervisionBlock uses a JSON schema as a form builder to create customer-driven
    UIs for Supervision tasks.

    Mandatory parameters:

    :param submission: Submission object
    :param task_purpose: the custom task name that's given to all supervision tasks that run
        through a particular instance of a custom supervision block. This can be used to filter
        tasks in the task queue.
    :param data: JSON structure that supplies the data used to populate the supervision_template
    :param supervision_template: JSON used for configuration of the Custom Supervision Task.

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param supervision_transcription_masking: Prevents users from inputting invalid
        characters during the Custom Supervision task,
        defaults to True
    :param task_restrictions: Defines what users can access Supervision tasks created
        by this block,
        defaults to []
    :param notification_workflow: Notification flow name to run when the submission
        enters Custom Supervision,
        defaults to IDP_SUBMISSION_NOTIFY_NAME
    :param chat_flow_identifier: Available from V41.2; optional chat flow identifier to be populated
        to enable Document Chat in Custom Supervision
    :param title: UI-visible title of the block. Defaults to 'IDP Custom Supervision'
    :type title: Optional[str]
    :param description: Description of the block. Both useful for documentation purpose and visible
            to users in the Flow studio. Defaults to 'IDP Custom Supervision'
    :type description: Optional[str]

    Example usage::

        custom_supervision = CustomSupervisionBlock(
            reference_name='custom_supervision',
            submission=manual_transcription.output('submission'),
            task_purpose='make_custom_decision',
            supervision_template=[
                {
                    'name': 'three_column_template',
                    'version': '1.0',
                    'thumbnail': {
                        'group_by_document': True,
                        'group_by_case': True,
                    },
                    'action': [
                        {
                            'name': 'my_tab',
                            'display': 'SSN Info',
                            'input': [
                                {
                                    'name': 'ssn_field',
                                    'type': 'transcription',
                                    'data_identifier': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                                    'title': 'SSN',
                                },
                            ],
                            'ui': {
                                'groups': [
                                    {
                                        'title': 'My Group',
                                        'fields': ['ssn_field'],
                                    },
                                ],
                            },
                        },
                    ],
                },
            ],
            data={
                'fields': [
                    {
                        'id': 967,
                        'uuid': 'fe8d4e7a-a82c-448c-85a1-0a3cbbe53b61',
                        'value': '111-22-3333',
                        'page_id': 15,
                        'layout_field_id': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                        'validation_overridden': False,
                        'bounding_box': [
                            0.09360783305186686,
                            0.25792617589433436,
                            0.6358913805295097,
                            0.28862414740388187,
                        ],
                        'occurrence_index': 1,
                    },
                ],
                'template_fields': [
                    {
                        'uuid': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                        'notes': '',
                        'type': 'entry',
                        'data_type_uuid': 'b600a4e4-758f-4c4b-a2f4-cbb5dd870a0c',
                        'name': 'SSN',
                    },
                ],
                'pages': [
                    {
                        'id': 15,
                        'file_page_number': 1,
                        'document_page_number': 1,
                        'image_url': '/image/2ed3d989-b64a-44bd-a9fb-6e0dcc5ccdb8',
                        'form_id': 2,
                        'submission_id': 1,
                        'external_case_ids': [],
                        'read_only': False,
                        'filename': '1 page.pdf',
                        'form_page_id': 1
                    },
                ],
                'documents': [
                    {
                        'id': 2,
                        'layout_uuid': 'e31c3cbf-dcea-44fd-a052-902463c6040f',
                        'layout_name': 'layout_name',
                        'page_count': 2,
                        'read_only': False,
                    },
                ],
                'cases': [],
                'selected_choices': [],
            },
            supervision_transcription_masking=False,
        )
    """

    IDENTIFIER = 'CUSTOM_SUPERVISION_3'

    def __init__(
        self,
        submission: Any,
        task_purpose: str,
        data: Any,
        supervision_template: Any,
        reference_name: str | None = None,
        supervision_transcription_masking: bool = True,
        task_restrictions: list[Any] | None = None,
        notification_workflow: str = DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER,
        chat_flow_identifier: str | None = None,
        title: str | None = 'Custom Supervision',
        description: str | None = 'Custom Supervision',
    ) -> None:
        if not task_restrictions:
            task_restrictions = []

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'supervision_template': supervision_template,
                'submission': submission,
                'task_purpose': task_purpose,
                'data': data,
                'task_restrictions': task_restrictions,
                'supervision_transcription_masking': supervision_transcription_masking,
                'notification_workflow': notification_workflow,
                'chat_flow_identifier': chat_flow_identifier,
            },
            title=title,
            description=description,
        )


class SoapRequestBlock(Block):
    """Soap Block allows user to perform SOAP requests
    Mandatory parameters:

    :param method: SOAP method to invoke
    :param endpoint: absolute url including schema to HTTP endpoint for this request

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param body_namespace: SOAP request body namespace url
    :param headers_namespace: SOAP request headers namespace url
    :param headers: SOAP headers to use
    :param http_headers: Available from V42.1; HTTP headers to be sent on all requests
    :param params: key-value pair used as query parameters in the request to be
        inserted as SOAP body

    Example usage::

        # minimum viable instantiation, the rest of the fields can later be added in the UI
        soap_block = SoapRequestBlock(
            reference_name='soap_request',
            title='Soap Request',
            description='Perform soap request',
            method='ExampleMethod',
        )
        soap_block = SoapRequestBlock(
            reference_name='soap_request',
            title='Soap Request',
            description='Perform soap request',
            method='ExampleMethod',
            endpoint='http://example.org/abc.wso',
            body_namespace='http://www.example.org/abc.countryinfo',
            params={'example': 'stuff'},
            headers={},
            http_headers={}
        )
        # reference to the output of SoapRequestBlock which can be passed as input to the next block
        # for more information on output() and output references, please take a look at class Block
        # and its output() method
        output_ref = soap_block.output()
    """

    IDENTIFIER = 'SOAP_REQ'

    def __init__(
        self,
        method: str,
        reference_name: str | None = None,
        endpoint: str = '',
        body_namespace: str | None = None,
        headers_namespace: str | None = None,
        headers: dict[Any, Any] | None = None,
        http_headers: dict[str, Any] | None = None,
        params: dict[Any, Any] | None = None,
        use_wsdl: bool = False,
        wsdl_uri: str | None = '',
        wsdl_service_name: str | None = '',
        wsdl_port_name: str | None = '',
        title: str = 'HTTP REST Block',
        description: str = 'HTTP REST block',
    ) -> None:
        inputs: dict[Any, Any] = {
            'method': method,
            'endpoint': endpoint,
            'use_wsdl': use_wsdl,
            'wsdl_uri': wsdl_uri,
            'wsdl_service_name': wsdl_service_name,
            'wsdl_port_name': wsdl_port_name,
        }
        if body_namespace is not None:
            inputs['body_namespace'] = body_namespace
        if headers_namespace is not None:
            inputs['headers_namespace'] = headers_namespace
        if headers is not None:
            inputs['headers'] = headers
        if params is not None:
            inputs['params'] = params
        if http_headers is not None:
            inputs['http_headers'] = http_headers

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class BaseHttpRestBlock(Block):
    """
    :meta private:
    Base HttpRest block to be reused by internal and external divergent interface implementations
    """

    IDENTIFIER = 'HTTP_REST'

    def __init__(
        self,
        method: str,
        reference_name: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        payload: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
        endpoint: str | None = None,
        sdm_app_endpoint: str | None = None,
        timeout: int | None = 600,
        authorization_type: str | None = None,
        handled_error_codes: list[int | str] | None = None,
        auth_params: None | (HttpHeaderAuthorizationParams | OAuth2AuthorizationParams) = None,
        endpoint_secrets: str | None = None,
        response_encoding: str | None = None,
        title: str = 'HTTP REST Block',
        description: str = 'HTTP REST block',
    ) -> None:
        assert endpoint or sdm_app_endpoint, 'An endpoint or an sdm_app_endpoint must be specified'

        inputs: dict[Any, Any] = {'method': method}
        if endpoint is not None:
            inputs['endpoint'] = endpoint
        if sdm_app_endpoint is not None:
            inputs['sdm_app_endpoint'] = sdm_app_endpoint
        if headers is not None:
            inputs['headers'] = headers
        if params is not None:
            inputs['params'] = params
        if payload is not None:
            inputs['payload'] = payload
        if json is not None:
            inputs['json'] = json
        if timeout is not None:
            inputs['timeout'] = timeout
        if authorization_type is not None:
            inputs['authorization_type'] = authorization_type
        if handled_error_codes is not None:
            inputs['handled_error_codes'] = handled_error_codes
        if endpoint_secrets is not None:
            inputs['endpoint_secrets'] = endpoint_secrets
        if response_encoding is not None:
            inputs['response_encoding'] = response_encoding
        if auth_params is not None:
            if isinstance(auth_params, HttpHeaderAuthorizationParams):
                inputs['authorization_header'] = auth_params.authorization_header
                inputs['authorization_header_name'] = auth_params.authorization_header_name
            elif isinstance(auth_params, OAuth2AuthorizationParams):
                inputs['auth_url'] = auth_params.auth_url
                inputs['client_id'] = auth_params.client_id
                inputs['client_secret'] = auth_params.client_secret
                inputs['audience'] = auth_params.audience
                inputs['scope'] = auth_params.scope
            else:
                raise ValueError(
                    'auth_params must be of type HttpHeaderAuthorizationParams '
                    'or OAuth2AuthorizationParams'
                )

        super().__init__(
            identifier=self.IDENTIFIER,
            title=title,
            description=description,
            reference_name=reference_name,
            input=inputs,
        )


class HttpRestBlock(BaseHttpRestBlock):
    """Http Rest Block allows user to perform HTTP requests
    Mandatory parameters:

    :param method: HTTP method to use
    :param endpoint: absolute url including schema to HTTP endpoint for this request

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param headers: HTTP headers to use
    :param params: key-value pair used as query parameters in the request
    :param payload: key-value pair to be used as x-www-form-urlencoded data.
        Mutually exclusive with json
    :param json: key-value pair to be used as json data. Mutually exclusive
        with payload
    :param timeout: How long (in seconds) to keep the connection open if no bytes are received
        from the endpoint. Set to 0 to wait indefinitely (not recommended).
    :param authorization_type: authorization type (none, http_header,
        oauth_2_client_credentials)
    :param handled_error_codes: specify HTTP error codes that will not fail
        the task, allowing for wildcards with the 'x' char. Example: [400, \"5xx\"]
    :param auth_params: authorization parameters to be passed when the authorization_type
        is set to "http_header" or "oauth_2_client_credentials"
    :param response_encoding: Available from V42.3; Character encoding to use when decoding
        the response. If not provided, the encoding from the Content-Type header or the
        requests library's default detection will be used. Specify a standard encoding name
        (e.g., 'utf-8', 'ISO-8859-1', 'windows-1252') to override.

    Example usage::

        # minimum viable instantiation, the rest of the fields can later be added in the UI
        http_rest_block = HttpRestBlock(
            reference_name='http_request',
            title='Http Request',
            description='Perform http request',
            method='GET',
        )
        http_rest_block = HttpRestBlock(
            reference_name='http_request',
            title='Http Request',
            description='Perform http request',
            method='GET',
            endpoint='https://sheets.googleapis.com/v4/spreadsheets/example',
        )
        # reference to the output of HttpRestBlock which can be passed as input to the next block
        # for more information on output() and output references, please take a look at class Block
        # and its output() method
        output_ref = http_rest_block.output()
    """

    def __init__(
        self,
        method: str,
        endpoint: str,
        reference_name: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        payload: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
        timeout: int | None = 600,
        authorization_type: str | None = None,
        handled_error_codes: list[int | str] | None = None,
        auth_params: None | (HttpHeaderAuthorizationParams | OAuth2AuthorizationParams) = None,
        response_encoding: str | None = None,
        title: str = 'HTTP REST Block',
        description: str = 'HTTP REST block',
    ) -> None:
        super().__init__(
            method=method,
            reference_name=reference_name,
            headers=headers,
            params=params,
            payload=payload,
            json=json,
            endpoint=endpoint,
            timeout=timeout,
            authorization_type=authorization_type,
            handled_error_codes=handled_error_codes,
            auth_params=auth_params,
            response_encoding=response_encoding,
            title=title,
            description=description,
        )


class HyperscienceRestApiBlock(BaseHttpRestBlock):
    """Make Http requests to the Hyperscience platform APIs.
    This block will automatically take care of prepending the base url and will include
    the appropriate authentication headers with the request.
    Mandatory parameters:

    :param method: HTTP method to use
    :param app_endpoint: relative url, beginning with a forward slash, to an HTTP endpoint served
        by the Hypersciecne platform. For reference on the available endpoints, check out
        https://docs.hyperscience.ai/

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param headers: HTTP headers to use
    :param params: key-value pair used as query parameters in the request
    :param payload: key-value pair to be used as x-www-form-urlencoded data.
        Mutually exclusive with json
    :param json: key-value pair to be used as json data. Mutually exclusive
        with payload
    :param handled_error_codes: specify HTTP error codes that will not fail
        the task, allowing for wildcards with the 'x' char. Example: [400, \"5xx\"]
    :param timeout: How long (in seconds) to keep the connection open if no bytes are received
        from the endpoint. Set to 0 to wait indefinitely (not recommended).
    :param response_encoding: Available from V42.3; Character encoding to use when decoding
        the response. If not provided, the encoding from the Content-Type header or the
        requests library's default detection will be used. Specify a standard encoding name
        (e.g., 'utf-8', 'ISO-8859-1', 'windows-1252') to override.

    Example usage::

        hs_rest_block = HyperscienceRestApiBlock(
            reference_name='http_request',
            app_endpoint='/api/healthcheck',
            method='GET',
        )
    """

    def __init__(
        self,
        method: str,
        app_endpoint: str,
        reference_name: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        payload: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
        handled_error_codes: list[int | str] | None = None,
        timeout: int | None = 600,
        response_encoding: str | None = None,
        title: str = 'Hyperscience HTTP REST Block',
        description: str = 'Hyperscience HTTP REST block',
    ) -> None:
        super().__init__(
            method=method,
            reference_name=reference_name,
            headers=headers,
            params=params,
            payload=payload,
            json=json,
            sdm_app_endpoint=app_endpoint,
            timeout=timeout,
            authorization_type=None,
            handled_error_codes=handled_error_codes,
            response_encoding=response_encoding,
            title=title,
            description=description,
        )


class DatabaseAccessBlock(Block):
    """Database Block allows user to access and perform queries on the specified database
    Mandatory parameters:

    :param db_type: database type (mssql, oracle, postgres)
    :param host: URL/IP address of the server database is hosted on
    :param database: database name
    :param username: database username
    :param password: database password
    :param query: parameterized query

    Optional parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param port: database port number
    :param options: dictionary of additional connection string options
    :param query_params: dictionary of values for query placeholders
    :param timeout: timeout in seconds (mssql and postgres only)

    Example usage::

        # minimum viable instantiation, the rest of the fields can later be added in the UI
        db_lookup = DatabaseAccessBlock(
            reference_name='db_lookup',
            title='Database Lookup',
            description='Perform database lookup',
        )
        # note that storing password in plain text form is not recommended
        # password can later be entered in the UI or defined as a flow secret.
        db_lookup = DatabaseAccessBlock(
            reference_name='db_lookup',
            title='Database Lookup',
            description='Perform database lookup',
            db_type='mssql',
            database='cars',
            host='example.com',
            username='user',
            # we recommend skipping the password field or defining it as a system secret
            # e.g. system_secret('{your_secret_identifier}') (both allow for secret input via. UI)
            password='pw'
            port=1433,
            timeout=200,
            query='SELECT * from CAR',
        )
        # reference to the output of DBAccessBlock which can be passed as input to the next block
        # for more information on output() and output references, please take a look at class Block
        # and its output() method
        output_ref = db_lookup.output()
        # content of output_ref:
        {
            "result": [
                {
                    "id": 1,
                    "brand": "Aston Martin",
                    "model": "Vanquish"
                },
                {
                    "id": 2,
                    "brand": "Jaguar",
                    "model": "XE 2018"
                }
            ]
        }

    Database output for the same query (SELECT * FROM CAR)

    .. image:: ../media/images/db_access_query_example.png
    """

    IDENTIFIER = 'DB_ACCESS_2'

    def __init__(
        self,
        reference_name: str | None = None,
        db_type: str = '',
        database: str = '',
        host: str = '',
        username: str = '',
        password: str = '',
        query: str = '',
        port: int | None = None,
        options: dict[Any, Any] | None = None,
        timeout: int | None = None,
        query_params: dict[Any, Any] | None = None,
        title: str = 'DB Block',
        description: str = 'DB access block',
    ) -> None:
        inputs: dict[Any, Any] = {
            'db_type': db_type,
            'database': database,
            'host': host,
            'username': username,
            'password': password,
            'query': query,
        }
        if port is not None:
            inputs['port'] = port
        if options is not None:
            inputs['options'] = options
        if timeout is not None:
            inputs['timeout'] = timeout
        if query_params is not None:
            inputs['query_params'] = query_params

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            title=title,
            description=description,
            input=inputs,
        )


class LLMInstallBlock(Block):
    """
    The LLM Install Block sets up the necessary LLM or VLM in the HS instance. It begins by
    verifying whether the model is already present and, if not, retrieves it from S3 for SaaS
    instances or Cloudsmith for on-premises instances.

    Mandatory parameters:

    :param model_name: Name of the LLM model to install (Choose from the available models)
    :param from_cloudsmith: Available from V42.2; Download from Cloudsmith flag
    :param cloudsmith_key: Cloudsmith API key (Only when running on on-premise instance)
    :param user_consent: User consent (The block will fail if set to False)

    The block outputs the detailed model name and model UUID of the chosen LLM.

    Example usage::

        llm_install = LLMInstallBlock(
            model_name='ORCA',
            from_cloudsmith=True,
            cloudsmith_key='cloudsmith_key',
            user_consent=True
        )

    Example output::

        {
            "model": "orca",
            "model_uuid": "14554188-cf8e-4f10-9057-d1df2f710072"
        }
    """

    IDENTIFIER = 'LLM_INSTALL'

    def __init__(
        self,
        model_name: str = 'ORCA',
        cloudsmith_key: str = '',
        user_consent: bool | str = False,
        reference_name: str | None = None,
        title: str = 'Install LLM/VLM',
        description: str = 'Sets up the necessary LLM or VLM in the HS instance.',
        from_cloudsmith: bool | str = False,
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'model_name': model_name,
                'from_cloudsmith': from_cloudsmith,
                'cloudsmith_key': cloudsmith_key,
                'user_consent': user_consent,
            },
            title=title,
            description=description,
        )


class LlamaBlock(Block):
    """Text generation using the Llama 2 model by Meta.

    **Deprecated** from version 41.1

    This block utilizes Llama 2 by Meta. Llama 2 is licensed under the LLAMA 2 Community License
    (https://ai.meta.com/llama/license/). By using the Llama Block, you acknowledge that you have
    received a copy of the LLAMA 2 Community License.

    Note: This block is still experimental and not ready for production use.

    Mandatory parameters:

    :param model_id: UUID, identifier of the asset with the ML model.
        Model assets are not part of the Hyperscience bundle and must first be downloaded and
        imported into the system before they can be used. Please contact your Hyperscience
        representative to discuss the usecase and the appropriate model and to get instructions on
        downloading the models.
        Once downloaded, here are the available model asset UUIDs:
        b3da05c7-061c-4a58-af6d-4c905d2e618f - Llama 2, 13B, 8-bit quantized
    :param prompt: The prompt to generate text from. Use a CodeBlock ahead of the LlamaBlock in
        order to build the prompt. The context window of the model is limited to 4096 tokens.
        If the prompt has more tokens, the block would return an error. The total input and output
        length also cannot exceed 4096 tokens, which means that if the input is too long, the output
        may be truncated. Also see tokenize_only for a more detailed explanation of how to handle
        longer texts.

    Optional parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param consent: Has the business user read and acknowledged the Llama 2 legal notice.
        Unless the flow would be used in CI automation, this should be set to False so that a
        business user can read and acknowledge the notice in the Hyperscience UI. Setting this
        to True in the Python definition of the flow is also treated as acknowledgement of the
        notice on behalf of the entity that will be using the flow.
    :param tokenize_only: In the context of LLMs, tokens correspond roughly to words, partial words
        and punctuation. A rough way to compute the number of tokens in a text is
        number_of_tokens = 1.25 * number_of_words. The Llama block works with a context window
        of 4096 tokens. If a longer prompt is passed in, it would return an error. Also, if the
        prompt is shorter, but still close to 4096, the output may be truncated.
        Since the length of the prompt in tokens cannot be known ahead of time, sometimes the flow
        may need to make dynamic decisions whether to pass the text to the Llama block, or to
        split it into multiple chunks, or to use some alternative method for processing it (e.g. a
        custom supervision manual task).
        The tokenize_only option enables flows to take such dynamic decisions based on the length
        of the prompt in tokens.
        The default is false - it instructs the block to run the ML model inference over the
        prompt, i.e. to generate a text response.
        When true is passed, the model will simply tokenize the prompt without running inference
        and return the list of tokens - this will work regardless of the length of the prompt.
        A subsequent Decision task can then route longer prompts to an alternative path in the
        flow, while routing shorter prompts to the LlamaBlock for actual text generation.
    :param predict_extra_kwargs: Extra keyword arguments used for model inference.
        (Used to fine-tune the model prediction. Not recommended to change this unless you know
        what you are doing)

    Example usage::

        llama = LlamaBlock(
            reference_name='llama',
            model_id='b3da05c7-061c-4a58-af6d-4c905d2e618f',
            prompt='${previous_block.output.llama_prompt}',
        )
    """

    IDENTIFIER = 'LLAMA'

    def __init__(
        self,
        model_id: str,
        prompt: str,
        reference_name: str | None = None,
        consent: bool | None = False,
        tokenize_only: bool | None = False,
        predict_extra_kwargs: dict[Any, Any] | None = None,
        title: str = 'Llama Text Generation',
        description: str = 'Text generation using the Llama 2 model',
    ) -> None:
        if predict_extra_kwargs is None:
            predict_extra_kwargs = {}

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'model_id': model_id,
                'prompt': prompt,
                'consent': consent,
                'tokenize_only': tokenize_only,
                'predict_extra_kwargs': predict_extra_kwargs,
            },
            title=title,
            description=description,
        )


class EntityRecognitionBlock(Block):
    """
    Entity Recognition Block detects entities of different types within the documents contained
    in a submission

    This block requires the output of the Full Page Transcription Block as input data.

    Mandatory parameters:

    :param pages: list of pages that includes the raw documents with the transcribed information
        from the FPT block
    :param regex_map: a map that specifies different regex patterns that the block should look for,
        a default one is present
    :param keyword_map: a map that specifies different keyword patterns that the block should look
        for, a default one is present

    Optional Parameters:

    :param enhanced_output: a boolean flag that enables toggling between simple and enhanced
        output formats. Default value is False.
    :param ner_enabled: a boolean flag that enables or disables Named Entity Recognition.
        Default value is True.
    :param ced_enabled: a boolean flag that enables or disables Custom Entity Detection.
        Default value is True.
    :param signature_enabled: a boolean flag that enables or disables Signature Detection.
        Default value is True.
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param page_batch_size: Available from V42.3; an integer that specifies the number of pages to
        be processed in a batch. If not provided, the block will process all pages in a single
        batch.
    :param page_overlap: Available from V42.3; an integer that specifies the number of overlapping
        pages between batches. Default value is 1, which means that the last page of a batch will
        be repeated as the first page of the next batch. This is to ensure that entities that are
        located at the border of two batches are not missed.
    :param language_family: Available from V42.3; language family to use when performing
        segmentation. If not provided, the system will default to `latin`. Language families are
        single word lowercase strings, e.g., `latin`, `arabic`, `korean`, `chinese`.
        You can read more about language families in the "Supported Languages" article in the
        application documentation: https://help.hyperscience.ai/v42/docs/supported-languages.

    Example usage::

        # This is one way to obtain the submission object (using SubmissionBootstrapBlock)
        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

        # EntityRecognitionBlock detects entities within the documents contained in the submission
        entity_recognition_block = EntityRecognitionBlock(
            reference_name='entity_recognition',
            pages=submission_bootstrap.output(submission.unassigned_pages),
            regex_map=DEFAULT_PII_REGEX_MAP,
            keyword_map=DEFAULT_PII_KEYWORD_MAP,
            enhanced_output=False,
        )

        # reference to the output of EntityRecognitionBlock which can be passed as input to the
        # next block. For more information on output() and output references, please take a look at
        # class Block and its output() method
        output_ref = entity_recognition_block.output()

    Example content of output_ref::

        {
            "documents": [
                {
                    "file_uuid": "da2c6117-43c4-4b30-84c4-cdc59cc3fa4f",
                    "entities": [
                        {
                            "text": "John Smith",
                            "type": "Person Name",
                            "positions": [
                                [0.5, 0.1, 0.55, 0.13],
                                [0.6, 0.2, 0.65, 0.23],
                                [0.7, 0.3, 0.75, 0.33],
                            ],
                            "page_ids": [0, 0, 1],
                            "origin": "NER",
                        },
                        {
                            "text": "<SIGNED>",
                            "type": "signature",
                            "positions": [[0.701171875, 0.732421875, 0.92578125, 0.8681640625]],
                            "page_ids": [0],
                            "origin": "Signature",
                        },
                    ]
                },
                {
                    "file_uuid": "4aa38f84-e5af-4cdc-ba5c-edd60f0a6b89",
                    "entities": [
                        ...
                    ]
                }
            ],
            "redaction_annotations": {
                "ner": [ ... ],
                "ced": [ ... ],
            }
        }
    """

    IDENTIFIER = 'ENTITY_RECOGNITION'

    def __init__(
        self,
        pages: str,
        regex_map: dict[str, str] | None = None,
        keyword_map: dict[str, list[str]] | None = None,
        enhanced_output: bool = False,
        ner_enabled: bool = True,
        ced_enabled: bool = True,
        signature_enabled: bool = True,
        page_batch_size: int | None = None,
        page_overlap: int = DEFAULT_ENTITY_RECOGNITION_PAGE_OVERLAP,
        language_family: str | None = None,
        reference_name: str | None = None,
        title: str = 'Entity Recognition',
        description: str = 'Recognizes entities of different types in documents',
    ) -> None:
        inputs: dict[Any, Any] = {
            'pages': pages,
            'regex_map': regex_map,
            'keyword_map': keyword_map,
            'enhanced_output': enhanced_output,
            'ner_enabled': ner_enabled,
            'ced_enabled': ced_enabled,
            'signature_enabled': signature_enabled,
            'page_batch_size': page_batch_size,
            'page_overlap': page_overlap,
            'language_family': language_family,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class FileFilterBlock(Block):
    """
    Available from V40.2

    File Filter Block filters out unwanted files from the input of a flow

    This block is meant to be placed at the start of the flow/subflow -
    BEFORE the SubmissionBootstrapBlock, not after it.
    It requires the output of a connector (e.g. Email Listener) or an API submission
    as input data, and its output is meant to be consumed by a SubmissionBootstrapBlock.

    Mandatory parameters:

        This block has no strictly required parameters - all of its filters are optional.

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param trigger: the trigger input from a connector - if not set explicitly,
        it will default to the workflow input trigger (which is where this value is normally found)
    :param filter_type: a discrete value, either "ALL_FILES" or "IMAGES_ONLY". Determines
        what kind of files the filters will be applied to. Default value is "ALL_FILES".
        If set to "IMAGES_ONLY", all filtering options will be applied only to images, other files
        will pass through.
    :param minimum_image_width: image width in pixels - half of the image dimension filter.
        Any image with less width than configured here will be filtered out.
        Defaults to None (will do nothing).
    :param minimum_image_height: image height in pixels - second half of the image dimension filter.
        Any image with less height than configured here will be filtered out.
        Defaults to None (will do nothing).
    :param minimum_file_size_kb: represents the file size filter. Any file whose disk size is less
        than this number (in KB) will be filtered out. May be fractional.
        Defaults to None (will do nothing).
    :param file_extensions_action: a discrete value, either "ALLOW", "DENY" or "NONE".
        Represents the function of the file extension filter.
        "ALLOW" means we only allow the configured file extensions.
        "DENY" means we only deny the configured file extensions.
        "NONE" means no file extension filtering takes place.
        Defaults to "NONE"
    :param file_extensions: a list of strings, representing the file extensions
        used for file extension filtering.
        Expected if file_extensions_action is not "NONE".
        Otherwise, defaults to None (will do nothing).
    :param file_extensions_other: a comma separated list of file extensions
        used for file extension filtering.
        Meant for adding extra extensions that are not available in the pre-defined list.
        Optional, defaults to None (will do nothing). However, it is expected
        in case the `file_extensions` parameter contains "other".

    Example usage::

        # File Filter Block filters out unwanted files from the input of a flow
        file_filter_block = FileFilterBlock(
            # trigger: str = workflow_input(Inputs.Trigger),  # usually not necessary to set this
            reference_name='file_filter',
            filter_type='ALL_FILES',
            minimum_image_width=500,
            minimum_image_height=500,
            minimum_file_size_kb=2.5,
            file_extensions_action='ALLOW',
            file_extensions=['pdf', 'png'],
            file_extensions_other='jpg,svg,txt',
        )

        # reference to the output of FileFilterBlock which can be passed as input to the
        # next block (a SubmissionBootstrapBlock)
        output_ref = file_filter_block.output('result.filtered_trigger')
        submission_bootstrap = SubmissionBootstrapBlock(trigger=output_ref)

    Example content of output_ref::

        {
            "payload": {
                "blob_storage_files": [
                    {
                        "uuid": "db58606e-32f9-42c9-a0bc-ed9848ff247a",
                    }
                ],
                "filtered_files": [
                    {
                        "uuid": "db58606e-32f9-42c9-a0bc-ed9848ff246e",
                        "filtered_by": [
                            "file_size_filter"
                        ]
                    },
                ]
            }
        }
    """

    IDENTIFIER = 'FILE_FILTER'

    def __init__(
        self,
        trigger: str = workflow_input(Inputs.Trigger),
        filter_type: str = workflow_input(Settings.FileFilterType),
        minimum_image_width: str | None = workflow_input(Settings.FileFilterMinimumImageWidth),
        minimum_image_height: str | None = workflow_input(Settings.FileFilterMinimumImageHeight),
        minimum_file_size_kb: str | None = workflow_input(Settings.FileFilterMinimumFileSizeKB),
        file_extensions_action: str = workflow_input(Settings.FileFilterFileExtensionsAction),
        file_extensions: str | None = workflow_input(Settings.FileFilterFileExtensions),
        file_extensions_other: str | None = workflow_input(Settings.FileFilterFileExtensionsOther),
        reference_name: str | None = None,
        title: str = 'File Filter',
        description: str = 'Filters out unwanted files from the input of a flow',
    ) -> None:
        inputs: dict[Any, Any] = {
            '$trigger': trigger,
            'filter_type': filter_type,
            'minimum_image_width': minimum_image_width,
            'minimum_image_height': minimum_image_height,
            'minimum_file_size_kb': minimum_file_size_kb,
            'file_extensions_action': file_extensions_action,
            'file_extensions': file_extensions,
            'file_extensions_other': file_extensions_other,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class GeneralPromptingORCABlock(Block):
    """
    General Prompting ORCA Block

    This block requires a GPU to function.

    Mandatory parameters:

    :param model_type: Base model to be used for general prompting.
        This is usually the output of the LLMInstallBlock.
    :param base_model_id: The UUID of the block asset containing ORCA model weights.
        This is usually the output of the LLMInstallBlock.

    Parameters with defaults:

    :param messages: A list of prompt message threads sent to the model.
        Each message thread is a list of messages.
        Each message is a dictionary containing the keys "role" and "content".
        - Role is a string, with one of "system", "user", "assistant", depending on what the
        related content represents.
        "system" - there is usually a single system prompt in any list of messages, which
        outlines rules and recommendations for the generative model to follow.
        "user" - User messages should be messages sent by a person to the model.
        "assistant" - Assistant messages should be model responses.
        - Content is a mixed list that can contain text and images. Each content entry is
        formatted either as {'type': 'image', 'image': image_uuid} or
        {'type': 'text', 'text': 'content of the message'}
    :param adapter_id: UUID of a previously imported adapter to use.
        The base model will be used when not provided.
        Default value is None.
    :param max_new_tokens: The maximum number of tokens the model can extract, which
        should be scaled based on the number and length of field values.
        Default value is set to 1024.
    :param max_image_tokens: The maximum number of tokens allocated per image by the model.
        This is conceptually similar to setting image resolution. Larger values may
        increase accuracy on dense / hard to read images but will raise GPU memory usage.
        Default value is set to 1280.
    :param enable_location_hint: Available from V42.3; When set to True, the ORCA general
        prompting block will generate location hint related outputs. This can be useful for
        downstream tasks that require bounding boxes within the image. However, enable it will
        raise GPU memory usage and inference latency.
    :param reference_name: unique reference name within a flow, a unique one will be generated
        when not provided.


    Example usage::

        # This is one way to obtain the model_type and base_model_id
        llm_install_block = LLMInstallBlock(user_consent=True)

        # Here we construct a simple static set of messages. But these can also be dynamic
        # and the output of a PythonCode block or other processing blocks.
        system_message = {'role': 'system', 'content': [
                {'type': 'text', 'text': 'You are a helpful assistant'}
        ]}
        prompt = {'role': 'user', 'content': [
            {'type': 'image', 'image': workflow_input('some_image_uuid')},
            {'type': 'text', 'text': 'Make a short summary of everything in the image'}
        ]}
        message_thread = [system_message, prompt]

        gp_block = GeneralPromptingORCABlock(
            model_type=llm_install.output('model'),
            base_model_id=llm_install.output('model_uuid'),
            messages=[message_thread]
        )
    """

    IDENTIFIER = 'OPTICAL_REASONING_COGNITION_AGENT_GENERAL_PROMPTING'

    def __init__(
        self,
        model_type: str,
        base_model_id: str,
        messages: list[list[dict[str, Any]]] | str | None = None,
        adapter_id: str | None = None,
        max_new_tokens: int | str | None = None,
        max_image_tokens: int | str | None = None,
        enable_location_hint: bool | None = None,
        reference_name: str | None = None,
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'messages': messages,
                'model_type': model_type,
                'base_model_id': base_model_id,
                'adapter_id': adapter_id,
                'max_new_tokens': max_new_tokens,
                'max_image_tokens': max_image_tokens,
                'enable_location_hint': enable_location_hint,
            },
            title='Optical Reasoning & Cognition Agent for General Prompting',
            description='Optical Reasoning & Cognition Agent for General Prompting',
        )


class ImagesToPrintableFileBlock(Block):
    """
    This block renders each document's sequence of images into a separate PDF file and
    stores each resulting PDF in Blob storage. For every document provided,
    a new blob is created containing the rendered PDF.

    Available from V42.1.

    Mandatory parameters:

    :param documents: List of documents, each containing a document_id and list of image UUIDs

    Optional parameters:

    :param height_in_mm: the height of the document to be generated in millimeters.
        Default is 279.4 (US Letter height). Ignored when use_native_dimensions is True.
    :param width_in_mm: the width of the document to be generated in millimeters.
        Default is 215.9 (US Letter width). Ignored when use_native_dimensions is True.
    :param use_native_dimensions: Available from V42.3; when True, each page uses its source
        image's native dimensions instead of being resized to width_in_mm × height_in_mm.
        This preserves maximum image quality. Default is False. When enabled, the output
        height_in_mm and width_in_mm represent the bounding box (maximum dimensions across all
        pages).
    :param dpi: Available from V42.3; dots per inch to assume for images without embedded DPI
        metadata. Used to calculate physical dimensions in native dimensions mode. Default is 200
        (matching VECTOR_GRAPHICS_DPI used by the pagination pipeline).
    :param mime_type: the mime type of the document to be generated. Default is 'application/pdf'
    :param quality: Quality of pages (images) appended to the resulting document
        as a percentage (recommended 50%). Higher quality results in a larger file size for the
        generated PDF.
    :param mode: Mode of the images appended to the resulting document.
        Supported modes are RGB (default), L (grayscale) and 1 (black-and-white)

    Example usage::

        documents = [
            {
                'document_id': '48212a99-c099-42e3-bb45-75664db65341',
                'images': ['f42fc9af-b551-4403-aba6-d0eba2c41973', '...'],
            },
            {
                'document_id': 'delivery_receipt_xyz',
                'images': ['f42fc9af-b551-4403-aba6-d0eba2c41974', '...'],
            }
        ]

        # Fixed dimensions mode (default) - all pages resized to specified dimensions
        images_renderer_block = ImagesToPrintableFileBlock(
            reference_name='images_renderer',
            height_in_mm=279.4,
            width_in_mm=215.9,
            quality=50,
            mode='L',
            documents=documents
        )

        # Native dimensions mode - preserves original image quality
        images_renderer_native = ImagesToPrintableFileBlock(
            reference_name='images_renderer_native',
            use_native_dimensions=True,
            dpi=200,
            quality=80,
            documents=documents
        )

        output_ref = images_renderer_block.output()

    Example content of output_ref (fixed dimensions mode)::

        {
            "rendered_documents": [
                {
                    "document_id": "48212a99-c099-42e3-bb45-75664db65341",
                    "blob_uuid": "52e81c7f-aef6-4f69-b4a6-91fd770a607d",
                    "mime_type": "application/pdf",
                    "height_in_mm": 279.4,
                    "width_in_mm": 215.9,
                    "quality": 50,
                    "mode": "L",
                    "page_dimensions": [
                        {
                            "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                            "width_in_mm": 215.9,
                            "height_in_mm": 279.4,
                        },
                        {
                            "image_uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                            "width_in_mm": 215.9,
                            "height_in_mm": 279.4,
                        },
                    ]
                }
            ]
        }

    Example content of output_ref (native dimensions mode)::

        {
            "rendered_documents": [
                {
                    "document_id": "48212a99-c099-42e3-bb45-75664db65341",
                    "blob_uuid": "52e81c7f-aef6-4f69-b4a6-91fd770a607d",
                    "mime_type": "application/pdf",
                    "height_in_mm": 297.0,
                    "width_in_mm": 215.9,
                    "quality": 80,
                    "mode": "RGB",
                    "page_dimensions": [
                        {
                            "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                            "width_in_mm": 210.0,
                            "height_in_mm": 297.0,
                        },
                        {
                            "image_uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                            "width_in_mm": 215.9,
                            "height_in_mm": 279.4,
                        },
                    ]
                }
            ]
        }

    """

    IDENTIFIER = 'IMAGE_TO_PRINTABLE_FILE'

    def __init__(
        self,
        documents: list[dict[int | str, list[UUID]]],
        height_in_mm: float = 279.4,
        width_in_mm: float = 215.9,
        use_native_dimensions: bool = False,
        dpi: int = 200,
        mime_type: str = 'application/pdf',
        quality: int = 50,
        mode: str = 'RGB',
        reference_name: str | None = None,
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'documents': documents,
                'height_in_mm': height_in_mm,
                'width_in_mm': width_in_mm,
                'use_native_dimensions': use_native_dimensions,
                'dpi': dpi,
                'mime_type': mime_type,
                'quality': quality,
                'mode': mode,
            },
            title='Images to PDF',
            description='Renders a list of images into a PDF',
        )
