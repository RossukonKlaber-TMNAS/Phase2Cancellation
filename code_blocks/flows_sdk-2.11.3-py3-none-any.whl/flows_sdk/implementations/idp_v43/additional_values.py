from dataclasses import dataclass

JSON_OUTPUT_ROLE = 'json_output'
METADATA_TRIGGER_ROLE = 'metadata_trigger'

DEFAULT_ENTITY_RECOGNITION_PAGE_BATCH_SIZE = 15
DEFAULT_ENTITY_RECOGNITION_PAGE_OVERLAP = 1

REDACTION_SYNTHETIC_DATA_MODE = 'synthetic_data'
REDACTION_OPAQUE_BOX_MODE = 'opaque_box'
REDACTION_OBFUSCATED_BOX_MODE = 'obfuscated_box'


@dataclass
class HttpHeaderAuthorizationParams:
    authorization_header: str
    authorization_header_name: str


@dataclass
class OAuth2AuthorizationParams:
    auth_url: str
    client_id: str
    client_secret: str
    audience: str
    scope: str | None
