import itertools
from collections.abc import Iterator
from typing import Any

from flows_sdk.flows import Parameter


class InputsMeta(type):
    @staticmethod
    def _get_class_inputs(namespace: dict[str, Any]) -> list[str]:
        return [
            value
            for key, value in namespace.items()
            if isinstance(value, str) and not key.startswith('_')
        ]

    @classmethod
    def _merge_manifest_params(
        cls, owner_name: str, manifest_params_it: Iterator[Parameter]
    ) -> list[Parameter]:
        params_by_name: dict[str, Parameter] = {}
        conflicting_names: set[str] = set()

        for param in manifest_params_it:
            existing = params_by_name.get(param.name)
            if existing is None:
                params_by_name[param.name] = param
                continue

            if existing != param:
                conflicting_names.add(param.name)

        if conflicting_names:
            raise TypeError(
                f'Conflicting manifest parameter definitions {conflicting_names}'
                f' found in class {owner_name}'
            )

        return list(params_by_name.values())

    def __new__(
        cls, name: str, bases: tuple[type['BaseInputs'], ...], namespace: dict[str, Any]
    ) -> Any:
        if not all(issubclass(base, BaseInputs) for base in bases):
            raise TypeError(f'{name}: All base classes must be subclasses of BaseInputs')

        local_inputs = cls._get_class_inputs(namespace)
        local_input_names = set(local_inputs)

        if len(local_inputs) != len(local_input_names):
            raise TypeError(f'{name}: Duplicate input names found in class')

        inherited_manifest_params_it: Iterator[Parameter] = itertools.chain.from_iterable(
            base_cls.get_all_manifest_params() for base_cls in bases if base_cls is not BaseInputs
        )

        new_cls = super().__new__(cls, name, bases, namespace)
        local_manifest_params = new_cls._get_manifest_params()  # type: ignore[attr-defined]

        new_cls._all_manifest_params = cls._merge_manifest_params(  # type: ignore[attr-defined]
            name,
            itertools.chain(inherited_manifest_params_it, local_manifest_params),
        )

        return new_cls


class BaseInputs(metaclass=InputsMeta):
    """Base container for flow input names and manifest parameters.

    Subclasses define input-name constants as class attributes and implement
    `_get_manifest_params()` for their local manifest parameters.
    """

    _all_manifest_params: list[Parameter] = []

    @classmethod
    def get_all(cls, exclude: set[str] | None = None) -> list[str]:
        """Returns all input names across the inheritance chain."""
        exclude = exclude or set()
        return [param.name for param in cls._all_manifest_params if param.name not in exclude]

    @classmethod
    def get_all_manifest_params(cls) -> list[Parameter]:
        """Returns all manifest parameters across the inheritance chain."""

        return cls._all_manifest_params

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        """Returns the manifest parameters for the current class."""

        return []
