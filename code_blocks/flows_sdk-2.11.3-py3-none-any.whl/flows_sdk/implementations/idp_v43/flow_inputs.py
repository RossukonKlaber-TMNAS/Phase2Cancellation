from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v43.base_inputs import BaseInputs
from flows_sdk.utils import workflow_input


class FlowInputs(BaseInputs):
    WorkflowUuid = 'workflow_uuid'
    WorkflowName = 'workflow_name'
    WorkflowVersion = 'workflow_version'

    Trigger = '$trigger'

    @classmethod
    def create(cls) -> dict[str, Any]:
        return {
            cls.WorkflowUuid: workflow_input(cls.WorkflowUuid),
            cls.WorkflowName: workflow_input(cls.WorkflowName),
            cls.WorkflowVersion: workflow_input(cls.WorkflowVersion),
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.WorkflowUuid,
                type='string',
                title='Root workflow UUID',
                optional=True,
                ui={'hidden': True},
            ),
            Parameter(
                name=cls.WorkflowName,
                type='string',
                title='Root workflow name',
                optional=True,
                ui={'hidden': True},
            ),
            Parameter(
                name=cls.WorkflowVersion,
                type='string',
                title='Root workflow version',
                optional=True,
                ui={'hidden': True},
            ),
            Parameter(
                name=cls.Trigger,
                title='Trigger',
                type='object',
                ui={'hidden': True},
            ),
        ]
