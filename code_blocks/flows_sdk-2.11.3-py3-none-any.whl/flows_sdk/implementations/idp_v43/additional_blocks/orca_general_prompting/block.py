from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.additional_blocks.orca_general_prompting.settings import (
    OrcaGeneralPromptingSettings as Settings,
)
from flows_sdk.utils import workflow_input


class GeneralPromptingORCABlock(Block):
    """
    General Prompting ORCA Block

    This block requires a GPU to function.

    Mandatory parameters:

    :param model_type: Base model to be used for general prompting.
    :param base_model_id: The UUID of the block asset containing ORCA model weights.

    Parameters with defaults:

    :param messages: A list of prompt message threads sent to the model.
        Each message thread is a list of messages.
        Each message is a dictionary containing the keys "role" and "content".
        - Role is a string, with one of "system", "user", "assistant", depending on what the
        related content represents.
        "system" - there is usually a single system prompt in any list of messages, which
        outlines rules and recommendations for the generative model to follow.
        "user" - User messages should be messages sent by a person to the model.
        "assistant" - Assistant messages should be model responses.
        - Content is a mixed list that can contain text and images. Each content entry is
        formatted either as {'type': 'image', 'image': image_uuid} or
        {'type': 'text', 'text': 'content of the message'}
    :param adapter_id: UUID of a previously imported adapter to use.
        The base model will be used when not provided.
        Default value is None.
    :param max_new_tokens: The maximum number of tokens the model can extract, which
        should be scaled based on the number and length of field values.
        Default value is set to 1024.
    :param max_image_tokens: The maximum number of tokens allocated per image by the model.
        This is conceptually similar to setting image resolution. Larger values may
        increase accuracy on dense / hard to read images but will raise GPU memory usage.
        Default value is set to 1280.
    :param enable_location_hint: When set to True, the ORCA general
        prompting block will generate location hint related outputs. This can be useful for
        downstream tasks that require bounding boxes within the image. However, enable it will
        raise GPU memory usage and inference latency.
    :param thinking_budget: Available from V43.2; Soft cap on the number of reasoning
        ("thinking") tokens the model may generate before it is forced to close its thinking
        phase and produce the answer. Only applies to thinking-capable models with thinking
        enabled. Defaults to ``None`` (no cap).
    :param json_schema: Available from V43.2; Optional JSON Schema (a dict) used to constrain
        the model's generated output to valid JSON that conforms to the schema. Enables
        structured JSON output via the SGLang ``xgrammar`` grammar backend. When ``None`` (the
        default), decoding is unconstrained.
        For a reference on how to author JSON Schemas, see
        https://json-schema.org/understanding-json-schema/reference/type.
    :param model_meta_overrides: Available from V43.2; A dictionary of arguments used to
        override the model meta for the vlm_gpu atomic block. Defaults to ``None``
        (no overrides).
    :param concurrency_config_overrides: Available from V43.2; A dictionary of arguments used
        to override the concurrency config (e.g. ``max_batch_size``, ``num_kv_cache_tokens``)
        computed for the vlm_gpu atomic block. Defaults to ``None`` (no overrides).
    :param is_byo_model: Available from V43.2; A boolean flag indicating whether the specified
        base model is a bring-your-own (BYO) model. Defaults to ``False``.
    :param reference_name: unique reference name within a flow, a unique one will be generated
        when not provided.
    :param target_outputs: Available from V43.2; A list of completions, one per message thread
        in ``messages``. When provided, the block scores each completion against its own thread
        (teacher forcing) instead of generating an answer: the output carries the target text
        back, along with the per-token confidences derived from the prompt log-probabilities.
        Because no tokens are generated, this cannot be combined with ``json_schema``,
        ``enable_location_hint`` or ``thinking_budget``. Defaults to ``None`` (the model
        generates its own answer).
    :param disable_log_redaction: Available from V43.2; Debug only. When set to ``True``, the
        VLM blocks skip the redaction of document content (which may contain PII) in their logs.
        Defaults to ``False``.
    :param title: UI-visible title of the block. Defaults to
        'Optical Reasoning & Cognition Agent for General Prompting'.
    :param description: Description of the block. Both useful for documentation purpose and
        visible to users in the Flow studio. Defaults to
        'Optical Reasoning & Cognition Agent for General Prompting'.

    Output:
    The block returns an object with the following keys:

    * `orca_result`: The result generated by the model for the given prompt messages.
    * `metadata`: Metadata related to the general prompting process.

    Example usage::

        # Here we construct a simple static set of messages. But these can also be dynamic
        # and the output of a PythonCode block or other processing blocks.
        system_message = {'role': 'system', 'content': [
                {'type': 'text', 'text': 'You are a helpful assistant'}
        ]}
        prompt = {'role': 'user', 'content': [
            {'type': 'image', 'image': workflow_input('some_image_uuid')},
            {'type': 'text', 'text': 'Make a short summary of everything in the image'}
        ]}
        message_thread = [system_message, prompt]

        gp_block = GeneralPromptingORCABlock(messages=[message_thread])
    """

    IDENTIFIER = 'OPTICAL_REASONING_COGNITION_AGENT_GENERAL_PROMPTING'

    def __init__(
        self,
        model_type: str = workflow_input(Settings.OrcaType),
        base_model_id: str = workflow_input(Settings.OrcaBaseModelUUID),
        messages: list[list[dict[str, Any]]] | str | None = None,
        adapter_id: str | None = None,
        max_new_tokens: int | str | None = None,
        max_image_tokens: int | str | None = None,
        enable_location_hint: bool | None = None,
        thinking_budget: int | str | None = None,
        json_schema: dict[str, Any] | None = None,
        model_meta_overrides: dict[str, Any] | None = None,
        concurrency_config_overrides: dict[str, Any] | None = None,
        is_byo_model: bool = False,
        reference_name: str | None = None,
        target_outputs: list[str] | str | None = None,
        disable_log_redaction: bool | str | None = False,
        title: str | None = 'Optical Reasoning & Cognition Agent for General Prompting',
        description: str | None = 'Optical Reasoning & Cognition Agent for General Prompting',
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'messages': messages,
                'target_outputs': target_outputs,
                'model_type': model_type,
                'base_model_id': base_model_id,
                'adapter_id': adapter_id,
                'max_new_tokens': max_new_tokens,
                'max_image_tokens': max_image_tokens,
                'enable_location_hint': enable_location_hint,
                'thinking_budget': thinking_budget,
                'model_meta_overrides': model_meta_overrides,
                'concurrency_config_overrides': concurrency_config_overrides,
                'is_byo_model': is_byo_model,
                'json_schema': json_schema,
                'disable_log_redaction': disable_log_redaction,
            },
            title=title,
            description=description,
        )
