from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v43.base_inputs import BaseInputs

PROVIDER_NONE = 'none'
PROVIDER_GOOGLE = 'google'
PROVIDER_SMARTY = 'smarty'
PROVIDER_GEOAPIFY = 'geoapify'


class AddressParserSettings(BaseInputs):
    AddressParsingEnabled = 'address_parsing_enabled'
    ApiProvider = 'address_parser_api_provider'
    ApiKey = 'address_parser_api_key'
    ApiOptions = 'address_parser_api_options'

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        disabled_dep = Dependency(
            condition={'properties': {cls.AddressParsingEnabled: {'const': False}}},
            override={'ui': {'hidden': True}, 'optional': True},
        )
        provider_local_dep = Dependency(
            condition={'properties': {cls.ApiProvider: {'const': PROVIDER_NONE}}},
            override={'ui': {'hidden': True}, 'optional': True},
        )
        external_provider_condition = {
            'properties': {
                cls.ApiProvider: {'enum': [PROVIDER_GOOGLE, PROVIDER_SMARTY, PROVIDER_GEOAPIFY]}
            }
        }
        provider_external_dep = Dependency(
            condition=external_provider_condition,
            override={'ui': {'hidden': False}},
        )
        provider_external_key_required_dep = Dependency(
            condition=external_provider_condition,
            override={'ui': {'hidden': False}, 'optional': False},
        )

        # Provider-aware help: each dependency swaps the Provider Options
        # description for guidance specific to the selected provider (example
        # JSON + that provider's docs link), instead of one tooltip listing all
        # three. Conditions are mutually exclusive, so at most one applies.
        google_help_dep = Dependency(
            condition={'properties': {cls.ApiProvider: {'const': PROVIDER_GOOGLE}}},
            override={
                'description': (
                    'Google Address Validation API request options, merged verbatim into '
                    'the request body using its own parameter names. '
                    'Example: {"enableUspsCass": true, "regionCode": "US"}. '
                    'Reference: https://developers.google.com/maps/documentation/address-validation'
                    '\nNote: used for parsing (more complete components), not validation.'
                )
            },
        )
        smarty_help_dep = Dependency(
            condition={'properties': {cls.ApiProvider: {'const': PROVIDER_SMARTY}}},
            override={
                'description': (
                    'Smarty US Extract API request options, merged verbatim into the '
                    'request query string using its own parameter names. '
                    'Example: {"license": "us-core-cloud"}. '
                    'Reference: https://www.smarty.com/docs/cloud/us-extract-api'
                )
            },
        )
        geoapify_help_dep = Dependency(
            condition={'properties': {cls.ApiProvider: {'const': PROVIDER_GEOAPIFY}}},
            override={
                'description': (
                    'Geoapify Batch Geocoding request options, merged verbatim into the '
                    'request query string using its own parameter names. '
                    'Example: {"lang": "en", "filter": "countrycode:us"}. '
                    'Reference: https://apidocs.geoapify.com/docs/geocoding/batch/'
                )
            },
        )

        return [
            Parameter(
                name=cls.AddressParsingEnabled,
                type='boolean',
                value=False,
                title='Address Parsing Enabled',
                description=(
                    'Enable structured parsing of address-typed fields after transcription. '
                    'When disabled (default), address fields are returned as plain '
                    'transcription strings with no parsing or normalisation.'
                ),
                ui={
                    'warning': (
                        'Enabling address parsing may increase memory usage and '
                        'require additional infrastructure resources.'
                    )
                },
            ),
            Parameter(
                name=cls.ApiProvider,
                type='string',
                value=PROVIDER_NONE,
                title='Address Parsing Provider',
                description=(
                    'Controls which parser is used for address-typed fields after transcription. '
                    '"Local only" uses usaddress (US) and deepparse (international) without any '
                    'external API calls. The other options route all address fields through the '
                    'respective third-party address API and return a normalised address string '
                    'alongside structured components (street, city, zip, etc.).'
                ),
                schema={
                    'type': 'string',
                    'oneOf': [
                        {'title': 'Local only (no external API)', 'const': PROVIDER_NONE},
                        {'title': 'Google Address Validation API', 'const': PROVIDER_GOOGLE},
                        {'title': 'Smarty US Extract API', 'const': PROVIDER_SMARTY},
                        {'title': 'Geoapify Geocoding API', 'const': PROVIDER_GEOAPIFY},
                    ],
                },
                dependencies=[disabled_dep],
            ),
            Parameter(
                name=cls.ApiKey,
                type='string',
                optional=True,
                secret=True,
                title='API Key',
                description='Credential for the selected address parsing provider.',
                dependencies=[disabled_dep, provider_local_dep, provider_external_key_required_dep],
            ),
            Parameter(
                name=cls.ApiOptions,
                type='json',
                optional=True,
                value={},
                title='Provider Options',
                description=(
                    'Provider-specific request options as a JSON object, merged verbatim '
                    "into the provider request using the provider's own parameter names. "
                    'Select a provider above to see an example and its documentation link.'
                ),
                dependencies=[
                    disabled_dep,
                    provider_local_dep,
                    provider_external_dep,
                    google_help_dep,
                    smarty_help_dep,
                    geoapify_help_dep,
                ],
            ),
        ]

    @classmethod
    def get_block_level_manifest_params(cls) -> list[Parameter]:
        return [p.model_copy(update={'optional': True}) for p in cls.get_all_manifest_params()]
