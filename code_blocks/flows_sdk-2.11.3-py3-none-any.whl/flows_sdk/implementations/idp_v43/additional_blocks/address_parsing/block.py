from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.additional_blocks.address_parsing.settings import (
    AddressParserSettings,
)
from flows_sdk.utils import workflow_input


class AddressParserBlock(Block):
    """
    Address Parser Block parses address-typed fields into structured components (street, city,
    zip, etc.), either locally (usaddress for US addresses, deepparse for international
    addresses) or by routing them through a configured third-party address API.

    Mandatory parameters:

    :param fields: list of address fields to parse, each a dict with `field_uuid`,
        `data_type_kind` set to `'address'`, `address_type`, and `transcription`

    Optional Parameters:

    :param address_parsing_enabled: flag to enable or disable address parsing,
        defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
    :param address_parser_api_provider: selects the address parsing provider
        ('none' / 'google' / 'smarty' / 'geoapify'),
        defaults to workflow_input(AddressParserSettings.ApiProvider)
    :param address_parser_api_key: API key for the configured provider,
        defaults to workflow_input(AddressParserSettings.ApiKey)
    :param address_parser_api_options: provider-specific JSON options,
        defaults to workflow_input(AddressParserSettings.ApiOptions)
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param title: overrides the block's default title shown in Flow Studio,
        defaults to 'Address Parser'
    :param description: overrides the block's default description shown in Flow Studio,
        defaults to 'Parses address-typed fields into structured components'

    Output:
    The block returns an object with the following keys:

    * `results`: list of parsed address results, one per input field.

    Example usage::

        address_parser = AddressParserBlock(
            reference_name='address_parser',
            fields=flexible_extraction.output('submission.documents[0].fields'),
            address_parser_api_provider='google',
        )
    """

    IDENTIFIER = 'ADDRESS_PARSER'

    def __init__(
        self,
        fields: list[dict[str, Any]] | str,
        address_parsing_enabled: bool | str = workflow_input(
            AddressParserSettings.AddressParsingEnabled
        ),
        address_parser_api_provider: str = workflow_input(AddressParserSettings.ApiProvider),
        address_parser_api_key: str | None = workflow_input(AddressParserSettings.ApiKey),
        address_parser_api_options: str | dict | None = workflow_input(
            AddressParserSettings.ApiOptions
        ),
        reference_name: str | None = None,
        title: str = 'Address Parser',
        description: str = 'Parses address-typed fields into structured components',
    ) -> None:
        inputs: dict[str, Any] = {
            'fields': fields,
            AddressParserSettings.AddressParsingEnabled: address_parsing_enabled,
            AddressParserSettings.ApiProvider: address_parser_api_provider,
            AddressParserSettings.ApiKey: address_parser_api_key,
            AddressParserSettings.ApiOptions: address_parser_api_options,
        }

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )
