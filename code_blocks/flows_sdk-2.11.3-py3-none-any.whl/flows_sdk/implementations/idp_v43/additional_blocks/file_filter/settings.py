from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v43.base_inputs import BaseInputs


class FileFilterSettings(BaseInputs):
    FileFilterType = 'file_filter_filter_type'
    FileFilterMinimumImageWidth = 'file_filter_minimum_image_width'
    FileFilterMinimumImageHeight = 'file_filter_minimum_image_height'
    FileFilterMinimumFileSizeKB = 'file_filter_minimum_file_size_kb'
    FileFilterFileExtensionsAction = 'file_filter_file_extensions_action'
    FileFilterFileExtensions = 'file_filter_file_extensions'
    FileFilterFileExtensionsOther = 'file_filter_file_extensions_other'

    @classmethod
    def create(
        cls,
        filter_type: str,
        minimum_image_width: int | None,
        minimum_image_height: int | None,
        minimum_file_size_kb: float | None,
        file_extensions_action: str,
        file_extensions: list[str] | None,
        file_extensions_other: str | None,
    ) -> dict[str, Any]:
        return {
            cls.FileFilterType: filter_type,
            cls.FileFilterMinimumImageWidth: minimum_image_width,
            cls.FileFilterMinimumImageHeight: minimum_image_height,
            cls.FileFilterMinimumFileSizeKB: minimum_file_size_kb,
            cls.FileFilterFileExtensionsAction: file_extensions_action,
            cls.FileFilterFileExtensions: file_extensions,
            cls.FileFilterFileExtensionsOther: file_extensions_other,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.FileFilterType,
                type='string',
                schema={
                    'type': 'string',
                    'oneOf': [
                        {'title': 'Apply to all files', 'const': 'ALL_FILES'},
                        {'title': 'Apply to images only', 'const': 'IMAGES_ONLY'},
                    ],
                },
                description='Determines whether filters will be applied '
                'to all files or only to image files',
                title='All files or images only',
                value='ALL_FILES',
            ),
            Parameter(
                name=cls.FileFilterMinimumImageWidth,
                type='number',
                description='Minimum width (in pixels) for an image to be processed. This filter '
                'is only applied to images and has no impact on other files.',
                title='Minimum image width (px)',
                optional=True,
            ),
            Parameter(
                name=cls.FileFilterMinimumImageHeight,
                type='number',
                description='Minimum height (in pixels) for an image to be processed. This '
                'filter is only applied to images and has no impact on other files.',
                title='Minimum image height (px)',
                optional=True,
            ),
            Parameter(
                name=cls.FileFilterMinimumFileSizeKB,
                type='number',
                description='Minimum file size (in KB) for a file to be processed',
                title='Minimum file size (KB)',
                optional=True,
            ),
            Parameter(
                name=cls.FileFilterFileExtensionsAction,
                type='string',
                schema={
                    'type': 'string',
                    'oneOf': [
                        {'title': 'Do not filter files by extension', 'const': 'NONE'},
                        {'title': 'Allow only these file extensions', 'const': 'ALLOW'},
                        {'title': 'Deny files with these extensions', 'const': 'DENY'},
                    ],
                },
                description='Allow or deny files based on extensions',
                title='File extension action',
                value='NONE',
            ),
            Parameter(
                name=cls.FileFilterFileExtensions,
                type='array',
                schema={
                    'type': 'array',
                    'minItems': 1,
                    'values': {
                        'oneOf': [
                            {'const': 'png', 'title': 'png'},
                            {'const': 'pdf', 'title': 'pdf'},
                            {'const': 'jpg', 'title': 'jpg'},
                            {'const': 'jpeg', 'title': 'jpeg'},
                            {'const': 'heic', 'title': 'heic'},
                            {'const': 'heif', 'title': 'heif'},
                            {'const': 'xps', 'title': 'xps'},
                            {'const': 'tif', 'title': 'tif'},
                            {'const': 'tiff', 'title': 'tiff'},
                            {'const': 'zip', 'title': 'zip'},
                            {'const': 'gif', 'title': 'gif'},
                            {'const': '', 'title': '<no extension>'},
                            {'const': 'other', 'title': 'other'},
                        ]
                    },
                },
                dependencies=[
                    Dependency(
                        condition={
                            'required': [cls.FileFilterFileExtensionsAction],
                            'properties': {
                                cls.FileFilterFileExtensionsAction: {'not': {'const': 'NONE'}}
                            },
                        },
                        override={'optional': False, 'ui': {'hidden': False}},
                    ),
                    Dependency(
                        condition={
                            'required': [cls.FileFilterType],
                            'properties': {cls.FileFilterType: {'const': 'IMAGES_ONLY'}},
                        },
                        override={
                            'schema': {
                                'type': 'array',
                                'minItems': 1,
                                'values': {
                                    'oneOf': [
                                        {'const': 'png', 'title': 'png'},
                                        {'const': 'jpg', 'title': 'jpg'},
                                        {'const': 'jpeg', 'title': 'jpeg'},
                                        {'const': 'heic', 'title': 'heic'},
                                        {'const': 'heif', 'title': 'heif'},
                                        {'const': 'tif', 'title': 'tif'},
                                        {'const': 'tiff', 'title': 'tiff'},
                                        {'const': 'gif', 'title': 'gif'},
                                        {'const': '', 'title': '<no extension>'},
                                        {'const': 'other', 'title': 'other'},
                                    ]
                                },
                            }
                        },
                    ),
                ],
                ui={'hidden': True},
                description='List of file extensions to use for filtering. Select the “other” '
                'option to specify any file extensions you want to filter by that '
                'do not appear in this list.',
                title='File extensions',
                optional=True,
            ),
            Parameter(
                name=cls.FileFilterFileExtensionsOther,
                type='string',
                dependencies=[
                    Dependency(
                        condition={
                            'required': [cls.FileFilterFileExtensions],
                            'properties': {
                                cls.FileFilterFileExtensions: {
                                    'contains': {'enum': ['other']},
                                    'not': {'const': None},
                                }
                            },
                        },
                        override={
                            'optional': False,
                            'schema': {'type': 'string', 'minLength': 1},
                            'ui': {'hidden': False},
                        },
                    )
                ],
                ui={'hidden': True},
                description='Comma-separated list of additional file extensions '
                'to use for filtering',
                title='Other file extensions',
                optional=True,
            ),
        ]
