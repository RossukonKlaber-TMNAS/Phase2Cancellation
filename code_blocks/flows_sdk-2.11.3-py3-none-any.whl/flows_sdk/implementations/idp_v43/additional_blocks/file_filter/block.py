from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.additional_blocks.file_filter.settings import (
    FileFilterSettings as Settings,
)
from flows_sdk.implementations.idp_v43.flow_inputs import FlowInputs
from flows_sdk.utils import apply_output_wrapping_mode, workflow_input


class FileFilterBlock(Block):
    """
    Available from V40.2

    File Filter Block filters out unwanted files from the input of a flow

    This block is meant to be placed at the start of the flow/subflow -
    BEFORE the SubmissionBootstrapBlock, not after it.
    It requires the output of a connector (e.g. Email Listener) or an API submission
    as input data, and its output is meant to be consumed by a SubmissionBootstrapBlock.

    Mandatory parameters:

        This block has no strictly required parameters - all of its filters are optional.

    Optional Parameters:

    :param trigger: the trigger input from a connector - if not set explicitly,
        it will default to the workflow input trigger (which is where this value is normally found)
    :param filter_type: a discrete value, either "ALL_FILES" or "IMAGES_ONLY". Determines
        what kind of files the filters will be applied to. Default value is "ALL_FILES".
        If set to "IMAGES_ONLY", all filtering options will be applied only to images, other files
        will pass through.
    :param minimum_image_width: image width in pixels - half of the image dimension filter.
        Any image with less width than configured here will be filtered out.
        Defaults to None (will do nothing).
    :param minimum_image_height: image height in pixels - second half of the image dimension filter.
        Any image with less height than configured here will be filtered out.
        Defaults to None (will do nothing).
    :param minimum_file_size_kb: represents the file size filter. Any file whose disk size is less
        than this number (in KB) will be filtered out. May be fractional.
        Defaults to None (will do nothing).
    :param file_extensions_action: a discrete value, either "ALLOW", "DENY" or "NONE".
        Represents the function of the file extension filter.
        "ALLOW" means we only allow the configured file extensions.
        "DENY" means we only deny the configured file extensions.
        "NONE" means no file extension filtering takes place.
        Defaults to "NONE"
    :param file_extensions: a list of strings, representing the file extensions
        used for file extension filtering.
        Expected if file_extensions_action is not "NONE".
        Otherwise, defaults to None (will do nothing).
    :param file_extensions_other: a comma separated list of file extensions
        used for file extension filtering.
        Meant for adding extra extensions that are not available in the pre-defined list.
        Optional, defaults to None (will do nothing). However, it is expected
        in case the `file_extensions` parameter contains "other".
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param title: overrides the block's default title shown in Flow Studio,
        defaults to 'File Filter'
    :param description: overrides the block's default description shown in Flow Studio,
        defaults to 'Filters out unwanted files from the input of a flow'

    Output:
    The block returns an object with the following keys:

    * `result.filtered_trigger`: The trigger payload with filtered-out files removed, meant to
      be passed as the `trigger` input to a `SubmissionBootstrapBlock`.

    Example usage::

        # File Filter Block filters out unwanted files from the input of a flow
        file_filter_block = FileFilterBlock(
            # trigger: str = workflow_input(Inputs.Trigger),  # usually not necessary to set this
            reference_name='file_filter',
            filter_type='ALL_FILES',
            minimum_image_width=500,
            minimum_image_height=500,
            minimum_file_size_kb=2.5,
            file_extensions_action='ALLOW',
            file_extensions=['pdf', 'png'],
            file_extensions_other='jpg,svg,txt',
        )

        # reference to the output of FileFilterBlock which can be passed as input to the
        # next block (a SubmissionBootstrapBlock)
        output_ref = file_filter_block.output('result.filtered_trigger')
        submission_bootstrap = SubmissionBootstrapBlock(trigger=output_ref)

    When the ``HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE`` env var selects ``no_wrapping``, the output is
    no longer wrapped under ``result``, so reference it directly instead::

        output_ref = file_filter_block.output('filtered_trigger')

    Example content of output_ref::

        {
            "payload": {
                "blob_storage_files": [
                    {
                        "uuid": "db58606e-32f9-42c9-a0bc-ed9848ff247a",
                    }
                ],
                "filtered_files": [
                    {
                        "uuid": "db58606e-32f9-42c9-a0bc-ed9848ff246e",
                        "filtered_by": [
                            "file_size_filter"
                        ]
                    },
                ]
            }
        }
    """

    IDENTIFIER = 'FILE_FILTER'

    def __init__(
        self,
        trigger: str = workflow_input(FlowInputs.Trigger),
        filter_type: str = workflow_input(Settings.FileFilterType),
        minimum_image_width: int | str | None = workflow_input(
            Settings.FileFilterMinimumImageWidth
        ),
        minimum_image_height: int | str | None = workflow_input(
            Settings.FileFilterMinimumImageHeight
        ),
        minimum_file_size_kb: float | str | None = workflow_input(
            Settings.FileFilterMinimumFileSizeKB
        ),
        file_extensions_action: str = workflow_input(Settings.FileFilterFileExtensionsAction),
        file_extensions: list[str] | str | None = workflow_input(Settings.FileFilterFileExtensions),
        file_extensions_other: str | None = workflow_input(Settings.FileFilterFileExtensionsOther),
        reference_name: str | None = None,
        title: str = 'File Filter',
        description: str = 'Filters out unwanted files from the input of a flow',
    ) -> None:
        inputs: dict[Any, Any] = {
            '$trigger': trigger,
            'filter_type': filter_type,
            'minimum_image_width': minimum_image_width,
            'minimum_image_height': minimum_image_height,
            'minimum_file_size_kb': minimum_file_size_kb,
            'file_extensions_action': file_extensions_action,
            'file_extensions': file_extensions,
            'file_extensions_other': file_extensions_other,
        }
        # File Filter is an alias for a code block, so it wraps its output in "result" at runtime
        # unless the no-wrapping mode is stamped into its input (forwarded to the aliased block).
        apply_output_wrapping_mode(inputs)

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )
