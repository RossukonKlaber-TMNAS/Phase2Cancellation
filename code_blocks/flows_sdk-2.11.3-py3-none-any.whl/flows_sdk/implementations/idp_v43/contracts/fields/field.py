from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.common.constants import (
    ConfidenceLiteral,
    EntryStatusLiteral,
    ProcessTypeLiteral,
    SourceLiteral,
)
from flows_sdk.implementations.idp_v43.contracts.fields.location import FieldLocation


@dataclass(kw_only=True)
class InternalField:
    uuid: UUID
    """
    Unique system-generated identifier.
    """

    status: EntryStatusLiteral | None = None
    """
    Current status of the Field.
    """

    layout_field_uuid: UUID
    """
    The unique identifier of the specific layout field this Field was matched to.
    """

    layout_page_uuid: UUID
    """
    The unique identifier of the layout page that this Field was matched to.
    """

    data_type_uuid: UUID
    """
    The unique identifier of the data type of the Field.
    """

    source_uuid: UUID | None
    """
    Stable layout-level field identifier used to map equivalent Fields across versions of the same
    layout.
    """

    original_source_uuid: UUID | None
    """
    The original stable layout-level field identifier. Used to map Fields from partially matched
    Documents to a specific layout field.
    """

    shared_field_uuid: UUID | None
    """
    The unique identifier of the shared field, if applicable.
    """

    field_number: int
    """
    One-based index, defining the number of the Field within the layout.
    """

    field_name: str
    """
    The name of the layout field that this Field was matched to.
    """

    output_name: str
    """
    The output name of the layout field that this Field was matched to.
    """

    required: bool
    """
    Indicates whether this Field was defined as required in the layout.
    """

    repeated: bool
    """
    For fields in Structured layouts, indicates whether this Field can appear multiple times. Data
    from repeated fields is extracted only from the Field's first occurrence in a Document.
    """

    dropout: bool
    """
    Indicates whether text in the Field's background is removed from the transcription, as defined
    in the layout.
    """

    multiline: bool
    """
    Indicates whether this Field is expected to have multiple lines of text, as defined in the
    layout.
    """

    identification_sv_mode: int
    """
    Indicates how Supervision affects the identification of the Field. Possible values are:

        * ``0`` (default) - using the default identification process.
        * ``2`` (auto_identify) - the field will never go to Identification Supervision, regardless
          of the machine's confidence.
        * ``3`` (sv_always) - the field will always go to Identification Supervision, regardless of
          the machine's confidence.

    Ignored when ``process_manual_identification_type`` is set.
    """

    transcription_sv_mode: int
    """
    Indicates how Supervision affects the transcription of the Field. Possible values are:

        * ``0`` (default) - using the default transcription process.
        * ``1`` (consensus) - this field requires multiple sources to agree on the transcription
          before its processing is complete.
        * ``2`` (auto_transcribe) - the field will never go to Transcription Supervision, regardless
          of the machine's confidence.
        * ``3`` (sv_always) - the field will always go to Transcription Supervision, regardless of
          the machine's confidence.
    """

    language: str | None
    """
    The language of the layout field that this Field was matched to.
    """

    notes: str | None
    """
    Additional notes or comments related to the Field.
    """

    transcription_target_accuracy: float | None
    """
    The target accuracy for the transcription of this Field, as defined in the layout.
    """

    process_manual_identification_type: ProcessTypeLiteral | None = None
    """
    Overrides the normal extraction process by forcing or bypassing Identification Supervision for
    this Field.

    When set, this value overrides ``identification_sv_mode``.
    """

    process_machine_transcription_type: ProcessTypeLiteral | None = None
    """
    Overrides the normal extraction process by forcing or bypassing machine transcription for
    this Field.
    """

    process_flexible_extraction_type: ProcessTypeLiteral | None = None
    """
    Overrides the normal extraction process by forcing or bypassing Flexible Extraction Supervision
    for this Field.
    """

    process_orca_type: ProcessTypeLiteral | None = None
    """
    Overrides the normal extraction process by forcing or bypassing ORCA extraction for
    this Field.
    """

    identification_source: SourceLiteral
    """
    The method by which the Field was identified.
    """

    identification_confidence: ConfidenceLiteral
    """
    The confidence of the Field's identification.
    """

    occurrence_index: int
    """
    Zero-based index of this occurrence among all occurrences for the same layout field and in the
    same Document.
    """

    locations: list[FieldLocation]
    """
    Array of locations where the Field appears.
    """

    page_number: int
    """
    Corresponds to the page number of the first ``FieldLocation`` of the Field.
    If the Field has no locations, will reference the first page of the Document.
    """

    bounding_box: list[float] | None
    """
    Coordinates of the bounding box of the first ``FieldLocation`` of the Field.
    If the Field has no locations, will be ``None``.
    """

    exceptions: list[str]
    """
    List of exceptions encountered during processing.
    """


@dataclass(kw_only=True)
class Field(InternalField):
    """
    Represents a concrete occurrence of a field that has been defined for extraction as part of a
    layout.
    """

    id: int
    """
    Unique system-generated identifier.
    """
