from dataclasses import dataclass
from typing import Literal


@dataclass(kw_only=True)
class FieldLocation:
    """
    Represents the location of a field on a page.
    """

    type: Literal['approximate', 'exact']
    """
    The type of location.
    """

    position: int
    """
    One-based index of this location among all locations for the same Field,
    ordered by reading order. Sort by this property to reconstruct the Field's
    content in the sequence it appears in across pages.
    """

    page_number: int
    """
    Reference to the ``document_page_number`` of the Page where the Field is located.
    """

    bounding_box: list[float]
    """
    The location of the Field on the Page, as an array of four normalized coordinates in the format
    ``[start_x, start_y, end_x, end_y]``, relative to page dimensions.
    """
