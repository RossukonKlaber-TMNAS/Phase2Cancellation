from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.common.constants import (
    ConfidenceLiteral,
    ProcessTypeLiteral,
)
from flows_sdk.implementations.idp_v43.contracts.tables.column import Column, InternalColumn
from flows_sdk.implementations.idp_v43.contracts.tables.row import Row


@dataclass(kw_only=True)
class InternalTable:
    layout_table_uuid: UUID
    """
    The unique identifier of the specific layout table this Table was matched to.
    """

    layout_table_name: str
    """
    The name of the layout table that this Table was matched to.
    """

    parent_layout_table_uuid: UUID | None = None
    """
    Indicates the ``layout_table_uuid`` of the parent Table, if applicable.
    """

    process_manual_identification_type: ProcessTypeLiteral | None = None
    """
    Overrides the normal extraction process by forcing or bypassing Identification Supervision for
    this Table.
    """

    identification_confidence: ConfidenceLiteral
    """
    The combined Identification confidence for the entire table hierarchy. If any table in the
    parent/child hierarchy is not confidently predicted, the value will be ``not_sure`` even if the
    individual table prediction is ``sure``.
    """

    model_prediction: ConfidenceLiteral
    """
    The Identification confidence for this specific Table only, independent of its parent or child
    tables.
    """

    rows: list[Row]
    """
    Array of Row objects identified as being part of this Table.
    """

    columns: list[InternalColumn]
    """
    Array of Column objects identified as being part of this Table.
    """


@dataclass(kw_only=True)
class Table(InternalTable):
    """
    Represents a concrete table that has been defined for extraction as part of a layout.
    """

    columns: list[Column]  # type: ignore[assignment]
