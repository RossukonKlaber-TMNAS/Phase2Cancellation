from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.tables.cell import Cell, InternalCell


@dataclass(kw_only=True)
class InternalColumn:
    layout_column_uuid: UUID
    """
    The unique identifier of the specific layout column.
    """

    data_type_uuid: UUID
    """
    The unique identifier of the data type of the TableColumn.
    """

    source_uuid: UUID | None
    """
    Stable layout-level column identifier used to map equivalent Columns across versions of the same
    layout.
    """

    column_number: int
    """
    One-based index, defining the number of the Column within the layout.
    """

    field_name: str
    """
    The name of the Column as defined in the layout.
    """

    output_name: str
    """
    The output name of the Column as defined in the layout.
    """

    required: bool
    """
    Indicates whether this Column was defined as required in the layout.
    """

    dropout: bool
    """
    Indicates whether text in the background of the cells in this Column is removed from the
    transcription, as defined in the layout.
    """

    multiline: bool
    """
    Indicates whether this Column is expected to have multiple lines of text, as defined in the
    layout.
    """

    transcription_sv_mode: int
    """
    Indicates how Supervision affects the transcription of the cells in this Column.
    Possible values are:

        * ``0`` (default) - using the default transcription process.
        * ``1`` (consensus) - the cells require multiple sources to agree on the transcription
          before their processing is complete.
        * ``2`` (auto_transcribe) - the cells will never go to Transcription Supervision,
          regardless of the machine's confidence.
        * ``3`` (sv_always) - the cells will always go to Transcription Supervision, regardless of
          the machine's confidence.
    """

    language: str | None
    """
    The language of the Column as defined in the layout.
    """

    notes: str | None
    """
    Additional notes or comments related to the Column.
    """

    transcription_target_accuracy: float | None = None
    """
    The target accuracy for the transcription of the cells in this Column, as defined in the layout.
    """

    cells: list[InternalCell]
    """
    Array of Cell objects identified as being part of this Column.
    """


@dataclass(kw_only=True)
class Column(InternalColumn):
    """
    Represents a concrete column in a table that has been defined for extraction as part of a
    layout.
    """

    cells: list[Cell]  # type: ignore[assignment]
