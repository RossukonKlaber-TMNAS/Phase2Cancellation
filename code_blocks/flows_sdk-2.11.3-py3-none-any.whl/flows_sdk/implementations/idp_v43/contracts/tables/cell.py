from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.common.constants import (
    ConfidenceLiteral,
    EntryStatusLiteral,
    ProcessTypeLiteral,
    SourceLiteral,
)


@dataclass(kw_only=True)
class InternalCell:
    uuid: UUID
    """
    Unique system-generated identifier.
    """

    status: EntryStatusLiteral | None = None
    """
    Current status of the Cell.
    """

    process_machine_transcription_type: ProcessTypeLiteral | None = None
    """
    Overrides the normal extraction process by forcing or bypassing machine transcription for
    this Cell.
    """

    process_flexible_extraction_type: ProcessTypeLiteral | None = None
    """
    Overrides the normal extraction process by forcing or bypassing Flexible Extraction Supervision
    for this Cell.
    """

    identification_source: SourceLiteral
    """
    The method by which the Cell was identified.
    """

    identification_confidence: ConfidenceLiteral
    """
    The confidence of the Cell's identification.
    """

    layout_column_uuid: UUID
    """
    The unique identifier of the specific layout column this Cell was matched to.
    """

    row_number: int
    """
    Reference to the ``row_number`` of the Row where the Cell is located.
    """

    page_number: int
    """
    Reference to the ``document_page_number`` of the Page where the Cell is located.
    """

    bounding_box: list[float] | None = None
    """
    The location of the Cell on the Page, as an array of four normalized coordinates in the format
    ``[start_x, start_y, end_x, end_y]``, relative to page dimensions.
    """

    exceptions: list[str]
    """
    List of exceptions encountered during processing.
    """


@dataclass(kw_only=True)
class Cell(InternalCell):
    """
    Represents a concrete cell in a table that has been defined for extraction as part of a layout.
    """

    id: int
    """
    Unique system-generated identifier.
    """
