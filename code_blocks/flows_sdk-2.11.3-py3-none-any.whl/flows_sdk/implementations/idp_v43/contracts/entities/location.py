from dataclasses import dataclass


@dataclass(kw_only=True)
class EntityLocation:
    """
    Represents the location of an entity on a page.
    """

    position: int
    """
    One-based index of this location among all locations for the same Entity,
    ordered by reading order. Sort by this property to reconstruct the Entity's
    content in the sequence it appears across pages.
    """

    page_number: int
    """
    Reference to the ``submission_page_number`` of the Page where the Entity is located.
    """

    bounding_box: list[float]
    """
    The location of the Entity on the Page, as array of four numbers in the format
    ``[start_x, start_y, end_x, end_y]``.
    """

    text: str
    """
    The text extracted from the Entity location.
    """

    raw_text: str
    """
    The raw text extracted from the Entity location.
    """
