from typing import Literal, TypeAlias

EntityOriginLiteral: TypeAlias = Literal['NER', 'CED', 'Signature']
