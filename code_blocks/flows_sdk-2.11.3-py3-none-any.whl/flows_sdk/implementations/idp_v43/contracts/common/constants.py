from enum import Enum
from typing import Literal, TypeAlias


class ProcessType(Enum):
    FORCE = 'FORCE'
    ALWAYS_FORCE = 'ALWAYS_FORCE'
    SKIP = 'SKIP'
    ALWAYS_SKIP = 'ALWAYS_SKIP'

    def is_forcing(self) -> bool:
        return self in {ProcessType.FORCE, ProcessType.ALWAYS_FORCE}


ProcessTypeLiteral: TypeAlias = Literal['FORCE', 'ALWAYS_FORCE', 'SKIP', 'ALWAYS_SKIP']


class EntryStatus(Enum):
    PROCESSING = 'processing'
    COMPLETE = 'complete'


EntryStatusLiteral: TypeAlias = Literal['processing', 'complete']


class Source(Enum):
    MACHINE = 'machine'
    HUMAN = 'human'


SourceLiteral: TypeAlias = Literal['machine', 'human']


class Confidence(Enum):
    SURE = 'sure'
    NOT_SURE = 'not_sure'


ConfidenceLiteral: TypeAlias = Literal['sure', 'not_sure']
