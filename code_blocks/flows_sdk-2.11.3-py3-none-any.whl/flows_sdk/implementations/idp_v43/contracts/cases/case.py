from dataclasses import dataclass
from datetime import datetime
from uuid import UUID


@dataclass(kw_only=True)
class Case:
    """
    The Case object represents a set of documents collated for a particular purpose.
    """

    id: int
    """
    Unique system-generated identifier.
    """

    uuid: UUID
    """
    Unique system-generated identifier that remains unique when there is a need to migrate case
    data between systems.
    """

    external_case_id: str
    """
    User-defined identifier that can be included as part of the Case object during case creation.
    """

    notes: str
    """
    User-defined string that can be included as part of the Case object during case creation
    or update.
    """

    start_time: datetime
    """
    Time the Case was created.
    """

    update_time: datetime
    """
    Time the Case was last updated.
    """

    to_delete_time: datetime | None = None
    """
    Time the Case is scheduled to be deleted, if applicable.
    """

    submissions: list[int]
    """
    Array of ``id``\\s of Submissions with Pages (or Documents) included in this Case.
    """

    submission_files: list[str]
    """
    Array of strings representing the names of files comprising the Case.
    """

    unassigned_pages: list[int]
    """
    Array of ``id``\\s of Pages that are included in the Case but not yet assigned to a Document.
    """

    documents: list[int]
    """
    Array of ``id``\\s of Documents included in the Case.
    """
