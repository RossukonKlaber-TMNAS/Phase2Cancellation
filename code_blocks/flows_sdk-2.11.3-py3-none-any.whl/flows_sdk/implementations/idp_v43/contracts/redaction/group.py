from dataclasses import dataclass

from flows_sdk.implementations.idp_v43.contracts.redaction.page import (
    InternalRedactedPage,
    RedactedPage,
)


@dataclass(kw_only=True)
class InternalRedactedGroup:
    identifier: str
    """
    Identifier of the source redaction group.
    """

    pages: list[InternalRedactedPage]
    """
    Array of RedactedPage objects included in this RedactedGroup.
    """


@dataclass(kw_only=True)
class RedactedGroup(InternalRedactedGroup):
    """
    The RedactedGroup object represents a group of redacted pages.
    """

    pages: list[RedactedPage]  # type: ignore[assignment]
