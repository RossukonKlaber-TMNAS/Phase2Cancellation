from dataclasses import dataclass


@dataclass(kw_only=True)
class Redaction:
    """
    Represents a single redaction applied to a page.
    """

    kind: str
    """
    The normalized redaction category.
    """

    bounding_box: list[float]
    """
    The location of the redacted text on the Page, as an array of four numbers in the format
    ``[start_x, start_y, end_x, end_y]``.
    """

    original_text: str
    """
    The original text before redaction.
    """

    redacted_text: str
    """
    The replacement text written into the page image. May be empty when text is not replaced
    (e.g., in opaque/box-based redaction modes).
    """
