from dataclasses import dataclass


@dataclass(kw_only=True)
class ImageCorrectionModelInfo:
    """
    Provides information about the models used for image correction.
    """

    rotation_model: str
    """
    The version of the rotation-detection model used for image correction.
    """

    mobile_model: str | None
    """
    The version of the mobile-correction model used for image correction, if applicable.
    """


@dataclass(kw_only=True)
class ImageCorrectionPerspectiveTransform:
    """
    Provides information about the perspective transform applied during mobile correction.
    """

    absolute_matrix: list[list[float]]
    """
    The 3x3 perspective (homography) matrix in absolute pixel coordinates.
    """

    relative_matrix: list[list[float]]
    """
    The 3x3 perspective (homography) matrix in normalized relative coordinates.
    """

    relative_corner_points: list[list[float]]
    """
    The corner points of the perspective transform, represented as relative
    coordinates (between 0 and 1) with respect to the original image dimensions.
    """
