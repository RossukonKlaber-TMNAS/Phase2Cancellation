from enum import Enum
from typing import Literal, TypeAlias


class PageStatus(Enum):
    PROCESSING = 'processing'
    FAILED = 'failed'
    COMPLETE = 'complete'


PageStatusLiteral: TypeAlias = Literal['processing', 'failed', 'complete']


class PageType(Enum):
    UNASSIGNED_PAGE = 'unassigned_page'
    BLANK_PAGE = 'blank_page'
    OTHER_PAGE = 'other_page'
    ADDITIONAL_FORM_PAGE = 'additional_form_page'
    DOCUMENT_PAGE = 'document_page'
    UNKNOWN_PAGE = 'unknown_page'
    FAILED = 'failed'

    @classmethod
    def get_unmatched_types(cls) -> list['PageType']:
        return [cls.UNASSIGNED_PAGE, cls.UNKNOWN_PAGE, cls.FAILED]

    @classmethod
    def get_non_document_types(cls) -> list['PageType']:
        return [cls.BLANK_PAGE, cls.OTHER_PAGE, cls.ADDITIONAL_FORM_PAGE]


PageTypeLiteral: TypeAlias = Literal[
    'unassigned_page',
    'blank_page',
    'other_page',
    'additional_form_page',
    'document_page',
    'unknown_page',
    'failed',
]


class ClassificationType(Enum):
    MANUAL = 'manual'
    MACHINE = 'machine'

    @classmethod
    def get_supported_types(cls, page_type: PageType) -> list['ClassificationType']:
        if page_type == PageType.FAILED:
            return [cls.MACHINE]

        if page_type == PageType.ADDITIONAL_FORM_PAGE:
            return [cls.MANUAL]

        return list(cls)


ClassificationTypeLiteral: TypeAlias = Literal['manual', 'machine']


class ImageCorrectionType(Enum):
    LAYOUT_MATCHING = 'layout_matching'
    IMAGE_CORRECTION = 'image_correction'
    MANUAL = 'manual'


ImageCorrectionTypeLiteral: TypeAlias = Literal['layout_matching', 'image_correction', 'manual']


class ImageCorrectionMobileResult(Enum):
    PREDICTED = 'PREDICTED_TRANSFORM'
    THRESHOLDED = 'THRESHOLDED_AS_SCANNED'
    NO_CONSENSUS = 'NO_VANISHING_POINT_CONSENSUS'
    FEW_PIXELS = 'TOO_FEW_DOCUMENT_PIXELS'


ImageCorrectionMobileResultLiteral: TypeAlias = Literal[
    'PREDICTED_TRANSFORM',
    'THRESHOLDED_AS_SCANNED',
    'NO_VANISHING_POINT_CONSENSUS',
    'TOO_FEW_DOCUMENT_PIXELS',
]
