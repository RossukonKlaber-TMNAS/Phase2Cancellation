from dataclasses import dataclass
from uuid import UUID


@dataclass(kw_only=True)
class FilePageOrigin:
    """
    Represents the origin of a page when detailed file information is available.
    """

    file_uuid: UUID
    """
    Unique identifier of the file from which this Page was extracted.
    """

    file_name: str | None = None
    """
    The name of the file from which this Page was extracted. Available in v43.1 and later.
    """

    sub_file_number: int
    """
    The number of the sub-file from which this Page was extracted. For example, if a ZIP
    file contains three PDFs, the Pages extracted from the first PDF would have
    ``sub_file_number`` 1, the second PDF would have ``sub_file_number`` 2, and the third
    PDF would have ``sub_file_number`` 3.
    """

    file_page_number: int | None
    """
    The page number within the file / sub-file. This value is 1-indexed.
    """

    file_group: str
    """
    The group to which the file belongs.
    """

    intermediate_file_uuid: UUID | None = None
    """
    UUID of the intermediate PDF blob produced when paginating a non-PDF file type (e.g., DOCX,
    HTML). ``None`` for native PDFs and image-only formats. Available in v43.2 and later.
    """


@dataclass(kw_only=True)
class FilenamePageOrigin:
    """
    Represents the origin of a page when the file name is the only available information.
    This situation can occur when the system fails to extract the referenced file.
    """

    file_name: str
    """
    The name of the file from which this Page was extracted.
    """
