from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.pages.constants import (
    ClassificationTypeLiteral,
    ImageCorrectionMobileResultLiteral,
    ImageCorrectionTypeLiteral,
    PageStatusLiteral,
    PageTypeLiteral,
)
from flows_sdk.implementations.idp_v43.contracts.pages.image import (
    ImageCorrectionModelInfo,
    ImageCorrectionPerspectiveTransform,
)
from flows_sdk.implementations.idp_v43.contracts.pages.page_origin import FilePageOrigin
from flows_sdk.implementations.idp_v43.contracts.pages.segments import PageSegments


@dataclass(kw_only=True)
class InternalPage:
    submission_page_number: int
    """
    Indicates page order for the Submission.
    """

    status: PageStatusLiteral
    """
    Current status of the Page.
    """

    page_type: PageTypeLiteral | str
    """
    The type of the Page.
    """

    origin: FilePageOrigin
    """
    The origin of the Page, which can be used to determine from which submitted file the
    Page was extracted.
    """

    classification_type: ClassificationTypeLiteral | None = None
    """
    The method by which the Page was classified, if applicable. Present when the ``page_type``
    is not 'unknown_page' or 'unassigned_page'.
    """

    machine_layout_page_uuid: UUID | None = None
    """
    Unique identifier of the layout page that the machine predicted this Page matches to, if
    applicable.
    """

    manual_layout_page_uuid: UUID | None = None
    """
    Unique identifier of the layout page that a keyer assigned this Page to, if applicable.
    """

    combined_segments: PageSegments | None = None
    """
    The segments for the Page, if applicable.
    """

    image_uuid: UUID
    """
    Unique identifier of the image for this Page. Refers to the original image as extracted from
    the source file before any transformations were applied.
    """

    image_name: str
    """
    The name of the original image file for this Page.
    """

    image_width: int
    """
    The width of the original image for this Page in pixels.
    """

    image_height: int
    """
    The height of the original image for this Page in pixels.
    """

    image_checksum: str
    """
    The checksum of the original image for this Page.
    """

    corrected_image_uuid: UUID | None = None
    """
    Unique identifier of the corrected image for this Page, if applicable. Refers to the image
    after transformations such as rotation or perspective correction were applied.
    """

    image_correction_type: ImageCorrectionTypeLiteral | None = None
    """
    The type of image correction applied to this Page, if applicable. Available in v43.1 and later.
    """

    transformation_matrix: list[list[float]] | None = None
    """
    The 3x3 registration homography matrix for the Page, if applicable.
    """

    template_image_shapes: list[list[int]] | None = None
    """
    Registration shape metadata for the layout image, if applicable. Contains the
    pre-computed layout shape and the original layout image shape.
    """

    submission_image_shape: list[int] | None = None
    """
    Registration pre-processing shape of the submission image, if applicable.
    """

    correction_model_info: ImageCorrectionModelInfo | None = None
    """
    Model version metadata for image correction on this Page, if applicable.
    """

    rotation_confidence: float | None = None
    """
    The confidence score for the applied rotation correction for the Page, if applicable. Ranges
    from 0.0 to 1.0, or ``None`` if not applicable.
    """

    rotation_class: int | None = None
    """
    The applied rotation-correction class for the Page, if applicable. Values are ``0``, ``1``,
    ``2``, or ``3``, representing the number of 90-degree counterclockwise rotations applied, or
    ``None`` if not applicable.
    """

    deskew_confidence: float | None = None
    """
    The confidence score for the applied deskew correction for the Page, if applicable. Ranges
    from 0.0 to 1.0, or ``None`` if not applicable.
    """

    skew_angle: float | None = None
    """
    The applied deskew-correction angle for the Page in degrees, if applicable. This value
    represents the rotation applied to deskew the image (it may be 0 when no deskew is needed),
    or ``None`` if not applicable.
    """

    mobile_correction_result: ImageCorrectionMobileResultLiteral | None = None
    """
    Outcome of mobile perspective correction for this Page, if applicable. Indicates whether a
    perspective transform was applied or why it was not, or ``None`` if not applicable.
    """

    applied_transform: ImageCorrectionPerspectiveTransform | None = None
    """
    Applied mobile perspective transform for this Page, if applicable.
    """

    exceptions: list[str]
    """
    List of exceptions encountered during processing.
    """


@dataclass(kw_only=True)
class Page(InternalPage):
    """
    The Page object is the representation of a single image that was submitted into the system.
    """

    id: int
    """
    Unique system-generated identifier.
    """
