from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.pages.constants import (
    PageStatusLiteral,
    PageTypeLiteral,
)
from flows_sdk.implementations.idp_v43.contracts.pages.page_origin import (
    FilenamePageOrigin,
    FilePageOrigin,
)


@dataclass(kw_only=True)
class InternalFailedPage:
    submission_page_number: int
    """
    Indicates page order for the Submission.
    """

    status: PageStatusLiteral
    """
    Current status of the Page. For failed pages, this property will be set to ``failed``.
    """

    page_type: PageTypeLiteral
    """
    The type of the Page, which can be used to determine how the system attempted to process
    the Page before it failed.
    """

    image_uuid: UUID | None
    """
    Unique identifier of the image for this Page, if available. Refers to the original image as
    extracted from the source file before any transformations were applied.
    """

    image_name: str | None
    """
    The name of the original image file for this Page, if available.
    """

    image_width: int
    """
    The width of the original image for this Page in pixels, if available.
    """

    image_height: int
    """
    The height of the original image for this Page in pixels, if available.
    """

    image_checksum: str | None
    """
    The checksum of the original image for this Page, if available.
    """

    origin: FilePageOrigin | FilenamePageOrigin
    """
    The origin of the Page, which can be used to determine from which submitted file the
    Page was extracted.
    """

    exceptions: list[str]
    """
    List of exceptions encountered during processing that led to the failure of this Page.
    """


@dataclass(kw_only=True)
class FailedPage(InternalFailedPage):
    """
    A FailedPage object represents a Page that failed processing during the execution of a Flow.
    """

    id: int
    """
    Unique system-generated identifier.
    """
