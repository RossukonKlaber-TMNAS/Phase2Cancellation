from enum import Enum
from typing import Literal, TypeAlias


class MlModel(Enum):
    CHECKBOX = 'checkbox'
    SIGNATURE = 'signature'
    ENTRY = 'entry'
    BARCODE = 'barcode'


MlModelLiteral: TypeAlias = Literal['checkbox', 'signature', 'entry', 'barcode']


class EntryType(Enum):
    BUILTIN = 1
    PATTERN = 2
    LIST = 3


EntryTypeLiteral: TypeAlias = Literal[1, 2, 3]


class LayoutKind(Enum):
    STRUCTURED = 'structured'
    SEMISTRUCTURED = 'semi_structured'
    ADDITIONAL = 'additional'


LayoutKindLiteral: TypeAlias = Literal['structured', 'semi_structured', 'additional']


class DocumentStatus(Enum):
    PROCESSING = 'processing'
    REPROCESS = 'reprocess'
    REPROCESSING = 'reprocessing'
    REJECTED = 'rejected'
    COMPLETE = 'complete'


DocumentStatusLiteral: TypeAlias = Literal[
    'processing', 'reprocess', 'reprocessing', 'rejected', 'complete'
]
