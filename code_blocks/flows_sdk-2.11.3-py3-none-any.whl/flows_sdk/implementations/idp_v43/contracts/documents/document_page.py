from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.pages.constants import ClassificationTypeLiteral
from flows_sdk.implementations.idp_v43.contracts.pages.page import InternalPage


@dataclass(kw_only=True)
class InternalDocumentPage(InternalPage):
    document_page_number: int
    """
    Indicates page order for the Document.
    """

    classification_type: ClassificationTypeLiteral
    """
    The method by which the Page was classified.
    """

    layout_page_uuid: UUID | None = None
    """
    Unique identifier of the layout page that this Page was matched to, if applicable.
    """

    layout_image_uuid: UUID | None = None
    """
    Unique identifier of the layout image that this Page was matched to, if applicable.
    """


@dataclass(kw_only=True)
class DocumentPage(InternalDocumentPage):
    """
    Represents a page within a document.
    """

    id: int
    """
    Unique system-generated identifier of the original Page object.
    """

    document_page_id: int
    """
    Unique system-generated identifier.
    """
