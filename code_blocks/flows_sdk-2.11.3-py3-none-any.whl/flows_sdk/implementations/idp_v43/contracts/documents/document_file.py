from dataclasses import dataclass
from uuid import UUID


@dataclass(kw_only=True)
class DocumentFilePage:
    """
    Metadata for one rendered page in a DocumentFile.

    Includes the source page image identifier and the rendered page size in millimeters.
    """

    image_uuid: UUID
    """
    UUID of the source image used for this rendered page.
    """

    width_in_mm: float | None
    """
    Rendered page width in millimeters.
    """

    height_in_mm: float | None
    """
    Rendered page height in millimeters.
    """


@dataclass(kw_only=True)
class DocumentFile:
    """
    Metadata for a printable file rendered from a document's page images.
    """

    document_uuid: UUID
    """
    UUID of the source Document this printable file was rendered for.
    """

    uuid: UUID
    """
    UUID of the stored rendered file.
    """

    checksum: str
    """
    Checksum of the stored rendered file.
    """

    mime_type: str
    """
    MIME type of the rendered file (e.g., ``application/pdf``).
    """

    height_in_mm: float
    """
    The maximum page height across all rendered pages in millimeters.
    """

    width_in_mm: float
    """
    The maximum page width across all rendered pages in millimeters.
    """

    quality: int
    """
    Rendering quality used when generating the printable file.
    """

    mode: str
    """
    Color mode used during rendering (e.g., ``RGB``, ``GRAYSCALE``, or ``BW``).
    """

    download_url: str
    """
    API URL for downloading the rendered file.
    """

    page_dimensions: list[DocumentFilePage]
    """
    Per-page rendered metadata listed in the same order as pages in the output file.
    """
