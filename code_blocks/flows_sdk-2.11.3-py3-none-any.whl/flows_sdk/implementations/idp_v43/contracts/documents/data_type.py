from dataclasses import dataclass
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.documents.constants import (
    EntryTypeLiteral,
    MlModelLiteral,
)


@dataclass(kw_only=True)
class DataType:
    """
    Provides means for configuring the data-extraction and normalization processes.
    """

    uuid: UUID
    """
    Unique system-generated identifier.
    """

    entry_type: EntryTypeLiteral
    """
    Represents the method by which the data is extracted. Possible values are:

        * ``1`` (builtin) - extraction using a built-in model.
        * ``2`` (pattern) - extraction using a regex pattern.
        * ``3`` (list) - extraction by matching against a list of accepted values.
    """

    ml_model: MlModelLiteral
    """
    Top-level category of the DataType.
    """

    meta_type: str | None
    """
    Sub-category of the DataType. For example, for an ``entry`` DataType, the ``meta_type`` could be
    ``date``, ``address``, etc.
    """

    pattern: str | None
    """
    A regex pattern used for extracting data when ``entry_type`` is ``pattern``.
    """

    normalization_strip_charset: str | None
    """
    A string of characters to be removed from the extracted value during normalization.
    """

    normalization_map: dict[str, str] | None
    """
    A mapping of values to their normalized forms. Used during normalization to convert extracted
    values to a standard format.
    """

    accepted_values: list[str] | None
    """
    A list of values that are considered valid for this DataType. Used when ``entry_type`` is
    ``list``.
    """

    raw_results: bool | None
    """
    Indicates whether the raw extracted results should be returned without normalization.
    """
