from dataclasses import dataclass
from datetime import datetime
from typing import Any
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.documents.constants import (
    DocumentStatusLiteral,
    LayoutKindLiteral,
)
from flows_sdk.implementations.idp_v43.contracts.documents.data_type import DataType
from flows_sdk.implementations.idp_v43.contracts.documents.document_file import DocumentFile
from flows_sdk.implementations.idp_v43.contracts.documents.document_page import (
    DocumentPage,
    InternalDocumentPage,
)
from flows_sdk.implementations.idp_v43.contracts.documents.segments import FragmentedSegments
from flows_sdk.implementations.idp_v43.contracts.fields.field import Field, InternalField
from flows_sdk.implementations.idp_v43.contracts.tables.table import InternalTable, Table


@dataclass(kw_only=True)
class InternalDocument:
    uuid: UUID
    """
    Unique system-generated identifier.
    """

    status: DocumentStatusLiteral
    """
    Current status of the Document.
    """

    complete_time: datetime | None = None
    """
    Time the entire Document entered the Complete state, including all of its Supervision tasks.
    """

    layout_uuid: UUID
    """
    The unique identifier of the layout that this Document was matched to.
    """

    layout_name: str
    """
    The name of the layout that this Document was matched to.
    """

    layout_language: str
    """
    The language of the layout that this Document was matched to.
    """

    layout_kind: LayoutKindLiteral
    """
    The kind of the layout that this Document was matched to.
    """

    layout_tags: list[str]
    """
    The list of tags associated with the layout that this Document was matched to.
    """

    layout_version_uuid: UUID
    """
    The unique identifier of the specific layout version that this Document was matched to.
    """

    original_layout_version_uuid: UUID
    """
    The unique identifier of the original layout version that this Document was matched to.
    Used to map partially matched Documents to a specific layout version.
    """

    classified_by_user_id: int
    """
    The unique identifier of the user who classified this Document.
    ``-1`` if classified by an automated process.
    """

    needs_flexible_extraction_review: bool
    """
    Indicates whether the Document requires Flexible Extraction Supervision.
    """

    pages: list[InternalDocumentPage]
    """
    Array of Page objects included in this Document.
    """

    document_fields: list[InternalField] | None = None
    """
    Array of Field objects identified as being part of this Document.
    """

    tables: list[InternalTable] | None = None
    """
    Array of Table objects identified as being part of this Document.
    """

    data_types: list[DataType]
    """
    Array of DataType objects identified as being part of this Document.
    """

    processed_segments: list[FragmentedSegments] | None = None
    """
    Array of FragmentedSegments objects representing the segments that have been extracted for this
    Document.
    """

    document_file: DocumentFile | None = None
    """
    The printable file rendered from the Document's page images, if applicable.
    """

    metadata: dict[str, Any]
    """
    A dictionary to store any additional metadata related to the Document.
    """

    exceptions: list[str]
    """
    List of exceptions encountered during processing.
    """


@dataclass(kw_only=True)
class Document(InternalDocument):
    """
    The Document object is a set of pages that have matched to a pre-defined layout.
    """

    id: int
    """
    Unique system-generated identifier.
    """

    pages: list[DocumentPage]  # type: ignore[assignment]

    document_fields: list[Field] | None = None  # type: ignore[assignment]

    tables: list[Table] | None = None  # type: ignore[assignment]
