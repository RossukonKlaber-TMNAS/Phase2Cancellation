from dataclasses import dataclass
from uuid import UUID


@dataclass(kw_only=True)
class FragmentedSegments:
    """
    Metadata for a stored artifact that contains fragmented segments from a document.

    Each instance represents one derived segment set produced from the document's original
    segments using a particular splitting configuration.
    """

    uuid: UUID
    """
    Unique identifier of the stored fragmented segments.
    """

    flex_model_type: str
    """
    Specifies the splitting strategy used to derive these fragmented segments from the original
    segments.
    """

    custom_split_char: str | None
    """
    Optional custom split-character configuration used when these fragmented segments were derived.
    """
