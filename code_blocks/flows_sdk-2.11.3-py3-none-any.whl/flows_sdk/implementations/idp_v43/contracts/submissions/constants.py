from enum import Enum
from typing import Literal, TypeAlias


class SubmissionStatus(Enum):
    PROCESSING = 'processing'
    COMPLETE = 'complete'
    REPROCESSING = 'reprocessing'


SubmissionStatusLiteral: TypeAlias = Literal['processing', 'complete', 'reprocessing']
