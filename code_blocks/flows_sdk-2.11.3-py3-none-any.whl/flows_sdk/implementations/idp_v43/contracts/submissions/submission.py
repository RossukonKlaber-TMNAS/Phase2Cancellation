from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

from flows_sdk.implementations.idp_v43.contracts.cases.case import Case
from flows_sdk.implementations.idp_v43.contracts.documents.document import (
    Document,
    InternalDocument,
)
from flows_sdk.implementations.idp_v43.contracts.pages.failed_page import (
    FailedPage,
    InternalFailedPage,
)
from flows_sdk.implementations.idp_v43.contracts.pages.page import InternalPage, Page
from flows_sdk.implementations.idp_v43.contracts.submissions.constants import (
    SubmissionStatusLiteral,
)


@dataclass(kw_only=True)
class InternalSubmission:
    flow_uuid: UUID
    """
    The UUID of the Flow that created this Submission.
    """

    flow_name: str
    """
    The name of the Flow that created this Submission.
    """

    flow_version: int
    """
    The version of the Flow that created this Submission.
    """

    status: SubmissionStatusLiteral
    """
    Current status of the Submission.
    """

    complete_time: datetime | None = None
    """
    Time the entire Submission entered the Complete state, including all of its Supervision tasks.
    """

    classification_review_needed: bool | None = None
    """
    Indicates whether Classification Supervision is needed for this Submission.
    """

    documents: list[InternalDocument] | None = None
    """
    Array of Document objects identified as being part of this Submission.
    """

    unassigned_pages: list[InternalPage]
    """
    Array of Page objects included in this Submission that have not been grouped into a
    Document.
    """

    failed_pages: list[InternalFailedPage]
    """
    Array of Page objects included in this Submission that failed processing.
    """


@dataclass(kw_only=True)
class Submission(InternalSubmission):
    """
    A Submission object is created when a set of files are submitted into the system together.
    The system then interprets each file as a one or more Page objects.
    """

    id: int
    """
    Unique system-generated identifier.
    """

    documents: list[Document] | None = None  # type: ignore[assignment]

    unassigned_pages: list[Page]  # type: ignore[assignment]

    failed_pages: list[FailedPage]  # type: ignore[assignment]

    cases: list[Case] | None = None
    """
    Array of Case objects that contain Documents and Pages from this Submission.
    """
