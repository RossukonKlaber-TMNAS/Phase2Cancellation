from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.additional_blocks.address_parsing.settings import (
    AddressParserSettings,
)
from flows_sdk.implementations.idp_v43.idp_blocks.flexible_extraction.settings import (
    FlexibleExtractionSettings as Settings,
)
from flows_sdk.utils import workflow_input


class FlexibleExtractionBlock(Block):
    """Flexible extraction manually transcribes fields marked for review

    Mandatory parameters:

    :param submission: Submission object
    :param api_params:

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param supervision_transcription_masking: Prevents users from inputting invalid
        characters during the Flexible Extraction task,
        defaults to workflow_input(Settings.FlexibleExtractionSupervisionTranscriptionMasking)
    :param task_restrictions: Defines what users can access Supervision tasks created
        by this block,
        defaults to workflow_input(Settings.FlexibleExtractionTaskRestrictions)
    :param notification_workflow: Notification flow name to run when the submission
        enters Flexible Extraction,
        defaults to workflow_input(Settings.FlexibleExtractionNotificationWorkflow)
    :param show_machine_predictions: Available from V42.3; Shows the machine predictions in the
        Flexible Extraction Supervision tasks,
        defaults to workflow_input(Settings.FlexibleExtractionShowMachinePredictions)
    :param searchable_pages: Available from V43.2; When enabled, enables searching by text
        segments in the Flexible Extraction Supervision tasks,
        defaults to workflow_input(Settings.FlexibleExtractionSearchablePages)
    :param address_parsing_enabled: Available from V43.2; toggles AddressParser invocation on
        flexibly-extracted address fields,
        defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
    :param address_parser_api_provider: Available from V43.2; selects the address parsing
        provider ('none' / 'google' / 'smarty' / 'geoapify'),
        defaults to workflow_input(AddressParserSettings.ApiProvider)
    :param address_parser_api_key: Available from V43.2; API key for the configured provider,
        defaults to workflow_input(AddressParserSettings.ApiKey)
    :param address_parser_api_options: Available from V43.2; provider-specific JSON options,
        defaults to workflow_input(AddressParserSettings.ApiOptions)

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>` with
      the fields marked for review updated with the transcribed values.

    Example usage::

        flexible_extraction = FlexibleExtractionBlock(
            reference_name='flexible_extraction',
            submission=manual_transcription.output('submission'),
            api_params=submission_bootstrap.output('result.api_params'),
            supervision_transcription_masking=(
                idp_wf_config.flexible_extraction_config.supervision_transcription_masking
            ),
            task_restrictions=idp_wf_config.flexible_extraction_config.task_restrictions,
        )
    """

    IDENTIFIER = 'FLEXIBLE_EXTRACTION_5'

    def __init__(
        self,
        submission: Any,
        api_params: Any,
        reference_name: str | None = None,
        supervision_transcription_masking: bool | str | None = workflow_input(
            Settings.FlexibleExtractionSupervisionTranscriptionMasking
        ),
        task_restrictions: list[Any] | str | None = workflow_input(
            Settings.FlexibleExtractionTaskRestrictions
        ),
        notification_workflow: str | None = workflow_input(
            Settings.FlexibleExtractionNotificationWorkflow
        ),
        show_machine_predictions: bool | str | None = workflow_input(
            Settings.FlexibleExtractionShowMachinePredictions
        ),
        searchable_pages: bool | str | None = workflow_input(
            Settings.FlexibleExtractionSearchablePages
        ),
        address_parsing_enabled: str | bool = workflow_input(
            AddressParserSettings.AddressParsingEnabled
        ),
        address_parser_api_provider: str = workflow_input(AddressParserSettings.ApiProvider),
        address_parser_api_key: str | None = workflow_input(AddressParserSettings.ApiKey),
        address_parser_api_options: str | dict | None = workflow_input(
            AddressParserSettings.ApiOptions
        ),
    ) -> None:
        if not task_restrictions:
            task_restrictions = []

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'api_params': api_params,
                'submission': submission,
                'task_restrictions': task_restrictions,
                'supervision_transcription_masking': supervision_transcription_masking,
                'notification_workflow': notification_workflow,
                'show_machine_predictions': show_machine_predictions,
                'searchable_pages': searchable_pages,
                AddressParserSettings.AddressParsingEnabled: address_parsing_enabled,
                AddressParserSettings.ApiProvider: address_parser_api_provider,
                AddressParserSettings.ApiKey: address_parser_api_key,
                AddressParserSettings.ApiOptions: address_parser_api_options,
            },
            title='Flexible Extraction',
            description='Manually transcribe fields marked for review',
        )
