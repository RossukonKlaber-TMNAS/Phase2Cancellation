from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v43.additional_blocks.common_settings import (
    ORCA_ENABLED_DEPENDENCIES,
    OrcaSettings,
    get_orca_base_model_uuid_param,
)
from flows_sdk.implementations.idp_v43.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v43.idp_blocks.defaults import EXACT_PERCENT_SCHEMA

ORCA_SLIDING_WINDOW_SIZE = 10
ORCA_MAX_NEW_TOKENS = 1024
ORCA_MAX_IMAGE_TOKENS = 1280
ORCA_MAX_BOUNDING_BOXES = 3


class OrcaExtractionSettings(OrcaSettings, BaseInputs):
    OrcaUseLiveModel = 'orca_use_live_model'
    OrcaBaseModelUUID = 'orca_base_model_uuid'
    OrcaTargetAccuracy = 'orca_target_accuracy'
    OrcaSlidingWindowSize = 'orca_sliding_window_size'
    OrcaMaxNewTokens = 'orca_max_new_tokens'
    OrcaMaxImageTokens = 'orca_max_image_tokens'
    OrcaMaxNumBBoxes = 'orca_max_num_bboxes'

    @classmethod
    def create(  # type: ignore[override]
        cls,
        orca_use_live_model: bool | str | None,
        orca_type: str,
        base_model_uuid: str | None,
        target_accuracy: float,
        sliding_window_size: int,
        max_new_tokens: int,
        max_image_tokens: int,
        max_num_bboxes: int,
    ) -> dict[str, Any]:
        return {
            **OrcaSettings.create(orca_type),
            cls.OrcaUseLiveModel: orca_use_live_model,
            cls.OrcaBaseModelUUID: base_model_uuid,
            cls.OrcaTargetAccuracy: target_accuracy,
            cls.OrcaSlidingWindowSize: sliding_window_size,
            cls.OrcaMaxNewTokens: max_new_tokens,
            cls.OrcaMaxImageTokens: max_image_tokens,
            cls.OrcaMaxNumBBoxes: max_num_bboxes,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.OrcaUseLiveModel,
                type='boolean',
                title='Use Live Model',
                description=(
                    'When enabled, the system uses the live model for the corresponding model'
                    ' definition in TDM for VLM extraction. If no live model is available, running'
                    ' the flow returns a runtime error.'
                ),
                value=False,
                optional=True,
                dependencies=ORCA_ENABLED_DEPENDENCIES,
            ),
            get_orca_base_model_uuid_param(
                cls.OrcaBaseModelUUID,
                description=(
                    'Select the base model to use. If a live specialized model is available for the'
                    ' selected base model, the system uses it automatically.'
                ),
                additional_dependencies=[
                    Dependency(
                        condition={'properties': {cls.OrcaUseLiveModel: {'const': True}}},
                        override={
                            'ui': {'hide_and_retain': True},
                            'optional': True,
                            'type': 'string',
                        },
                    ),
                ],
            ),
            Parameter(
                name=cls.OrcaTargetAccuracy,
                type='Percentage',
                schema=EXACT_PERCENT_SCHEMA,
                title='ORCA Target Accuracy',
                ui={
                    'warning': 'Target accuracy is applied only after a specialized model '
                    'definition has been created from the base model.'
                },
                value=0.95,
                dependencies=ORCA_ENABLED_DEPENDENCIES,
            ),
            Parameter(
                name=cls.OrcaSlidingWindowSize,
                type='integer',
                title='Sliding Window Size',
                description='The number of pages processed by the model at once. '
                'Larger values improve throughput but raise GPU memory usage.',
                value=ORCA_SLIDING_WINDOW_SIZE,
                ui={'hidden': True},
                dependencies=ORCA_ENABLED_DEPENDENCIES,
            ),
            Parameter(
                name=cls.OrcaMaxNewTokens,
                type='integer',
                title='Max New Tokens',
                description='The maximum number of tokens the model can extract, which '
                'should be scaled based on the number and length of field values.',
                value=ORCA_MAX_NEW_TOKENS,
                ui={'hidden': True},
                dependencies=ORCA_ENABLED_DEPENDENCIES,
            ),
            Parameter(
                name=cls.OrcaMaxImageTokens,
                type='integer',
                title='Max Image Tokens',
                description=(
                    'The maximum number of tokens allocated per image by the model. '
                    'This is conceptually similar to setting image resolution. '
                    'Larger values may increase accuracy on dense / '
                    'hard to read images but will raise GPU memory usage.'
                ),
                value=ORCA_MAX_IMAGE_TOKENS,
                ui={'hidden': True},
                dependencies=ORCA_ENABLED_DEPENDENCIES,
            ),
            Parameter(
                name=cls.OrcaMaxNumBBoxes,
                type='integer',
                title='Max Number of Bounding Boxes',
                description=(
                    'The maximum number of candidate bounding boxes per field occurrence. '
                    'Larger values may improve the likelihood of identifying the correct location '
                    'but may also increase false positives.'
                ),
                value=ORCA_MAX_BOUNDING_BOXES,
                ui={'hidden': True},
                dependencies=ORCA_ENABLED_DEPENDENCIES,
            ),
        ]
