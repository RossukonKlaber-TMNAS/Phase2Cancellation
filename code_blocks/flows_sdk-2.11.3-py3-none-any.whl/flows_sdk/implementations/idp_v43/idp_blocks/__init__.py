from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from flows_sdk.blocks import Block, IOBlock, Outputs
from flows_sdk.implementations.idp_v43.additional_blocks.address_parsing.settings import (
    AddressParserSettings,
)
from flows_sdk.implementations.idp_v43.idp_blocks.all_settings import Settings
from flows_sdk.implementations.idp_v43.idp_blocks.defaults import (
    DEFAULT_IDP_CORE_IDENTIFIER,
    DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER,
    IDP_CORE_FLOW_ROLE,
    IDP_OUTPUT_ROLE,
)
from flows_sdk.implementations.idp_v43.idp_blocks.document_renderer import DocumentRendererBlock
from flows_sdk.implementations.idp_v43.idp_blocks.flexible_extraction import FlexibleExtractionBlock
from flows_sdk.implementations.idp_v43.idp_blocks.flow_inputs import IdpFlowInputs
from flows_sdk.implementations.idp_v43.idp_blocks.machine_classification import (
    MachineClassificationBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.machine_collation import MachineCollationBlock
from flows_sdk.implementations.idp_v43.idp_blocks.machine_identification import (
    MachineIdentificationBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.machine_transcription import (
    MachineTranscriptionBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.manual_classification import (
    ManualClassificationBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.manual_identification import (
    ManualIdentificationBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.manual_transcription import (
    ManualTranscriptionBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.orca_extraction import (
    OpticalReasoningCognitionAgentBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.reprocessing import ReprocessingBlock
from flows_sdk.implementations.idp_v43.idp_blocks.submission_bootstrap import (
    SubmissionBootstrapBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.submission_complete import SubmissionCompleteBlock
from flows_sdk.types import CompatibilitySpec
from flows_sdk.utils import workflow_input

if TYPE_CHECKING:
    from flows_sdk.implementations.idp_v43.idp_values import IdpWorkflowConfig

__all__ = [
    'IDPCoreBlock',
    'SubmissionBootstrapBlock',
    'MachineCollationBlock',
    'MachineClassificationBlock',
    'ManualClassificationBlock',
    'MachineIdentificationBlock',
    'ManualIdentificationBlock',
    'MachineTranscriptionBlock',
    'ManualTranscriptionBlock',
    'FlexibleExtractionBlock',
    'ReprocessingBlock',
    'SubmissionCompleteBlock',
    'SetTransformedOutputBlock',
    'IDPOutputsBlock',
    'IdpCustomSupervisionBlock',
    'IDPFullPageTranscriptionBlock',
    'DocumentRendererBlock',
    'IDPImageCorrectionBlock',
    'OpticalReasoningCognitionAgentBlock',
]


class IDPCoreBlock(Block):
    """IDP core block includes the steps to process the passed documents into machine-readable
    output.

    Mandatory parameters:

    :parameter idp_wf_config: IdpWorkflowConfig object with all flow-level configuration settings
        for IDP

    Parameters with defaults:

    :param reference_name: unique reference name within a flow, a unique one will be generated when
        not provided
    :param compatibility_spec: defines a filter for flows that could be selected in the UI in place
        of "IDP Core" for the block. Defaults to flows with the role 'idp_core'. The user will be
        able to pick any flow that matches the compatibility_spec. This serves to make upgrading
        to a new compatible version of "IDP Core" (e.g. IDP_CORE_V39) easier in future releases.
    :param identifier: The identifier of the flow. Defaults to the IDP_CORE_VXX identifier of the
        out-of-the-box flow that comes with the system.
    :param additional_inputs: Dictionary containing key-value pairs that will be added to the
        inputs of the block. If a key is contained in the default inputs, its value will be
        overwritten by the value provided here. You generally do not need to provide
        additional_inputs, unless you are creating a custom derivative of the IDP_CODE_Vxx flow
        and are modifying or extending the list of inputs it accepts.

    Example usage::

        idp_core = IDPCoreBlock(idp_wf_config=idp_wf_config)
    """

    # REFERENCE_NAME should be "__idp_core__" to preserve core platform functionality
    # related to layouts and releases that looks for this specific name.
    # Do not change it even if you are creating custom versions of IDPCoreBlock.
    REFERENCE_NAME = '__idp_core__'

    def __init__(
        self,
        idp_wf_config: 'IdpWorkflowConfig',
        reference_name: str | None = REFERENCE_NAME,
        title: str = 'Start Document Processing Subflow',
        description: str = 'Calls the Document Processing Subflow with the specified settings.',
        compatibility_spec: CompatibilitySpec | None = CompatibilitySpec(
            filter_roles=[IDP_CORE_FLOW_ROLE]
        ),
        identifier: str = DEFAULT_IDP_CORE_IDENTIFIER,
        additional_inputs: dict[str, Any] | None = None,
    ) -> None:
        from flows_sdk.implementations.idp_v43.idp_values import get_idp_wf_inputs  # noqa

        if not additional_inputs:
            additional_inputs = {}
        default_inputs = get_idp_wf_inputs(idp_wf_config)

        super().__init__(
            identifier=identifier,
            reference_name=reference_name,
            title=title,
            description=description,
            input={
                **default_inputs,
                **additional_inputs,
                IdpFlowInputs.Trigger: workflow_input(IdpFlowInputs.Trigger),
            },
            compatibility_spec=compatibility_spec,
        )


class SetTransformedOutputBlock(Block):
    """
    Set Transformed Output block sets the transformed output for the provided submission. This can
    later be used to send the transformed data downstream using output blocks. For more information
    see https://docs.hyperscience.ai/#retrieving-transformed-submissions.

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>`
        object
    :param transformed_output: Object that will be set as the transformed output for this submission

    Output:
    The block returns an object with the following keys:

    * `submission_id`: identifier of the submission for which the transformed output was set
    """

    IDENTIFIER = 'SET_TRANSFORMED_OUTPUT'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        transformed_output: dict[str, Any] | str,
        reference_name: str | None = None,
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={'submission': submission, 'transformed_output': transformed_output},
            title='Set Transformed Output',
            description='Sets the transformed output for the provided submission',
        )


class IDPOutputsBlock(Outputs):
    """Output block allows users to send data extracted by an IDP flow to other systems
    for downstream processing

    Mandatory parameters:

    :param inputs: Used by the UI to automatically pre-populate the input of
        newly added blocks. Extended in this class to include ``'enabled': True``
        to visualize an enabled/disabled trigger that is controllable via Flow Studio.

    Usage when parameters are to be defined in Flow Studio::

        outputs = IDPOutputBlock(
            inputs={'submission': submission_bootstrap.output('result.submission')}
        )
    """

    def __init__(self, inputs: dict[str, Any], blocks: Sequence[IOBlock] | None = None) -> None:
        if not blocks:
            blocks = []

        super().__init__(
            reference_name='outputs',
            title='Outputs',
            description='Send submission data to external systems',
            role_filter=[IDP_OUTPUT_ROLE],
            input_template={**inputs, 'enabled': True},
            blocks=blocks,
        )


class IdpCustomSupervisionBlock(Block):
    """An IDP wrapper for the Custom Supervision block. It has the same functionality,
    but handles reading/writing data from the IDP database.

    Mandatory parameters:

    :param submission: Workflow Submission object from upstream IDP Blocks.
    :param task_purpose: The custom task name that's given to all supervision tasks that run
        through a particular instance of a custom supervision block. This can be used to filter
        tasks in the task queue.
    :param supervision_template: JSON used for configuration of the Custom Supervision Task.

    Parameters with defaults:

    :param data: Optional JSON structure that extends the data used to populate the
        supervision_template. This is intended to append to the data already gathered by the IDP
        wrapper. If there are any conflicting keys, the keys in this input will take precedent.
    :param reference_name: Unique identifier within a flow. A unique one will be generated when
        not provided.
    :param supervision_transcription_masking: Prevents users from inputting invalid
        characters during the Custom Supervision task. Defaults to True.
    :param task_restrictions: Defines what users can access Supervision tasks created
        by this block. Defaults to [].
    :param page_ids: If left empty, the IDP wrapper will, by default, pull in all pages
        in the submission. Adding a list of page IDs will override the default list of pages.
        Defaults to [].
    :param notification_workflow: Notification flow name to run when the submission
        enters Custom Supervision. Defaults to IDP_SUBMISSION_NOTIFY_NAME.
    :param chat_flow_identifier: Available from V41.2; optional chat flow identifier to enable
        Document Chat.
    :param title: UI-visible title of the block. Defaults to 'IDP Custom Supervision'.
    :type title: Optional[str]
    :param description: Description of the block. Useful for documentation and shown in Flow Studio.
        Defaults to 'IDP Custom Supervision'.
    :type description: Optional[str]

    Example usage::

        idp_custom_supervision = IdpCustomSupervisionBlock(
            reference_name='idp_custom_supervision',
            submission=manual_transcription.output('submission'),
            task_purpose='make_custom_decision',
            supervision_template=[
                {
                    'name': 'three_column_template',
                    'version': '1.0',
                    'thumbnail': {
                        'group_by_document': True,
                        'group_by_case': True,
                    },
                    'action': [
                        {
                            'name': 'my_tab',
                            'display': 'SSN Info',
                            'input': [
                                {
                                    'name': 'ssn_field',
                                    'type': 'transcription',
                                    'data_identifier': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                                    'title': 'SSN',
                                },
                            ],
                            'ui': {
                                'groups': [
                                    {
                                        'title': 'My Group',
                                        'fields': ['ssn_field'],
                                    },
                                ],
                            },
                        },
                    ],
                },
            ],
            data={
                'documents': [
                    {
                        'id': 2,
                        'layout_uuid': 'e31c3cbf-dcea-44fd-a052-902463c6040f',
                        'layout_name': 'layout_name',
                        'page_count': 2,
                        'read_only': False,
                    }
                ]
            },
            supervision_transcription_masking=False,
        )
    """

    IDENTIFIER = 'IDP_CUSTOM_SUPERVISION_4'

    def __init__(
        self,
        submission: Any,
        task_purpose: str,
        supervision_template: Any,
        data: dict[str, Any] | None = None,
        reference_name: str | None = None,
        supervision_transcription_masking: str | bool = True,
        task_restrictions: str | list[Any] | None = None,
        page_ids: str | list[int] | None = None,
        notification_workflow: str = DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER,
        chat_flow_identifier: str | None = None,
        title: str | None = 'IDP Custom Supervision',
        description: str | None = 'IDP Custom Supervision',
    ) -> None:
        if not task_restrictions:
            task_restrictions = []
        if not page_ids:
            page_ids = []
        if not data:
            data = {}

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'supervision_template': supervision_template,
                'data': data,
                'task_purpose': task_purpose,
                'submission': submission,
                'task_restrictions': task_restrictions,
                'supervision_transcription_masking': supervision_transcription_masking,
                'page_ids': page_ids,
                'notification_workflow': notification_workflow,
                'chat_flow_identifier': chat_flow_identifier,
            },
            title=title,
            description=description,
        )


class IDPFullPageTranscriptionBlock(Block):
    """
    IDP Full Page Transcription Block machine-transcribes the pages contained in a submission.

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>`
        object that includes the pages that need to be transcribed

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param app_metadata: used for capturing information about the flow
    :param language_family: language family to use when instantiating the underlying transcription
        model. If not provided, the system will default to `latin`. Language families are single
        word lowercase strings, e.g., `latin`, `arabic`, `korean`, `chinese`.
        You can read more about language families in the
        "Supported Languages" article in the application documentation:
        https://help.hyperscience.ai/v43/docs/supported-languages.
    :param rerun_segmentation: Available from V42.3; controls whether segmentation should be
        rerun for already segmented pages.

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>` with
      the `combined_segments` field populated on its pages with the transcription results.

    Example usage::

        # This is one way to obtain the submission object (using SubmissionBootstrapBlock)
        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

        idp_fpt_block = IDPFullPageTranscriptionBlock(
            reference_name='idp_fpt',
            submission=submission_bootstrap.output('submission'),
        )

        # reference to the output of IDPFullPageTranscriptionBlock which can be passed as input to
        # the next block. For more information on output() and output references, please take a
        # look at class Block and its output() method
        output_ref = idp_fpt_block.output()
    """

    IDENTIFIER = 'FULL_PAGE_TRANSCRIPTION_SUBMISSION_3'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        reference_name: str | None = None,
        title: str = 'Full Page Transcription (Submission)',
        description: str = 'Transcribes the documents included in a submission',
        app_metadata: list[str] | None = None,
        language_family: str | None = None,
        rerun_segmentation: bool = False,
    ) -> None:
        inputs: dict[Any, Any] = {
            'submission': submission,
            'language_family': language_family,
            'rerun_segmentation': rerun_segmentation,
        }
        if app_metadata is not None:
            inputs['app_metadata'] = app_metadata

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


class IDPImageCorrectionBlock(Block):
    """
    IDP Image Correction Block rotates and de-skews tilted/skewed images so that they are more
    transcription-friendly

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>`
        object that includes pages that need to be image-corrected

    Optional Parameters:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param rotation_correction_enabled: Identifies and corrects the orientation of images.
        Enabled by default.
    :param mobile_processing_enabled: Improves the machine readability of photo captured documents.
        Disabled by default.
    :param language_family: language family to use when performing image correction.
        If not provided, the system will default to `latin`. Language families are single
        word lowercase strings, e.g., `latin`, `arabic`, `korean`, `chinese`.
        You can read more about language families in the
        "Supported Languages" article in the application documentation:
        https://help.hyperscience.ai/v43/docs/supported-languages.
    :param app_metadata: used for capturing information about the flow

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>` with
      the `corrected_image_uuid` field populated on its pages with the rotated/de-skewed images.

    Example usage::

        # This is one way to obtain the submission object (using SubmissionBootstrapBlock)
        submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

        idp_image_correction_block = IDPImageCorrectionBlock(
            reference_name='idp_image_correction',
            submission=submission_bootstrap.output('submission'),
        )

        # reference to the output of IDPImageCorrectionBlock which can be passed as input to the
        # next block. For more information on output() and output references, please take a look at
        # class Block and its output() method
        output_ref = idp_image_correction_block.output()
    """

    IDENTIFIER = 'IMAGE_CORRECTION_SUBMISSION_2'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        reference_name: str | None = None,
        rotation_correction_enabled: bool | str = True,
        mobile_processing_enabled: bool | str = False,
        language_family: str | None = None,
        title: str = 'Image Correction (Submission)',
        description: str = 'Rotate and de-skew documents included in a submission',
        app_metadata: list[str] | None = None,
    ) -> None:
        inputs: dict[Any, Any] = {
            'submission': submission,
            'rotation_correction_enabled': rotation_correction_enabled,
            'mobile_processing_enabled': mobile_processing_enabled,
            'language_family': language_family,
        }
        if app_metadata is not None:
            inputs['app_metadata'] = app_metadata

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input=inputs,
            title=title,
            description=description,
        )


IDP_CORE_INPUTS_MAPPING = {
    SubmissionBootstrapBlock.IDENTIFIER: {
        'submission': workflow_input('submission'),
        'notification_workflow': workflow_input(Settings.SubmissionBootstrapNotificationWorkflow),
        's3_config': workflow_input(Settings.SubmissionBootstrapS3Config),
        's3_endpoint_url': workflow_input(Settings.SubmissionBootstrapS3EndpointUrl),
        'ocs_config': workflow_input(Settings.SubmissionBootstrapOCSConfig),
        'http_config': workflow_input(Settings.SubmissionBootstrapHTTPConfig),
        'oauth_token_url': workflow_input(Settings.SubmissionBootstrapOAuthTokenUrl),
        'oauth_client_id': workflow_input(Settings.SubmissionBootstrapOAuthClientId),
        'oauth_client_secret': workflow_input(Settings.SubmissionBootstrapOAuthClientSecret),
        'oauth_scope': workflow_input(Settings.SubmissionBootstrapOAuthScope),
        'abs_auth_type': workflow_input(Settings.SubmissionBootstrapABSAuthType),
        'abs_account_url': workflow_input(Settings.SubmissionBootstrapABSAccountUrl),
        'abs_tenant_id': workflow_input(Settings.SubmissionBootstrapABSTenantId),
        'abs_client_id': workflow_input(Settings.SubmissionBootstrapABSClientId),
        'abs_client_secret': workflow_input(Settings.SubmissionBootstrapABSClientSecret),
        'abs_authority_host': workflow_input(Settings.SubmissionBootstrapABSAuthorityHost),
        'abs_account_key': workflow_input(Settings.SubmissionBootstrapABSAccountKey),
        'abs_account_name': workflow_input(Settings.SubmissionBootstrapABSAccountName),
        'gcs_credentials_json': workflow_input(Settings.SubmissionBootstrapGCSCredentialsJson),
        'workflow_uuid': workflow_input(IdpFlowInputs.WorkflowUuid),
        'workflow_name': workflow_input(IdpFlowInputs.WorkflowName),
        'workflow_version': workflow_input(IdpFlowInputs.WorkflowVersion),
    },
    MachineCollationBlock.IDENTIFIER: {
        'dedupe_files': workflow_input('machine_collation_dedupe_files'),
        'remove_from_cases': workflow_input('machine_collation_remove_from_cases'),
        'retention_period': workflow_input('machine_collation_retention_period'),
        'refresh_retention_period': workflow_input('machine_collation_refresh_retention_period'),
    },
    MachineClassificationBlock.IDENTIFIER: {
        'rotation_correction_enabled': workflow_input(
            'machine_classification_rotation_correction_enabled'
        ),
        'mobile_processing_enabled': workflow_input(
            'machine_classification_mobile_processing_enabled'
        ),
        'file_transcription_enabled': workflow_input(
            'machine_classification_file_transcription_enabled'
        ),
        'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
        'vpc_registration_threshold': workflow_input(Settings.StructuredLayoutMatchThreshold),
        'manual_nlc_enabled': workflow_input(Settings.ManualNlcEnabled),
        'nlc_enabled': workflow_input(Settings.SemiStructuredClassification),
        'nlc_target_accuracy': workflow_input(Settings.SemiTargetAccuracy),
        'nlc_doc_grouping_logic': workflow_input(Settings.SemiDocGroupingLogic),
    },
    ManualClassificationBlock.IDENTIFIER: {
        'notification_workflow': workflow_input('notification_workflow_classification'),
        'task_restrictions': workflow_input('manual_classification_task_restrictions'),
        'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
        'manual_nlc_enabled': workflow_input(Settings.ManualNlcEnabled),
        'nlc_enabled': workflow_input(Settings.SemiStructuredClassification),
        'nlc_target_accuracy': workflow_input(Settings.SemiTargetAccuracy),
        'mobile_processing_enabled': workflow_input(
            'machine_classification_mobile_processing_enabled'
        ),
    },
    MachineIdentificationBlock.IDENTIFIER: {
        'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
        'manual_field_id_enabled': workflow_input(Settings.ManualFieldIdEnabled),
        'force_required_missing_entries_to_sv': workflow_input(Settings.ForceRequiredEntriesToSV),
        'field_id_target_accuracy': workflow_input(Settings.FieldIdTargetAccuracy),
        'table_id_target_accuracy': workflow_input(Settings.TableIdTargetAccuracy),
        'id_target_accuracies': workflow_input(Settings.IdentificationTargetAccuracies),
    },
    ManualIdentificationBlock.IDENTIFIER: {
        'notification_workflow': workflow_input('notification_workflow_identification'),
        'task_restrictions': workflow_input('manual_identification_task_restrictions'),
        'manual_field_id_enabled': workflow_input(Settings.ManualFieldIdEnabled),
        'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
    },
    MachineTranscriptionBlock.IDENTIFIER: {
        'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
        'transcription_model': workflow_input(Settings.TranscriptionModel),
        'finetuning_only_trained_layouts': workflow_input(Settings.FinetuningOnlyTrainedLayouts),
        'force_normalization_errors_to_sv': workflow_input(Settings.ForceNormalizationErrorsToSV),
        'force_required_blank_entries_to_sv': workflow_input(Settings.ForceRequiredEntriesToSV),
        'transcription_overrides': workflow_input(Settings.TranscriptionOverrides),
        'structured_text_target_accuracy': workflow_input(Settings.StructuredTextTargetAccuracy),
        'structured_text_confidence_threshold': workflow_input(Settings.StructuredTextThreshold),
        'structured_text_acceptable_confidence': workflow_input(
            Settings.StructuredTextMinLegThreshold
        ),
        'semi_structured_text_target_accuracy': workflow_input(
            Settings.SemiStructuredTextTargetAccuracy
        ),
        'semi_structured_text_confidence_threshold': workflow_input(
            Settings.SemiStructuredTextThreshold
        ),
        'semi_structured_text_acceptable_confidence': workflow_input(
            Settings.SemiStructuredTextMinLegThreshold
        ),
        'semi_structured_table_target_accuracy': workflow_input(
            Settings.SemiStructuredTableTargetAccuracy
        ),
        'semi_structured_table_confidence_threshold': workflow_input(
            Settings.SemiStructuredTableThreshold
        ),
        'semi_structured_table_acceptable_confidence': workflow_input(
            Settings.SemiStructuredTableMinLegThreshold
        ),
        'structured_checkbox_target_accuracy': workflow_input(
            Settings.StructuredCheckboxTargetAccuracy
        ),
        'structured_checkbox_confidence_threshold': workflow_input(
            Settings.StructuredCheckboxThreshold
        ),
        'structured_checkbox_acceptable_confidence': workflow_input(
            Settings.StructuredCheckboxMinLegThreshold
        ),
        'structured_signature_target_accuracy': workflow_input(
            Settings.StructuredSignatureTargetAccuracy
        ),
        'structured_signature_confidence_threshold': workflow_input(
            Settings.StructuredSignatureThreshold
        ),
        'structured_signature_acceptable_confidence': workflow_input(
            Settings.StructuredSignatureMinLegThreshold
        ),
        'semi_structured_checkbox_target_accuracy': workflow_input(
            Settings.SemiStructuredCheckboxTargetAccuracy
        ),
        'semi_structured_checkbox_confidence_threshold': workflow_input(
            Settings.SemiStructuredCheckboxThreshold
        ),
        'semi_structured_checkbox_acceptable_confidence': workflow_input(
            Settings.SemiStructuredCheckboxMinLegThreshold
        ),
        'field_target_accuracies': workflow_input(Settings.FieldTranscriptionTargetAccuracies),
        'always_supervise_blank_cells': workflow_input(
            'manual_transcription_always_supervise_blank_cells'
        ),
        'manual_transcription_enabled': workflow_input(Settings.ManualTranscriptionEnabled),
        'address_parsing_enabled': workflow_input(AddressParserSettings.AddressParsingEnabled),
        'address_parser_api_provider': workflow_input(AddressParserSettings.ApiProvider),
        'address_parser_api_key': workflow_input(AddressParserSettings.ApiKey),
        'address_parser_api_options': workflow_input(AddressParserSettings.ApiOptions),
    },
    ManualTranscriptionBlock.IDENTIFIER: {
        'table_output_manual_review': workflow_input(
            'manual_transcription_table_output_manual_review'
        ),
        'supervision_transcription_masking': workflow_input(
            'manual_transcription_supervision_transcription_masking'
        ),
        'always_supervise_blank_cells': workflow_input(
            'manual_transcription_always_supervise_blank_cells'
        ),
        'task_restrictions': workflow_input('manual_transcription_task_restrictions'),
        'notification_workflow': workflow_input('notification_workflow_transcription'),
        'address_parsing_enabled': workflow_input(AddressParserSettings.AddressParsingEnabled),
        'address_parser_api_provider': workflow_input(AddressParserSettings.ApiProvider),
        'address_parser_api_key': workflow_input(AddressParserSettings.ApiKey),
        'address_parser_api_options': workflow_input(AddressParserSettings.ApiOptions),
    },
    FlexibleExtractionBlock.IDENTIFIER: {
        'task_restrictions': workflow_input('flexible_extraction_task_restrictions'),
        'supervision_transcription_masking': workflow_input(
            'flexible_extraction_supervision_transcription_masking'
        ),
        'notification_workflow': workflow_input('notification_workflow_flexible_extraction'),
        'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
        'address_parsing_enabled': workflow_input(AddressParserSettings.AddressParsingEnabled),
        'address_parser_api_provider': workflow_input(AddressParserSettings.ApiProvider),
        'address_parser_api_key': workflow_input(AddressParserSettings.ApiKey),
        'address_parser_api_options': workflow_input(AddressParserSettings.ApiOptions),
    },
    ReprocessingBlock.IDENTIFIER: {
        'trigger': workflow_input(IdpFlowInputs.Trigger),
    },
    DocumentRendererBlock.IDENTIFIER: {
        'document_rendering_enabled': workflow_input(Settings.DocumentRenderingEnabled),
        'document_rendering_mime_type': workflow_input(Settings.DocumentRenderingMimeType),
        'document_rendering_unit': workflow_input(Settings.DocumentRenderingUnit),
        'document_rendering_height': workflow_input(Settings.DocumentRenderingHeight),
        'document_rendering_width': workflow_input(Settings.DocumentRenderingWidth),
        'document_rendering_quality': workflow_input(Settings.DocumentRenderingQuality),
        'document_rendering_mode': workflow_input(Settings.DocumentRenderingMode),
        'document_rendering_searchable_pdf_enabled': workflow_input(
            Settings.DocumentRenderingSearchablePdfEnabled
        ),
    },
    SubmissionCompleteBlock.IDENTIFIER: {
        'nlc_qa_sampling_ratio': workflow_input(Settings.SemiQaSampleRate),
        'field_id_qa_enabled': workflow_input(Settings.FieldIdQaEnabled),
        'field_id_qa_sampling_ratio': workflow_input(Settings.FieldIdQaSampleRate),
        'table_id_qa_enabled': workflow_input(Settings.TableIdQaEnabled),
        'table_id_qa_sampling_ratio': workflow_input(Settings.TableIdQaSampleRate),
        'transcription_qa_enabled': workflow_input(Settings.TranscriptionQaEnabled),
        'transcription_structured_entry_qa_sample_rate': workflow_input(
            Settings.TranscriptionStructuredEntryQaSampleRate
        ),
        'transcription_structured_signature_qa_sample_rate': workflow_input(
            Settings.TranscriptionStructuredSignatureQaSampleRate
        ),
        'transcription_structured_checkbox_qa_sample_rate': workflow_input(
            Settings.TranscriptionStructuredCheckboxQaSampleRate
        ),
        'transcription_semi_structured_qa_sample_rate': workflow_input(
            Settings.TranscriptionSemiStructuredQaSampleRate
        ),
        'table_cell_transcription_qa_enabled': workflow_input(
            Settings.TableCellTranscriptionQaEnabled
        ),
        'table_cell_transcription_qa_sample_rate': workflow_input(
            Settings.TableCellTranscriptionQaSampleRate
        ),
        'auto_qa_sampling_rate_enabled': workflow_input(Settings.AutoQaSamplingRateEnabled),
        'exclude_auto_transcribe_fields_from_qa': workflow_input(
            Settings.ExcludeAutoTranscribeFieldsFromQA
        ),
    },
}
