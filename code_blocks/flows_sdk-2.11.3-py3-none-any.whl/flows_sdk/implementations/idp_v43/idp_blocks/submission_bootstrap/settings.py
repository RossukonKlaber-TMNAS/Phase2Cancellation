from typing import Any

from flows_sdk.flows import Dependency, Parameter
from flows_sdk.implementations.idp_v43.base_inputs import BaseInputs

S3_SECRET_KEY = 's3_downloader'
OCS_SECRET_KEY = 'ocs_downloader'

ABS_SAS_TOKEN_ONLY = 'sas_token_only'
ABS_SERVICE_PRINCIPAL = 'service_principal'
ABS_MANAGED_IDENTITY = 'managed_identity'
ABS_ACCOUNT_KEY = 'account_key'

MAX_PAGES_DEFAULT = 10_000

OCS_DEPRECATION_WARNING = (
    'Oracle Content Server (OCS) support is deprecated as of v43.1 and will be removed in v46.0. '
    'Replace ocs:// paths with supported storage such as Amazon S3, Azure Blob Storage, GCS, '
    'or Generic Web Storage (HTTP/HTTPS).'
)
OCS_CONFIGURED_VALUE_CONDITION = {
    'anyOf': [
        {'type': 'string', 'minLength': 1},
        {'type': 'object', 'minProperties': 1},
    ]
}


def ocs_deprecation_warning_dependency(input_name: str) -> Dependency:
    return Dependency(
        condition={
            'required': [input_name],
            'properties': {input_name: OCS_CONFIGURED_VALUE_CONDITION},
        },
        override={'ui': {'warning': OCS_DEPRECATION_WARNING}},
    )


class SubmissionBootstrapSettings(BaseInputs):
    SubmissionBootstrapNotificationWorkflow = 'notification_workflow_initialization'
    SubmissionBootstrapS3Config = 'submission_bootstrap_s3_config'
    SubmissionBootstrapS3EndpointUrl = 'submission_bootstrap_s3_endpoint_url'
    SubmissionBootstrapOCSConfig = 'submission_bootstrap_ocs_config'
    SubmissionBootstrapOCSHostUrl = 'submission_bootstrap_ocs_host_url'
    SubmissionBootstrapOCSUsername = 'submission_bootstrap_ocs_username'
    SubmissionBootstrapOCSPassword = 'submission_bootstrap_ocs_password'
    SubmissionBootstrapOCSSslCert = 'submission_bootstrap_ocs_ssl_cert'
    SubmissionBootstrapHTTPConfig = 'submission_bootstrap_http_config'
    SubmissionBootstrapOAuthTokenUrl = 'submission_bootstrap_oauth_token_url'
    SubmissionBootstrapOAuthClientId = 'submission_bootstrap_oauth_client_id'
    SubmissionBootstrapOAuthClientSecret = 'submission_bootstrap_oauth_client_secret'
    SubmissionBootstrapOAuthScope = 'submission_bootstrap_oauth_scope'
    SubmissionBootstrapABSAuthType = 'submission_bootstrap_abs_auth_type'
    SubmissionBootstrapABSAccountUrl = 'submission_bootstrap_abs_account_url'
    SubmissionBootstrapABSTenantId = 'submission_bootstrap_abs_tenant_id'
    SubmissionBootstrapABSClientId = 'submission_bootstrap_abs_client_id'
    SubmissionBootstrapABSClientSecret = 'submission_bootstrap_abs_client_secret'
    SubmissionBootstrapABSAuthorityHost = 'submission_bootstrap_abs_authority_host'
    SubmissionBootstrapABSAccountKey = 'submission_bootstrap_abs_account_key'
    SubmissionBootstrapABSAccountName = 'submission_bootstrap_abs_account_name'
    SubmissionBootstrapGCSCredentialsJson = 'submission_bootstrap_gcs_credentials_json'
    SubmissionBootstrapGCSWorkloadIdentity = 'submission_bootstrap_gcs_workload_identity'
    SubmissionBootstrapMaxNumberOfPagesEnabled = 'submission_bootstrap_max_number_pages_enabled'
    SubmissionBootstrapMaxNumberOfPages = 'submission_bootstrap_max_number_pages'

    @classmethod
    def create(
        cls,
        notification_workflow: str | None,
        max_number_of_pages_enabled: bool,
        max_number_of_pages: int | None,
        s3_config: str | None = None,
        ocs_config: str | None = None,
        oauth_token_url: str | None = None,
        oauth_client_id: str | None = None,
        oauth_client_secret: str | None = None,
        oauth_scope: str | None = None,
    ) -> dict[str, Any]:
        return {
            cls.SubmissionBootstrapNotificationWorkflow: notification_workflow,
            cls.SubmissionBootstrapS3Config: s3_config,
            cls.SubmissionBootstrapOCSConfig: ocs_config,
            cls.SubmissionBootstrapOAuthTokenUrl: oauth_token_url,
            cls.SubmissionBootstrapOAuthClientId: oauth_client_id,
            cls.SubmissionBootstrapOAuthClientSecret: oauth_client_secret,
            cls.SubmissionBootstrapOAuthScope: oauth_scope,
            cls.SubmissionBootstrapMaxNumberOfPagesEnabled: max_number_of_pages_enabled,
            cls.SubmissionBootstrapMaxNumberOfPages: max_number_of_pages,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.SubmissionBootstrapNotificationWorkflow,
                type='FlowIdentifier',
                title='Submission Initialization Notification Flow',
                type_spec={'filter_roles': ['notifications'], 'label': 'If task needed'},
                optional=True,
                value=None,
            ),
            Parameter(
                name=cls.SubmissionBootstrapS3Config,
                type='object',
                description='Specify Amazon S3 credentials for submission retrieval store. '
                'Expects a json expression: '
                '{"aws_access_key_id": "X", "aws_secret_access_key": "Y"}',
                title='S3 Submission Retrieval Store Configuration',
                secret=True,
                optional=True,
            ),
            Parameter(
                name=cls.SubmissionBootstrapS3EndpointUrl,
                type='string',
                description='Endpoint URL for S3 Submission Retrieval Store. '
                'Do not use when your submission retrieval store is in a public cloud.',
                title='S3 Submission Retrieval Endpoint URL',
                optional=True,
            ),
            # @deprecated since v43.1; will be removed in v46.0.
            # Kept for backward compatibility.
            Parameter(
                name=cls.SubmissionBootstrapOCSConfig,
                type='object',
                description='OCS configuration for submission retrieval store. '
                'Expects a json expression: {"host_url": "X", "username": "Y", '
                '"password": "Z", "ssl_cert": "CA bundle filename"}. '
                'ssl_cert is the CA bundle filename inside $HS_PATH/certs directory. '
                'Set it to "SKIP" to disable certificate validation.',
                title='OCS Configuration',
                secret=True,
                optional=True,
                ui={'hidden': True},
            ),
            Parameter(
                name=cls.SubmissionBootstrapOCSHostUrl,
                type='string',
                description='OCS host URL for submission retrieval store.',
                title='OCS Host URL',
                optional=True,
                dependencies=[
                    ocs_deprecation_warning_dependency(cls.SubmissionBootstrapOCSHostUrl),
                    ocs_deprecation_warning_dependency(cls.SubmissionBootstrapOCSConfig),
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapOCSUsername,
                type='string',
                description='OCS username for authentication.',
                title='OCS Username',
                optional=True,
                dependencies=[
                    ocs_deprecation_warning_dependency(cls.SubmissionBootstrapOCSUsername)
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapOCSPassword,
                type='string',
                description='OCS password for authentication.',
                title='OCS Password',
                secret=True,
                optional=True,
                dependencies=[
                    ocs_deprecation_warning_dependency(cls.SubmissionBootstrapOCSPassword)
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapOCSSslCert,
                type='string',
                description='CA bundle filename inside $HS_PATH/certs directory. '
                'Set it to "SKIP" to disable certificate validation.',
                title='OCS SSL Certificate',
                optional=True,
                dependencies=[
                    ocs_deprecation_warning_dependency(cls.SubmissionBootstrapOCSSslCert)
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapHTTPConfig,
                type='object',
                description='Specify relevant Generic Web Storage configuration variables '
                'for submission retrieval store. Expects a JSON expression: '
                '{"username": "X", "password": "Y", "ssl_cert": "CA bundle filename"}. '
                'ssl_cert is the CA bundle filename inside $HS_PATH/certs directory. '
                'Set it to "SKIP" to disable certificate validation.',
                title='Generic Web Storage (HTTP/HTTPS) Configuration',
                secret=True,
                optional=True,
            ),
            Parameter(
                name=cls.SubmissionBootstrapOAuthTokenUrl,
                type='string',
                description='OAuth token endpoint for client credentials authentication. '
                'Used for authenticated HTTP/HTTPS file downloads (e.g., Salesforce).',
                title='HTTP/HTTPS OAuth Token URL',
                optional=True,
            ),
            Parameter(
                name=cls.SubmissionBootstrapOAuthClientId,
                type='string',
                description='Client ID for OAuth client credentials. '
                'Used for authenticated HTTP/HTTPS file downloads.',
                title='HTTP/HTTPS OAuth Client ID',
                optional=True,
            ),
            Parameter(
                name=cls.SubmissionBootstrapOAuthClientSecret,
                type='string',
                description='Client secret for OAuth client credentials. '
                'Used for authenticated HTTP/HTTPS file downloads.',
                title='HTTP/HTTPS OAuth Client Secret',
                secret=True,
                optional=True,
            ),
            Parameter(
                name=cls.SubmissionBootstrapOAuthScope,
                type='string',
                description='Optional OAuth scope sent with the OAuth client credentials '
                'token request. Used for authenticated HTTP/HTTPS file downloads.',
                title='HTTP/HTTPS OAuth Scope',
                optional=True,
            ),
            Parameter(
                name=cls.SubmissionBootstrapABSAuthType,
                type='string',
                optional=True,
                schema={
                    'type': 'string',
                    'oneOf': [
                        {'title': 'SAS Token Only', 'const': ABS_SAS_TOKEN_ONLY},
                        {'title': 'Service Principal', 'const': ABS_SERVICE_PRINCIPAL},
                        {'title': 'Managed Identity', 'const': ABS_MANAGED_IDENTITY},
                        {'title': 'Account Key', 'const': ABS_ACCOUNT_KEY},
                    ],
                },
                description='The type of authentication to use.',
                title='Azure Blob Storage Authentication Type',
            ),
            Parameter(
                name=cls.SubmissionBootstrapABSAccountUrl,
                type='string',
                description='The URL of the storage account.',
                title='Azure Blob Storage Account URL',
                optional=True,
                ui={'hidden': True},
                dependencies=[
                    Dependency(
                        condition={'required': [cls.SubmissionBootstrapABSAuthType]},
                        override={
                            'ui': {'hidden': False},
                            'optional': False,
                        },
                    ),
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapABSTenantId,
                type='string',
                description='The tenant ID of the service principal.',
                title='Azure Blob Storage Tenant ID',
                optional=True,
                ui={'hidden': True},
                dependencies=[
                    Dependency(
                        condition={
                            'required': [cls.SubmissionBootstrapABSAuthType],
                            'properties': {
                                cls.SubmissionBootstrapABSAuthType: {'const': ABS_SERVICE_PRINCIPAL}
                            },
                        },
                        override={
                            'ui': {'hidden': False},
                            'optional': False,
                        },
                    ),
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapABSClientId,
                type='string',
                description='The client ID of the service principal or managed identity.',
                title='Azure Blob Storage Client ID',
                optional=True,
                ui={'hidden': True},
                dependencies=[
                    Dependency(
                        condition={
                            'required': [cls.SubmissionBootstrapABSAuthType],
                            'properties': {
                                cls.SubmissionBootstrapABSAuthType: {
                                    'enum': [ABS_SERVICE_PRINCIPAL, ABS_MANAGED_IDENTITY]
                                }
                            },
                        },
                        override={
                            'ui': {'hidden': False},
                            'optional': False,
                        },
                    ),
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapABSClientSecret,
                type='string',
                description='The client secret of the service principal.',
                title='Azure Blob Storage Client Secret',
                optional=True,
                secret=True,
                ui={'hidden': True},
                dependencies=[
                    Dependency(
                        condition={
                            'required': [cls.SubmissionBootstrapABSAuthType],
                            'properties': {
                                cls.SubmissionBootstrapABSAuthType: {'const': ABS_SERVICE_PRINCIPAL}
                            },
                        },
                        override={
                            'ui': {'hidden': False},
                            'optional': False,
                        },
                    )
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapABSAuthorityHost,
                type='string',
                description='The authority host of the service principal.',
                title='Azure Blob Storage Authority Host',
                optional=True,
                ui={'hidden': True},
                dependencies=[
                    Dependency(
                        condition={
                            'required': [cls.SubmissionBootstrapABSAuthType],
                            'properties': {
                                cls.SubmissionBootstrapABSAuthType: {'const': ABS_SERVICE_PRINCIPAL}
                            },
                        },
                        override={'ui': {'hidden': False}},
                    )
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapABSAccountName,
                type='string',
                description='The account name of the storage account.',
                title='Azure Blob Storage Account Name',
                optional=True,
                secret=False,
                ui={'hidden': True},
                dependencies=[
                    Dependency(
                        condition={
                            'required': [cls.SubmissionBootstrapABSAuthType],
                            'properties': {
                                cls.SubmissionBootstrapABSAuthType: {'const': ABS_ACCOUNT_KEY}
                            },
                        },
                        override={
                            'ui': {'hidden': False},
                            'optional': False,
                        },
                    )
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapABSAccountKey,
                type='string',
                description='The account key of the storage account.',
                title='Azure Blob Storage Account Key',
                optional=True,
                secret=True,
                ui={'hidden': True},
                dependencies=[
                    Dependency(
                        condition={
                            'required': [cls.SubmissionBootstrapABSAuthType],
                            'properties': {
                                cls.SubmissionBootstrapABSAuthType: {'const': ABS_ACCOUNT_KEY}
                            },
                        },
                        override={
                            'ui': {'hidden': False},
                            'optional': False,
                        },
                    )
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapGCSCredentialsJson,
                type='json',
                description='GCP Service Account JSON credentials for connecting to GCS Storage, '
                'must be a valid json',
                title='GCP Service Account JSON',
                optional=True,
                secret=True,
                dependencies=[
                    Dependency(
                        condition={
                            'properties': {
                                cls.SubmissionBootstrapGCSWorkloadIdentity: {'const': True}
                            },
                        },
                        override={'ui': {'hidden': True}},
                    )
                ],
            ),
            Parameter(
                name=cls.SubmissionBootstrapGCSWorkloadIdentity,
                type='boolean',
                description='Credentials are obtained by using the Workload Identity Federation, '
                'applicable for HS installations inside GKE clusters.',
                title='Use GCP Workload Identity',
                value=True,
            ),
            Parameter(
                name=cls.SubmissionBootstrapMaxNumberOfPagesEnabled,
                type='boolean',
                value=False,
                title='Enable file page-limit check',
                description="Checks each file's page count and fails the submission "
                'if any exceed the specified page limit.',
            ),
            Parameter(
                name=cls.SubmissionBootstrapMaxNumberOfPages,
                type='integer',
                schema={'type': 'integer', 'minimum': 1, 'maximum': 1_000_000},
                optional=True,
                value=MAX_PAGES_DEFAULT,
                title='Maximum pages allowed per file',
                description='Submissions with files that exceed this maximum will '
                'automatically fail',
                dependencies=[
                    Dependency(
                        condition={
                            'properties': {
                                cls.SubmissionBootstrapMaxNumberOfPagesEnabled: {'const': False}
                            },
                        },
                        override={'ui': {'hidden': True}},
                    )
                ],
            ),
        ]
