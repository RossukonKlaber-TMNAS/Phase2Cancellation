from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.idp_blocks.flow_inputs import IdpFlowInputs
from flows_sdk.implementations.idp_v43.idp_blocks.reprocessing.settings import (
    ReprocessingSettings as Settings,
)
from flows_sdk.utils import workflow_input


class ReprocessingBlock(Block):
    """Reprocessing block enables a second extraction attempt if documents were initially
    confidently mis-classified by the machine. When an end-user specifies that a document layout
    is incorrect during Manual Identification, Manual Transcription, or Flexible Extraction, the
    flow will reach the Reprocessing block which will mark correctly classified documents as
    "complete" status. Misclassified documents with "reprocess" status will be marked with
    status "reprocessing" and processed in a second execution of the flow. This block should be
    placed before the SubmissionCompleteBlock to enable reprocessing.

    **How the Reprocessing block works**

    The Reprocessing block examines whether any documents within the submission have been marked
    with an incorrect layout, and if so, redirects the submission to the classification step for
    proper classification. It does this by recursively calling the same flow or subflow with the
    same inputs and documents, but with the addition of a status key for each document to denote
    which were marked with an incorrect layout during supervision.

    .. note::
        The Reprocessing block works in tandem with the “Mark Incorrect Layout” option presented
        to users during Manual Identification, Manual Transcription, and Flexible Extraction
        supervision interfaces introduced in R38. Include the Reprocessing block in all custom
        flows in order to take advantage of this feature. The feature will remain selectable
        in supervision interfaces even if the Reprocessing block is not included in the flow.

    The initial flow run will pause execution at the Reprocessing block until the recursive flow
    has completed, at which point the initial flow will resume to finish its execution. If an
    error occurs during the execution of the recursive flow, that error will be raised to the
    Reprocessing block of the initial flow.

    .. note::
        The recursive flow run is linked with the same correlation_id as the initial flow run
        and the submission. Users can click the “View related flow runs” link on the left
        sidebar of the initial flow run to view any recursive flow runs.

    As expected, recursively calling the same flow may cause some blocks to run again, resulting
    in unnecessary work being performed, or work which doesn't gracefully handle duplications
    (non-idempotent blocks). To mitigate this, certain Hyperscience-provided blocks - including
    Submission Initialization, Machine Collation, and Machine Classification - detect when the
    submission object already contains the output from its block to avoid re-execution. It's a
    best practice to build custom blocks such that they are idempotent and reentrant; if that's
    not feasible, you can add similar logic to custom blocks which do not depend on the layout
    for the documents being processed. Common methods for handling this include:

    * Iterating through each status key within the submission.document[] collection to see if
      any documents are set to "reprocess" or "reprocessing".

    * Inspecting if the submission object already contains a key or value explicitly defined
      by the custom code block.

    **Recommended Placement for the Reprocessing Block**

    * The Reprocessing block should not be placed before any supervision blocks which allow
      users to mark a document with an incorrect layout. These supervision blocks include
      Manual Identification, Manual Transcription and Flexible Extraction.

    * The Reprocessing block should always be placed before the SubmissionComplete Block.

    * The Reprocessing block can be used with flows which include multiple branches and
      conditionals; however, it's recommended to ensure the Reprocessing block is executed
      to honor user's selection of marking layouts incorrectly when supervising documents.

    * In general, any custom logic that is to be performed after data has been extracted from
      documents should be placed after the Reprocessing block. To avoid duplicate executions of
      this custom logic, it is recommended to separate the document processing blocks - inclusive
      of the Reprocessing block - from the custom logic. This can be handled in different ways:

        * Split the flow into separate subflows, where the Reprocessing block is in a subflow
          that does not contain the custom logic.

        * Add a decision to bypass the custom logic if the Reprocessing block was triggered.
          With this method, the recursive flow run will execute the custom logic, and the initial
          flow run will bypass the logic.

    Mandatory parameters:

    :param submission: Submission object

    Parameters with defaults:

    :param parent_flow: The identifier of the flow that this block is placed in, used to
        recursively call the same flow, defaults to '${workflow.definition.identifier}'
    :param idp_wf_config: The workflow input config to pass through to the recursive flow
        run, defaults to '${workflow.input}'
    :param trigger: Value used to trigger and correlate the recursive flow run,
        defaults to workflow_input(IdpFlowInputs.Trigger)
    :param reprocessing_enabled: Enables reprocessing of documents marked with an incorrect
        layout, defaults to workflow_input(Settings.ReprocessingEnabled)

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>`
      updated with the reprocessing results.
    * `is_reprocessing`: A boolean flag indicating whether the submission was sent for
      reprocessing.
    """

    IDENTIFIER = 'REPROCESSING_2'

    def __init__(
        self,
        reference_name: str | None,
        submission: Any,
        parent_flow: str = '${workflow.definition.identifier}',
        # This name could be more generic (like workflow_input), but changing it would
        # require releasing a new version of the block and would break compatibility with
        # existing flows.
        idp_wf_config: Any = '${workflow.input}',
        trigger: Any = workflow_input(IdpFlowInputs.Trigger),
        reprocessing_enabled: str | bool = workflow_input(Settings.ReprocessingEnabled),
    ):
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            title='Reprocessing',
            description='Reprocess flow if required.',
            input={
                'reprocessing_enabled': reprocessing_enabled,
                'idp_wf_config': idp_wf_config,
                'trigger': trigger,
                'submission': submission,
                'parent_flow': parent_flow,
            },
        )
