from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.idp_blocks.machine_collation.settings import (
    MachineCollationSettings as Settings,
)
from flows_sdk.utils import workflow_input


class MachineCollationBlock(Block):
    """Machine collation block groups files, documents and pages (from the submission) into cases.

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>`
        object
    :param cases: This parameter accepts an array of JSON objects that contain information on
        how Cases should be created. There are two ways to collate a case: by the filenames
        specified in the current Submission, or by the ids of the Documents or Pages submitted
        in previous submissions.

        This parameter follows the given format::

            {
                'cases': [
                    'external_case_id': 'HS-1',
                    'filename': 'file1.pdf',
                    'documents': [42],
                    'pages': [43]
                ]
            }

    Parameters with defaults:

    :param dedupe_files: Enabling this setting will replace case data from repeated file names
        within the same case. Cases will retain data from the most recently submitted version of
        a particular file. Note that this setting does not delete the old data, it just removes it
        from the case. Keep in mind this option is only relevant when adding to cases.
        Defaults to workflow_input(Settings.CollationDedupeFiles)
    :param refresh_retention_period: If ``True``, (re)applies Retention Period parameter to all
        cases passed into the block. If ``False``, only updates those without a pre-existing
        deletion date. Defaults to workflow_input(Settings.CollationRefreshRetentionPeriod)
    :param remove_from_cases: This parameter accepts an array of JSON objects that contains
        information on how documents or pages should be removed from a pre-existing case.
        Currently, the only way to de-collate from a case is by the ids of the Documents or
        Pages within a given case, defaults to workflow_input(Settings.CollationRemoveFromCases)

        This parameter follows the given format::

            {
                'remove_from_cases': [
                    'external_case_id': 'HS-1',
                    'documents': [42],
                    'pages': [43]
                ]
            }

    :param retention_period: The number of days to retain cases after they are updated by this
        block. If passed ``None``, no changes to the deletion date will be made.
        Defaults to workflow_input(Settings.CollationRetentionPeriod)
    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>`
      object.

    Example usage::

        machine_collation = MachineCollationBlock(
            reference_name='machine_collation',
            submission=submission_bootstrap.output('submission'),
            cases=submission_bootstrap.output('api_params.cases'),
            dedupe_files=True,
            remove_from_cases=custom_supervision.output('remove_from_cases')
        )
    """

    IDENTIFIER = 'MACHINE_COLLATION_2'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        cases: list[dict[str, Any]] | str,
        dedupe_files: bool | str = workflow_input(Settings.CollationDedupeFiles),
        refresh_retention_period: bool | str = workflow_input(
            Settings.CollationRefreshRetentionPeriod
        ),
        remove_from_cases: list[dict[str, Any]] | str | None = workflow_input(
            Settings.CollationRemoveFromCases
        ),
        retention_period: int | str | None = workflow_input(Settings.CollationRetentionPeriod),
        reference_name: str | None = None,
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'submission': submission,
                'cases': cases,
                'dedupe_files': dedupe_files,
                'remove_from_cases': remove_from_cases,
                'retention_period': retention_period,
                'refresh_retention_period': refresh_retention_period,
            },
            title='Machine Collation',
            description='Group files, documents, and pages into cases',
        )
