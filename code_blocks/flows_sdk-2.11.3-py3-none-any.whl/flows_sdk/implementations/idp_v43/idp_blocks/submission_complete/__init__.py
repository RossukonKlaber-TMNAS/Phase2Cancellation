from flows_sdk.implementations.idp_v43.idp_blocks.submission_complete.block import (
    SubmissionCompleteBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.submission_complete.settings import (
    SubmissionCompleteSettings,
)

__all__ = ['SubmissionCompleteBlock', 'SubmissionCompleteSettings']
