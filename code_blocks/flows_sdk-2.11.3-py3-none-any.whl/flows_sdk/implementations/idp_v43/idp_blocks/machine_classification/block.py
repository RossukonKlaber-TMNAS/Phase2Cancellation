from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.idp_blocks.machine_classification.settings import (
    MachineClassificationSettings as Settings,
)
from flows_sdk.utils import workflow_input


class MachineClassificationBlock(Block):
    """Machine classification block automatically matches documents to structured,
    semi-structured or additional layouts

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>`
        object
    :param api_params:

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param rotation_correction_enabled: Identifies and corrects the orientation of
        semi-structured images,
        defaults to workflow_input(Settings.RotationCorrectionEnabled)
    :param mobile_processing_enabled: Improves the machine readability of photo
        captured documents,
        defaults to workflow_input(Settings.MobileProcessingEnabled)
    :param file_transcription_enabled: Improves the transcription speed of pdf files.
        Make sure that the "Image Correction" option is disabled and the pdfs you
        submit do not contain any rotated images
        defaults to workflow_input(Settings.FileTranscriptionEnabled)
    :param layout_release_uuid: Layout Release UUID at submission creation time,
        defaults to workflow_input(Settings.LayoutReleaseUuid)
    :param vpc_registration_threshold: Structured pages above this threshold will be
        automatically matched to a layout variation,
        defaults to workflow_input(Settings.StructuredLayoutMatchThreshold)
    :param nlc_enabled: Enables workflow to manage a model for automated classification
        of semi-structured and additional layout variations,
        defaults to workflow_input(Settings.SemiStructuredClassification)
    :param nlc_target_accuracy: defaults to workflow_input(Settings.SemiTargetAccuracy)
    :param nlc_doc_grouping_logic: Logic to handle multiple pages matched to the same
        layout variation a given submission,
        defaults to workflow_input(Settings.SemiDocGroupingLogic)
    :param layout_id_dealbreaker: Validates structured document matching by ensuring that the
        Form ID on the document matches the Layout ID on the corresponding layout,
        defaults to workflow_input(Settings.LayoutIdDealbreaker)
    :param layout_id_dealbreaker_bypass: Bypasses Form ID and Layout ID validation if there is
        no Layout ID present on the Layout Page,
        defaults to workflow_input(Settings.LayoutIdDealbreakerBypass)
    :param manual_nlc_enabled: Available from V41.2; enables manual classification when applicable,
        defaults to workflow_input(Settings.ManualNlcEnabled)

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>` with
      the `documents` and `unassigned_pages` fields updated with the classification results.
    * `needs_manual_classification`: A boolean flag indicating whether the submission needs manual
      classification.
    * `vpc_metadata`: Metadata related to the structured classification process.
    * `nlc_metadata`: Metadata related to the non-structured classification process.

    Example usage::

        machine_classification = MachineClassificationBlock(
            reference_name='machine_classification',
            submission=case_collation.output('submission'),
            api_params=submission_bootstrap.output('result.api_params'),
            rotation_correction_enabled=idp_wf_config.rotation_correction_enabled,
        )
    """

    IDENTIFIER = 'MACHINE_CLASSIFICATION_7'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        api_params: dict[str, Any] | str,
        reference_name: str | None = None,
        rotation_correction_enabled: bool | str = workflow_input(
            Settings.RotationCorrectionEnabled
        ),
        mobile_processing_enabled: bool | str = workflow_input(Settings.MobileProcessingEnabled),
        file_transcription_enabled: bool | str = workflow_input(Settings.FileTranscriptionEnabled),
        layout_release_uuid: str = workflow_input(Settings.LayoutReleaseUuid),
        vpc_registration_threshold: str | float = workflow_input(
            Settings.StructuredLayoutMatchThreshold
        ),
        nlc_enabled: str | bool = workflow_input(Settings.SemiStructuredClassification),
        nlc_target_accuracy: str | float = workflow_input(Settings.SemiTargetAccuracy),
        nlc_doc_grouping_logic: str = workflow_input(Settings.SemiDocGroupingLogic),
        layout_id_dealbreaker: str | bool = workflow_input(Settings.LayoutIdDealbreaker),
        layout_id_dealbreaker_bypass: str | bool = workflow_input(
            Settings.LayoutIdDealbreakerBypass
        ),
        manual_nlc_enabled: str | bool = workflow_input(Settings.ManualNlcEnabled),
    ) -> None:
        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'layout_release_uuid': layout_release_uuid,
                'submission': submission,
                'api_params': api_params,
                'vpc_registration_threshold': vpc_registration_threshold,
                'nlc_enabled': nlc_enabled,
                'nlc_target_accuracy': nlc_target_accuracy,
                'nlc_doc_grouping_logic': nlc_doc_grouping_logic,
                'rotation_correction_enabled': rotation_correction_enabled,
                'mobile_processing_enabled': mobile_processing_enabled,
                'file_transcription_enabled': file_transcription_enabled,
                'layout_id_dealbreaker': layout_id_dealbreaker,
                'layout_id_dealbreaker_bypass': layout_id_dealbreaker_bypass,
                'manual_nlc_enabled': manual_nlc_enabled,
            },
            title='Machine Classification',
            description='Automatically classify documents',
        )
