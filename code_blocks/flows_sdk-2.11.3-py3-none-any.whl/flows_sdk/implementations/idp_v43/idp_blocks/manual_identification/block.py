from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.idp_blocks.manual_identification.settings import (
    ManualIdentificationSettings as Settings,
)
from flows_sdk.utils import workflow_input


class ManualIdentificationBlock(Block):
    """Manual identification allows keyers to complete field identification or table identification
    tasks, where they draw bounding boxes around the contents of certain fields, table columns
    or table rows. This identification process ensures that the system will be able to
    transcribe the correct content in the upcoming transcription process

    Mandatory parameters:

    :param submission: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>`
        object
    :param api_params:

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param task_restrictions: Defines what users can access Supervision tasks created
        by this block,
        defaults to workflow_input(Settings.ManualFieldIdTaskRestrictions)
    :param manual_field_id_enabled: Enables manual identification when applicable,
        defaults to workflow_input(Settings.ManualFieldIdEnabled)
    :param layout_release_uuid: Layout Release UUID at submission creation time,
        defaults to workflow_input(Settings.LayoutReleaseUuid)
    :param notification_workflow: Notification flow name to run when the submission
        enters Manual Identification,
        defaults to workflow_input(Settings.ManualFieldIdNotificationWorkflow)

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>` with
      its `documents` updated with the identified fields and tables.

    Example usage::

        manual_identification = ManualIdentificationBlock(
            reference_name='manual_identification',
            submission=machine_identification.output('submission'),
            api_params=submission_bootstrap.output('result.api_params'),
            task_restrictions=idp_wf_config.manual_identification_config.task_restrictions,
        )
    """

    IDENTIFIER = 'MANUAL_IDENTIFICATION_6'

    def __init__(
        self,
        submission: dict[str, Any] | str,
        api_params: dict[str, Any] | str,
        reference_name: str | None = None,
        task_restrictions: list[Any] | str | None = workflow_input(
            Settings.ManualFieldIdTaskRestrictions
        ),
        manual_field_id_enabled: bool | str = workflow_input(Settings.ManualFieldIdEnabled),
        layout_release_uuid: str = workflow_input(Settings.LayoutReleaseUuid),
        notification_workflow: str = workflow_input(Settings.ManualFieldIdNotificationWorkflow),
    ) -> None:
        if task_restrictions is None:
            task_restrictions = []

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'submission': submission,
                'api_params': api_params,
                'manual_field_id_enabled': manual_field_id_enabled,
                'layout_release_uuid': layout_release_uuid,
                'notification_workflow': notification_workflow,
                'task_restrictions': task_restrictions,
            },
            title='Manual Identification',
            description=(
                'Manually locate fields on Semi-structured documents that '
                'could not be automatically located'
            ),
        )
