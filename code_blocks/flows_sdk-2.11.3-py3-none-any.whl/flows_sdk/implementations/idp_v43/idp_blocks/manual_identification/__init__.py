from flows_sdk.implementations.idp_v43.idp_blocks.manual_identification.block import (
    ManualIdentificationBlock,
)
from flows_sdk.implementations.idp_v43.idp_blocks.manual_identification.settings import (
    ManualIdentificationSettings,
)

__all__ = ['ManualIdentificationBlock', 'ManualIdentificationSettings']
