from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v43.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v43.idp_blocks.common_settings import (
    ORCA_ONLY_EXTRACTION_DEPENDENCY,
    IdentificationSettings,
    IdpSystemSettings,
)
from flows_sdk.implementations.idp_v43.licensing.licensing import FeatureGatingCommonDependencies


class ManualIdentificationSettings(IdpSystemSettings, IdentificationSettings, BaseInputs):
    ManualFieldIdNotificationWorkflow = 'notification_workflow_identification'
    ManualFieldIdTaskRestrictions = 'manual_identification_task_restrictions'

    @classmethod
    def create(  # type: ignore[override]
        cls,
        manual_id_enabled: bool,
        notification_workflow: str | None,
    ) -> dict[str, Any]:
        return {
            cls.ManualFieldIdEnabled: manual_id_enabled,
            cls.ManualFieldIdNotificationWorkflow: notification_workflow,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.ManualFieldIdNotificationWorkflow,
                type='FlowIdentifier',
                value=None,
                title='Manual Identification Notification Flow',
                type_spec={'filter_roles': ['notifications'], 'label': 'If task needed'},
                optional=True,
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
            Parameter(
                name=cls.ManualFieldIdTaskRestrictions,
                type='TaskRestrictions',
                title='Default Task Restrictions',
                description=(
                    'Defines what users can access Supervision tasks created by this block.'
                ),
                optional=True,
                dependencies=[
                    *FeatureGatingCommonDependencies.SemiStructured,
                    ORCA_ONLY_EXTRACTION_DEPENDENCY,
                ],
            ),
        ]
