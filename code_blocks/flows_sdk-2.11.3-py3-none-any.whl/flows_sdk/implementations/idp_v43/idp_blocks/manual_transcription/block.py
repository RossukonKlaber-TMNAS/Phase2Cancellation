from typing import Any

from flows_sdk.blocks import Block
from flows_sdk.implementations.idp_v43.additional_blocks.address_parsing.settings import (
    AddressParserSettings,
)
from flows_sdk.implementations.idp_v43.idp_blocks.manual_transcription.settings import (
    ManualTranscriptionSettings as Settings,
)
from flows_sdk.utils import workflow_input


class ManualTranscriptionBlock(Block):
    """Manual transcription lets your keyers manually enter the text found in fields or tables
    that could not be automatically transcribed

    Mandatory parameters:

    :param submission: Submission object
    :param api_params:

    Parameters with defaults:

    :param reference_name: unique identifier within a flow, a unique one will be generated when
        not provided
    :param supervision_transcription_masking: Prevents users from inputting invalid
        characters during Supervision Transcription tasks,
        defaults to workflow_input(Settings.ManualTranscriptionSupervisionTranscriptionMasking)
    :param table_output_manual_review: Always generates a table transcription task if the
        layout contains a table. If disabled, a table transcription task will only be
        generated if one or more cells have transcribed values below the defined thresholds,
        defaults to workflow_input(Settings.ManualTranscriptionTableOutputManualReview)
    :param always_supervise_blank_cells: If enabled, always send blank cells in transcribed
        tables to be supervised manually, regardless of confidence
        defaults to workflow_input(Settings.ManualTranscriptionAlwaysSuperviseBlankCells)
    :param task_restrictions: Defines what users can access Supervision tasks for
        submission from a particular source or submissions matching a specific layout,
        defaults to workflow_input(Settings.ManualTranscriptionTaskRestrictions)
    :param manual_transcription_enabled: Enables manual transcription when applicable,
        defaults to workflow_input(Settings.ManualTranscriptionEnabled)
    :param notification_workflow: Notification flow name to run when the submission
        enters Manual Transcription,
        defaults to workflow_input(Settings.ManualTranscriptionNotificationWorkflow)
    :param address_parsing_enabled: Available from V43.2; toggles AddressParser invocation on
        manually-transcribed address fields,
        defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
    :param address_parser_api_provider: Available from V43.2; selects the address parsing
        provider ('none' / 'google' / 'smarty' / 'geoapify'),
        defaults to workflow_input(AddressParserSettings.ApiProvider)
    :param address_parser_api_key: Available from V43.2; API key for the configured provider,
        defaults to workflow_input(AddressParserSettings.ApiKey)
    :param address_parser_api_options: Available from V43.2; provider-specific JSON options,
        defaults to workflow_input(AddressParserSettings.ApiOptions)
    :param title: overrides the block's default title shown in Flow Studio,
        defaults to 'Manual Transcription'
    :param description: overrides the block's default description shown in Flow Studio,
        defaults to 'Manually transcribe fields that could not be automatically transcribed'

    Output:
    The block returns an object with the following keys:

    * `submission`: :py:class:`Submission <flows_sdk.implementations.idp_v43.contracts.Submission>` with
      the manually transcribed field values.

    Example usage::

        manual_transcription = ManualTranscriptionBlock(
            reference_name='manual_transcription',
            submission=machine_transcription.output('submission'),
            api_params=submission_bootstrap.output('result.api_params'),
            supervision_transcription_masking=(
                idp_wf_config.manual_transcription_config.supervision_transcription_masking
            ),
            table_output_manual_review=(
                idp_wf_config.manual_transcription_config.table_output_manual_review
            ),
            task_restrictions=idp_wf_config.manual_transcription_config.task_restrictions,
        )
    """

    IDENTIFIER = 'MANUAL_TRANSCRIPTION_5'

    def __init__(
        self,
        submission: Any,
        api_params: Any,
        reference_name: str | None = None,
        supervision_transcription_masking: bool | str = workflow_input(
            Settings.ManualTranscriptionSupervisionTranscriptionMasking
        ),
        table_output_manual_review: bool | str = workflow_input(
            Settings.ManualTranscriptionTableOutputManualReview
        ),
        always_supervise_blank_cells: bool | str = workflow_input(
            Settings.ManualTranscriptionAlwaysSuperviseBlankCells
        ),
        task_restrictions: list[Any] | str | None = workflow_input(
            Settings.ManualTranscriptionTaskRestrictions
        ),
        manual_transcription_enabled: bool | str = workflow_input(
            Settings.ManualTranscriptionEnabled
        ),
        notification_workflow: str | None = workflow_input(
            Settings.ManualTranscriptionNotificationWorkflow
        ),
        address_parsing_enabled: str | bool = workflow_input(
            AddressParserSettings.AddressParsingEnabled
        ),
        address_parser_api_provider: str = workflow_input(AddressParserSettings.ApiProvider),
        address_parser_api_key: str | None = workflow_input(AddressParserSettings.ApiKey),
        address_parser_api_options: str | dict | None = workflow_input(
            AddressParserSettings.ApiOptions
        ),
        title: str = 'Manual Transcription',
        description: str = 'Manually transcribe fields that could not be automatically transcribed',
    ) -> None:
        if not task_restrictions:
            task_restrictions = []

        super().__init__(
            identifier=self.IDENTIFIER,
            reference_name=reference_name,
            input={
                'submission': submission,
                'api_params': api_params,
                'task_restrictions': task_restrictions,
                'manual_transcription_enabled': manual_transcription_enabled,
                'supervision_transcription_masking': supervision_transcription_masking,
                'table_output_manual_review': table_output_manual_review,
                'always_supervise_blank_cells': always_supervise_blank_cells,
                'notification_workflow': notification_workflow,
                AddressParserSettings.AddressParsingEnabled: address_parsing_enabled,
                AddressParserSettings.ApiProvider: address_parser_api_provider,
                AddressParserSettings.ApiKey: address_parser_api_key,
                AddressParserSettings.ApiOptions: address_parser_api_options,
            },
            title=title,
            description=description,
        )
