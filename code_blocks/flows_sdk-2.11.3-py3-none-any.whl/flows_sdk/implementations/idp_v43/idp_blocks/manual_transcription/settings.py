from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v43.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v43.idp_blocks.common_settings import (
    ORCA_ONLY_EXTRACTION_DEPENDENCY,
    TranscriptionSettings,
)
from flows_sdk.implementations.idp_v43.licensing.licensing import FeatureGatingCommonDependencies


class ManualTranscriptionSettings(TranscriptionSettings, BaseInputs):
    ManualTranscriptionNotificationWorkflow = 'notification_workflow_transcription'
    ManualTranscriptionTaskRestrictions = 'manual_transcription_task_restrictions'
    ManualTranscriptionSupervisionTranscriptionMasking = (
        'manual_transcription_supervision_transcription_masking'
    )
    ManualTranscriptionTableOutputManualReview = 'manual_transcription_table_output_manual_review'

    @classmethod
    def create(
        cls,
        manual_transcription_enabled: bool,
        notification_workflow: str | None,
        task_restrictions: list[str],
        supervision_transcription_masking: bool,
        table_output_manual_review: bool,
    ) -> dict[str, Any]:
        return {
            cls.ManualTranscriptionEnabled: manual_transcription_enabled,
            cls.ManualTranscriptionNotificationWorkflow: notification_workflow,
            cls.ManualTranscriptionTaskRestrictions: task_restrictions,
            cls.ManualTranscriptionSupervisionTranscriptionMasking: (
                supervision_transcription_masking
            ),
            cls.ManualTranscriptionTableOutputManualReview: table_output_manual_review,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.ManualTranscriptionNotificationWorkflow,
                type='FlowIdentifier',
                value=None,
                title='Manual Transcription Notification Flow',
                type_spec={'filter_roles': ['notifications'], 'label': 'If task needed'},
                optional=True,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.ManualTranscriptionTaskRestrictions,
                type='TaskRestrictions',
                title='Default Task Restrictions',
                description=(
                    'Defines what users can access Supervision tasks created by this block.'
                ),
                optional=True,
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.ManualTranscriptionSupervisionTranscriptionMasking,
                type='boolean',
                value=True,
                title='Supervision Transcription Masking',
                description=(
                    'Prevents users from inputting invalid characters during'
                    ' Supervision Transcription tasks.'
                ),
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY],
            ),
            Parameter(
                name=cls.ManualTranscriptionTableOutputManualReview,
                type='boolean',
                value=False,
                title='Table Output Manual Review',
                description=(
                    'Always generates a table transcription task if the layout '
                    'contains a table. If disabled, a table transcription task will '
                    'only be generated if one or more cells have transcribed values '
                    'below the defined thresholds.'
                ),
                dependencies=[ORCA_ONLY_EXTRACTION_DEPENDENCY]
                + FeatureGatingCommonDependencies.SemiStructured,
            ),
        ]
