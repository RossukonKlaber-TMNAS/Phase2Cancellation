from typing import Any

from flows_sdk.flows import Parameter
from flows_sdk.implementations.idp_v43.base_inputs import BaseInputs
from flows_sdk.implementations.idp_v43.idp_blocks.common_settings import (
    ClassificationSettings,
    IdpSystemSettings,
)


class ManualClassificationSettings(IdpSystemSettings, ClassificationSettings, BaseInputs):
    ManualClassificationNotificationWorkflow = 'notification_workflow_classification'
    ManualClassificationTaskRestrictions = 'manual_classification_task_restrictions'

    @classmethod
    def create(  # type: ignore[override]
        cls,
        manual_classification_enabled: bool,
        notification_workflow: str | None,
        structured_layout_match_threshold: float,
    ) -> dict[str, Any]:
        return {
            cls.ManualNlcEnabled: manual_classification_enabled,
            cls.ManualClassificationNotificationWorkflow: notification_workflow,
            cls.StructuredLayoutMatchThreshold: structured_layout_match_threshold,
        }

    @classmethod
    def _get_manifest_params(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.ManualClassificationNotificationWorkflow,
                type='FlowIdentifier',
                value=None,
                title='Manual Classification Notification Flow',
                type_spec={'filter_roles': ['notifications'], 'label': 'If task needed'},
                optional=True,
            ),
            Parameter(
                name=cls.ManualClassificationTaskRestrictions,
                type='TaskRestrictions',
                title='Default Task Restrictions',
                description=(
                    'Defines what users can access Supervision tasks created by this block.'
                ),
                optional=True,
            ),
        ]
