from dataclasses import dataclass


class CustomTypes:
    FieldTranscriptionTargetAccuracies = 'FieldTranscriptionTargetAccuracies'
    IdentificationTargetAccuracies = 'IdentificationTargetAccuracies'
    TranscriptionAutomationTraining = 'TranscriptionAutomationTraining'
    TranscriptionAutomation = 'TranscriptionAutomation'
    TranscriptionThreshold = 'TranscriptionThreshold'


@dataclass
class SingleEntityTargetAccuracy(dict):
    ENTRY_TYPE_FIELD = 1
    ENTRY_TYPE_COLUMN = 2

    source_uuid: str
    target_accuracy: float
    entry_type: int
