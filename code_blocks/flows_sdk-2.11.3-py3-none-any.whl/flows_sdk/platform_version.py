"""Utilities for working with the targeted Hyperscience platform version.

The platform version a flow targets is declared through the ``HS_PLATFORM_TARGET_VERSION``
environment variable. Declaring it lets the SDK make version-aware decisions - for example only
emitting parameters that are supported by the platform the flow is being deployed to.

The helpers in this module are intentionally generic so they can be reused wherever the SDK needs
to read or reason about the targeted platform version.
"""

import os
import re
from typing import Tuple

#: Environment variable used to declare the Hyperscience platform version a flow targets.
PLATFORM_TARGET_VERSION_ENV_VAR = 'HS_PLATFORM_TARGET_VERSION'

#: A parsed platform version, expressed as a tuple of its numeric components (e.g. ``(43, 2, 1)``).
PlatformVersion = Tuple[int, ...]

_VERSION_PATTERN = re.compile(r'\d+(?:[._]\d+)*')
_VERSION_SEPARATORS = re.compile(r'[._]')


def parse_version(version_str: str) -> PlatformVersion:
    """Parse a numeric Hyperscience version string into a comparable tuple of ints.

    Components may be separated by ``.`` or ``_``; both ``'43.2'`` and ``'43_2'`` parse to
    ``(43, 2)``. The resulting tuples order the same way the versions do, so they can be compared
    directly (e.g. ``parse_version('43.2') >= (43, 2)``).

    :param version_str: the version string to parse.
    :return: the version as a tuple of its numeric components.
    :raises ValueError: if ``version_str`` is not a numeric, ``.``/``_``-separated version.
    """
    normalized = version_str.strip()
    if not _VERSION_PATTERN.fullmatch(normalized):
        raise ValueError(
            f"Could not parse the Hyperscience version '{version_str}'. Expected a numeric "
            f"version with components separated by '.' or '_', such as '43.2', '43_2' or '43.2.1'."
        )
    return tuple(int(component) for component in _VERSION_SEPARATORS.split(normalized))


def get_target_platform_version() -> PlatformVersion | None:
    """Return the targeted platform version declared via ``HS_PLATFORM_TARGET_VERSION``.

    :return: the parsed version, or ``None`` when the environment variable is unset or empty.
    :raises ValueError: if the environment variable is set to a value that cannot be parsed.
    """
    raw_version = os.environ.get(PLATFORM_TARGET_VERSION_ENV_VAR, '').strip()
    if not raw_version:
        return None
    try:
        return parse_version(raw_version)
    except ValueError as exc:
        raise ValueError(
            f"'{PLATFORM_TARGET_VERSION_ENV_VAR}' is set to an invalid value. {exc}"
        ) from exc
